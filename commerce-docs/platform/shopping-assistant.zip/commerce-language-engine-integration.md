# Commerce language engine integration

For the full storefront-to-store API flow, see the [shopping assistant guide](shopping-assistant/README.md).

The assistant chat entry point resolves ordinary free-text turns through the engine before model extraction. Configure `AI_LANGUAGE_ENGINE_URL`; an empty URL produces an unavailable response. Explicit order IDs, submitted support tickets and saved-address requests retain deterministic handlers. Basket proposal messages also pass through the gate.

## Compound semantic extension

The local source now parses supported compound actions into a semantic graph. See [local multi-message tests](commerce-language-engine/local-run-and-test.md) and [the structured contract](commerce-language-engine/semantic-requests.md). The assistant handles `COMPOUND` results as clarification or review guidance, never as automatic batch execution. The single-action rules below still apply to ordinary flat requests. This extension has not been deployed by its implementation task.

## Routing

- `PRODUCT_SEARCH`: translate supported entities into `ShoppingIntent`; use the existing scoped catalog tools, schema validation, price verification and product blocks. No model call for supported plans.
- `ADD_TO_CART`: find matching products and show the requested quantity with the existing storefront cart controls. The language engine does not supply trusted product/variant IDs or authorization, so it never writes directly to a cart.
- `VIEW_CART`: existing authenticated cart reader.
- Order status/history: existing sign-in and order-selection flow.
- Ambiguous/missing context: display the engine clarification; do not execute tools or call a model.
- `REORDER` with an explicit numbered command: scoped server-side reorder, returning the committed order card and new number without checkout navigation.
- Other changes to carts/orders and checkout: guidance to the existing review/confirmation flow; never claim an action was executed.
- Only explicit `UNKNOWN` may use the LLM path. Known low-confidence results, unsupported mappings and compound requests show engine text, clarification or guidance. Invalid JSON, missing configuration and engine outages show an unavailable/retry response with no LLM call. The engine timeout is 1.5 seconds. Non-English input is sent to the engine before any fallback decision.

Read plans require confidence >= 0.65; change guidance requires >= 0.85. These scores are heuristic, not calibrated probabilities. The engine's simulated conversation state is deliberately not promoted into actual selected product/order IDs. Follow-ups that require a selection ask for clarification. Supported clarification replies now retain the original request through an inline reply form; see [contextual replies](shopping-assistant/03_language_engine.md#contextual-clarification-replies). This addition is local until the next deployment. English-only coverage and engine ambiguities remain limitations.

## Local lab (no keys or commerce database required)

From the repository root, in two terminals:

```sh
PORT=3187 node commerce-language-engine/src/server.ts
```

```sh
cd ai-service
AI_LANGUAGE_ENGINE_URL=http://127.0.0.1:3187 .venv/bin/uvicorn local.language_lab:app --host 127.0.0.1 --port 8017
```

Open http://localhost:8017. The page shows engine JSON, the chosen route, executed catalog tools, and assistant text/product cards. It runs the real engine and shopping runtime against a clearly marked fixture catalog (apples, bananas, milk in USD). Cart/order reads are simulations, writes are disabled, and the LLM fallback is reported rather than paid for. This is a manual integration lab, not a replacement storefront.

Try `find apples`, `find bananas under $5`, `add two apples to my cart`, `show my cart`, `add it`, `cancel and create order`, and `hello`.

## Connected storefront

Native AI service: set `AI_LANGUAGE_ENGINE_URL=http://127.0.0.1:3187` when starting it, keeping the existing assistant/provider configuration.

Docker: append `-f compose.language-engine.yaml` after the existing assistant/provider Compose files when rebuilding your local stack. This adds an internal engine service on `assistant-private` and points the AI service to it. The sidecar loads the compiled dictionary when supplied, otherwise it compiles the bundled source dictionary in memory; it does not connect to or overwrite a database. No engine port is published. Native engine startup stays on loopback; `HOST` is overridden only in its container.

The currently running lab does not rebuild or modify an existing storefront deployment. Normal assistant enablement, model setup, gateway authentication, tenant scoping, budgets and permissions still apply.

## Validation

538 tests passed, one skipped across language-gate, shopping, assistant HTTP/SSE and commerce-core suites. Seven real-engine HTTP lab examples passed, and a browser search rendered the expected product card with zero LLM calls.

```sh
ai-service/.venv/bin/pytest -q ai-service/tests/test_language_gate.py ai-service/tests/test_shopping.py ai-service/tests/test_assistant.py ai-service/tests/test_commerce_core.py
npm --prefix commerce-language-engine run typecheck
```

## Direct numbered reorder

`buy again order 5`, `reorder order #5`, and `please repeat order 5` now invoke the owned-order reorder API without asking the customer to open checkout. The engine supplies `REORDER` and `entities.order_reference`. Rust independently recognizes the exact command and signs a capability bound to that order number, authenticated session, tenant and chat request ID. Questions, negation, extra instructions, ambiguous references and model tool calls cannot mint this capability.

The transaction verifies the account, original order ownership, unchanged owned saved address, exact products/options/selling units/quantities, stock allocation, delivery eligibility, current prices, promotions, tax and COD payment. The new total must be no higher than the original total in the same currency. A private temporary basket preserves the customer's current cart. Order, inventory consumption, shipments, COD obligation and outbox events commit together. A retry with the same chat `request_id` returns the same order; a new request ID is a new purchase command.

Successful chat streams contain `card.order` with the real `number` and `id`, followed by the success message. The internal `POST /v1/assistant-tools/reorder` accepts `{"order_number":5}` and returns the existing `AssistantOrder` JSON shape. Its signed capability, not an arbitrary order number or engine confidence, authorizes execution. A missing/changed address, higher total, unavailable product, required fulfillment plan/slot, or other unresolved requirement stops creation with a chat message. Pickup and manual scheduling are not automatically chosen. No saved-card charging is implemented; the platform currently uses cash on delivery.

If the API response is lost or times out, the assistant does not claim failure or automatically retry a purchase. It asks the customer to check orders. Clients retrying a transport failure must reuse the original request ID.

### Deployment

The normal EC2 Compose wrapper and Quality wrapper now include `compose.language-engine.yaml`. The EC2 source fingerprint includes the engine, so the usual deployment command rebuilds it when necessary. The next gateway startup applies the new forward-only migration `20260922170000_assistant_reorder.sql` for source-order auditing. Rebuild the gateway, AI service and engine, and recreate the assistant-tools proxy to load its new allowlisted route. This work does not deploy anything or place orders against a real store.

The local fixture lab recognizes the reorder route but intentionally creates no orders. Real creation is covered by isolated database tests in `backend/crates/api-gateway/tests/orders.rs`.

### Reorder verification

The full checkout/order database suite passes: 47 tests, including direct reorder, exact capability scoping, concurrent idempotency, ownership, price/address/stock failures, current-cart preservation, and rollback after a late payment failure. The assistant/Python suites pass 124 tests; two real-engine numbered-reorder cases and 17 deployment-script tests also pass. Rust compilation, Python lint/type checks and migration preflight pass. Strict Clippy remains blocked by existing warnings in customer memory, checkout condition formatting and trust modules; these are unrelated to the reorder implementation.

The engine Docker image also builds successfully and resolves `buy again order 5` to `REORDER` with order reference `5` under the pinned Node runtime. Database test containers were removed after verification.
