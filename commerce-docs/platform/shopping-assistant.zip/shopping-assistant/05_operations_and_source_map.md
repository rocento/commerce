# Configuration, troubleshooting and source map

## Runtime requirements

The connected path needs a configured gateway assistant, matching tenant/signing verification setup, assistant ingress/tools proxies, the Python service and the relevant commerce services. Model-assisted journeys require a working configured provider. Conversation/knowledge features require their corresponding storage/configuration.

The language engine is optional. `AI_LANGUAGE_ENGINE_URL` points Python to its HTTP endpoint. [compose.language-engine.yaml](../../compose.language-engine.yaml) adds an internal service and uses `http://commerce-language-engine:3000`; it publishes no engine port. The fixture lab in the [integration guide](../commerce-language-engine-integration.md) demonstrates routing without real purchases.

These documents describe source behavior. They do not change configuration, rebuild containers, deploy code or certify the currently running store images.

## Investigating a request

Follow the same `request_id` from the browser through gateway delegation, AI route metadata, tool audit and final receipt. For a streamed response, inspect the selected journey, language-gate status/route, tool outcomes and completion status. Avoid treating a model answer as evidence that a write committed.

| Symptom | First places to inspect |
|---|---|
| Assistant unavailable or busy | Gateway assistant enablement, rate/concurrency limits, ingress health, Python readiness |
| Ordinary English request uses a model | Check the recorded engine status: only `UNKNOWN` permits a model call; outages and unsupported mappings must return deterministic responses |
| Arabic bypasses the engine | Expected current language-gate restriction; inspect model path instead |
| Wrong/empty product results | Correct deployment tenant/catalog, discovered schema, search results and live availability |
| Cart/order access denied | Session ownership, delegated token scope/expiry and tenant match |
| Proposal cannot be applied | Expiry, cart revision, unresolved constraints, current stock and execution verdict |
| Pickup or slot missing | Effective cart-store capabilities, source eligibility and calendar/capacity availability |
| Reorder rejected | Exact command, owned order/address, current total/currency, stock and required fulfillment selection |
| Reorder response interrupted | Check orders; preserve original request ID for a transport retry |
| Older history has stale prices | Expected: history is a past response; request current facts or a new quote |

## Source map

All links below point to the implementation reviewed for this guide.

| Area | Entry points |
|---|---|
| Chat UI and proposal review | [assistant.tsx](../../frontend/apps/storefront/src/assistant.tsx), [shopping.tsx](../../frontend/apps/storefront/src/shopping.tsx) |
| Stream validation | [API client assistant.ts](../../frontend/packages/api-client/src/assistant.ts) |
| Gateway delegation and tool routes | [assistant.rs](../../backend/crates/api-gateway/src/assistant.rs) |
| Catalog tools | [assistant_catalog.rs](../../backend/crates/api-gateway/src/assistant_catalog.rs), [catalog_tools.py](../../ai-service/app/catalog_tools.py) |
| AI request routing | [main.py](../../ai-service/app/main.py), [security.py](../../ai-service/app/security.py) |
| Language-engine adapter | [language_gate.py](../../ai-service/app/language_gate.py) |
| Language-engine HTTP/runtime | [server.ts](../../commerce-language-engine/src/server.ts), [engine.ts](../../commerce-language-engine/src/engine.ts) |
| Shopping and constraints | [shopping.py](../../ai-service/app/shopping.py), [commerce_meaning.py](../../ai-service/app/commerce_meaning.py) |
| Runtime/core path selection | [runtime.py](../../ai-service/app/runtime.py), [core_facade.py](../../ai-service/app/core_facade.py) |
| Basket planning and proposals | [baskets.py](../../ai-service/app/baskets.py), [gateway shopping.rs](../../backend/crates/api-gateway/src/shopping.rs), [domain shopping.rs](../../backend/crates/domain-cart-checkout/src/shopping.rs) |
| Direct reorder | [reorder.py](../../ai-service/app/reorder.py), [assistant_reorder.rs](../../backend/crates/api-gateway/src/assistant_reorder.rs) |
| Memory and knowledge | [personalization.py](../../ai-service/app/personalization.py), [knowledge.py](../../ai-service/app/knowledge.py) |
| Settings and proxy boundary | [settings.py](../../ai-service/app/settings.py), [tools.conf](../../deploy/assistant/tools.conf) |
| Fulfillment behavior | [fulfillment milestone](../rocento_fulfillment_milestone_md/README.md) |

## Verification boundary

This guide was produced by reading current routing, contracts, authorization, domain adapters, storefront code and deployment configuration. Documentation links were checked; no application suites or real-store purchases were run for this documentation task. Existing dated test evidence remains in the [language-engine integration record](../commerce-language-engine-integration.md) and [fulfillment completion report](../rocento_fulfillment_milestone_md/05_completion_report.md). Counts from those records are scoped to their runs, not a new end-to-end acceptance result.


### Clarification implementation checks — 22 September 2026

The follow-up change passed the selected Python language-gate/assistant tests (79 including a real-engine fish scenario and a no-model HTTP/SSE test), 25 frontend state/client tests and eight desktop/mobile browser checks. Rust gateway compilation, storefront/admin TypeScript and changed-file Ruff checks passed. Broader Python type checking still reports existing errors in `personalization.py` and `knowledge.py`; it is not a clean whole-service type-check result. The browser checks use mocked commerce APIs; the real-engine scenario uses fixture catalog facts. No production deployment or order placement was performed for this change.
