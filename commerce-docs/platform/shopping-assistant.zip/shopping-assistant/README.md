# Shopping assistant

Rocento's shopping assistant translates customer requests into bounded searches, comparisons, basket proposals and supported account actions. The commerce API supplies store facts and authorizes changes. The language engine helps understand text; it does not own inventory, prices, customers or orders.

This guide describes the local source reviewed on **22 September 2026**, including the commerce language engine and direct numbered reorder integration. It does not assert that every store is running this version or that every optional feature is enabled.

## Read in this order

1. [Architecture: what each component does](01_architecture.md)
2. [Customer flows, from message to result](02_customer_flows.md)
3. [Commerce language engine interaction](03_language_engine.md)
4. [APIs, store context and authorization](04_apis_and_stores.md)
5. [Configuration, troubleshooting and source map](05_operations_and_source_map.md)

## What the customer can do

| Request | Current behavior |
|---|---|
| Find or compare products | Searches a bounded set of current store products and returns grounded cards/comparisons |
| Add a product through ordinary chat | Finds matching products and offers existing cart controls; language resolution alone does not mutate the cart |
| Shop for me / optimize my cart | Prepares a quoted, editable proposal for customer approval |
| Buy again through the shopping workspace | Proposes a previous order for review, then applies approved changes to the cart |
| Explicit `buy again order 5` in ordinary chat | Can place a new COD order through the narrowly authorized reorder path when all backend checks pass |
| Read cart, saved addresses or order status | Uses account/context-specific handlers; protected information requires sign-in |
| Ask a store policy question | Can use approved policy/knowledge sources when configured |
| Choose delivery or pickup | Existing checkout uses live store fulfillment capabilities and availability |

The distinction between a **suggestion**, a **saved proposal**, an **applied cart change** and a **placed order** is deliberate. A product card or assistant sentence is not a transaction receipt.

For runnable engine-only examples, see [local multi-message testing](../commerce-language-engine/local-run-and-test.md) and the [compound semantic request contract](../commerce-language-engine/semantic-requests.md).

See [all 20 database tables, multi-sentence/context handling and the UNKNOWN-only LLM policy](../commerce-language-engine/database-and-context.md).
