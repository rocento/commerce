# Customer flows

## Ordinary product search

Example: “Find bananas under $5.”

1. The storefront sends text, a request UUID and conversation context to the gateway.
2. Rust checks authentication when supplied, limits the request, and signs short-lived context/tool capabilities for this installation.
3. Python verifies that context. When enabled, the language gate sends the text to the commerce language engine.
4. A supported resolution becomes a typed shopping intent. Only `UNKNOWN` permits model extraction; known unsupported requests show engine text, and ambiguous requests ask for clarification.
5. Shopping loads catalog schema and reads current candidates through scoped commerce tools. It preserves constraints, checks facts and filters/ranks the bounded result set.
6. The service emits progress, text and typed product blocks. The gateway streams these to the storefront.
7. The customer uses normal product/cart controls. Merely interpreting “add two bananas” does not write the cart.

```mermaid
sequenceDiagram
    participant C as Customer/storefront
    participant G as Rust gateway
    participant A as AI service
    participant L as Language engine
    participant T as Commerce tools/domains
    C->>G: Chat text + request_id
    G->>A: Signed context + scoped tokens
    A->>L: POST /api/resolve with text
    L-->>A: Intent, entities, status, confidence
    alt Supported shopping intent
        A->>T: Catalog schema and product queries
    else Explicit UNKNOWN resolution
        A->>A: Model-assisted extraction when available
        A->>T: Validated allowed queries
    end
    T-->>A: Current store facts
    A-->>G: SSE progress, text, product blocks, done
    G-->>C: Validated storefront presentation
```

Clarification can end the turn before catalog execution. The customer can answer in the attached reply field; the original request and answer are then resolved together through the engine. See [contextual replies](03_language_engine.md#contextual-clarification-replies). Model/provider unavailability is not permission to fabricate products or prices.

## Shop for me and optimize my cart

These explicit `shopping_mode` journeys now pass through the language gate. Only `UNKNOWN` can enter model planning; known results show engine text/clarification/guidance, and an engine outage stops with a retry response. The proposal steps below apply when the gate permits planning.

1. The storefront opens a shopping task with mode `shop`, `optimize` or `buy_again`.
2. Rust binds a basket capability to the owned customer/guest cart. Python reads basket context, including cart revision, current items and fulfillment facts.
3. The planner uses catalog tools to prepare candidate additions/replacements. Optimization preserves requested locks and constraints; proposed changes are visible to the customer.
4. Python submits a draft to the Rust basket-proposal endpoint. Rust validates and quotes the proposed result, returning issues, expiry and whether it can be applied.
5. Chat returns a `basket_proposal` block referencing the saved proposal. The live cart has not changed yet.
6. The customer reviews/edits the proposal. Edits need a fresh quote. “Approve and apply to cart” calls the normal cart proposal API, which revalidates before applying.
7. The customer continues to checkout, chooses an available receiving method/window and confirms the order.

An expired or stale proposal must be refreshed. A proposal that fails execution checks cannot be approved through the UI. Applying a proposal is a cart operation, not order placement.

## Two buy-again flows

**Workspace buy again:** the customer chooses a previous order, receives a newly quoted proposal, approves cart changes and continues to checkout.

**Direct numbered command:** ordinary chat such as `buy again order 5` can create a new cash-on-delivery order. Rust independently matches the narrow command and signs an order-number-bound capability; the language engine's `REORDER` result is not sufficient authorization.

The reorder transaction checks ownership, unchanged saved address, exact products/options/selling units/quantities, current availability and delivery eligibility, current price/promotions/tax and COD compatibility. The total must not exceed the original in the same currency. A private temporary basket preserves the existing cart. Requirements such as a new fulfillment plan or customer-selected slot stop automatic creation. Pickup is not chosen automatically.

Success returns a real order card and number. The same request UUID is idempotent; a new UUID represents a new purchase command. If the response is lost, the assistant reports an uncertain outcome and directs the customer to check orders rather than claiming failure or repeating a purchase.

## Account, support and fulfillment

Explicit order context, submitted support tickets and saved-address requests retain dedicated handlers. Protected data requires the appropriate authenticated owner and scope. Support creation uses the existing support service.

Delivery/pickup rules come from live commerce context. Disabled methods must not be offered as available. A desired delivery date is not a reservation. Checkout creates and confirms fulfillment plans through the normal fulfillment APIs, including atomic source groups and capacity where configured. See [fulfillment plans](../fulfillment/plans-api.md).
