# Commerce language engine interaction

## What the integration sends

With `AI_LANGUAGE_ENGINE_URL` configured, `language_gate.resolve()` calls `POST /api/resolve` with `{"text": "customer message"}`. The assistant adapter sends text only to the engine, not the inspector's simulated conversation state, customer tokens, live cart or order records. For an explicit clarification reply it re-resolves the original request, fills a supported missing field and sends the combined request back to the engine.

The engine returns structured data including `status`, `intent`, `entities`, `message`, `confidence`, and possibly confirmation/context indicators. Python validates the response before using it. The engine loads its compiled dictionary at startup; it does not query or update the commerce database.

## Routing rules in the current adapter

| Result | Assistant path |
|---|---|
| `PRODUCT_SEARCH`, `ADD_TO_CART`, confidence at least 0.65 | Try a supported typed shopping plan and run existing catalog tools |
| `VIEW_CART`, confidence at least 0.65 | Existing cart reader |
| `TRACK_ORDER`, `ORDER_HISTORY`, `ORDER_STATUS`, confidence at least 0.65 | Existing sign-in/order-selection flow |
| `AMBIGUOUS`, `NEEDS_CONTEXT`, or a context request | Return clarification; no model/tool execution for that branch |
| `REORDER`, confidence at least 0.85 | Narrow direct reorder handler, still requiring Rust authorization |
| Recognized cart/order mutations, confidence at least 0.85 | Guidance to existing review/action screens unless handled by the direct reorder exception |
| `UNKNOWN` | May use the model-assisted path when available |
| Known intent with low confidence or unsupported catalog mapping | Show the engine message; no LLM |
| Missing configuration, timeout, invalid response or unavailable engine | Show a retry/unavailable message; no LLM |

Every known engine message is emitted as `message.delta` in chat. Supported catalog/account handlers can append live results; compound/mutation guidance follows the engine text. `UNKNOWN` is permission to consider a model, not a requirement to call one.

Scores are rule-based heuristics, not calibrated probabilities. They never authorize a commerce mutation.

## Supported search mapping

The adapter accepts a bounded set of entities: product text/category, brand, color, material, size, quantity, price/currency and cart destination. Product text becomes a search query; attributes are checked against the discovered store schema. Supported price bounds become typed constraints. A budget with no currency can require clarification.

Complex negative/factual constraints and unsupported entity keys stop catalog execution and show the engine response. Missing references show clarification. None of these cases permit an LLM call. `ADD_TO_CART` still returns matching products and cart controls; it does not become an internal write tool.

## Availability and limits

- Configure `AI_LANGUAGE_ENGINE_URL` for free-text chat. An empty URL produces an unavailable message, not model fallback.
- Text over 4,000 characters cannot be resolved by this adapter and receives an unavailable response. Other languages are sent to the engine too; only an explicit `UNKNOWN` allows model fallback. English remains the deterministic grammar’s supported language.
- Engine requests have a 1.5-second timeout. Invalid JSON, schema mismatch, oversized response or HTTP failure produces a retry message without a model call.
- Explicit basket modes also pass through the engine. Known results return engine text/clarification/guidance; only `UNKNOWN` can start the model-assisted basket planner. Submitted support, selected orders and saved-address handling retain deterministic handlers.
- Engine resolution alone does not ensure the downstream assistant/model/catalog configuration is ready.

The standalone engine accepts optional context in its own API, but the assistant deliberately does not promote its simulated states into commerce authority.

## Example outcome

“Find apples” can resolve to `PRODUCT_SEARCH`, become a typed intent and query the store's current catalog without a model extraction call. “Find apples without allergens” exceeds the simple adapter's supported constraint mapping and displays the engine response without invoking the model. “Add it” may require clarification because no trusted product selection was supplied.

For the local fixture lab and existing integration verification record, see [language engine integration](../commerce-language-engine-integration.md). Fixture products are not a connected merchant catalog.


## Contextual clarification replies

Implemented locally on 22 September 2026; not deployed by this change.

An engine clarification now emits a typed `clarification` field with `original_message` and `question`. After the response completes, the storefront shows an inline reply form. The main composer also attaches the latest pending clarification unless the customer chooses “Start a different request.” A question mark alone does not activate this flow.

For example:

```text
Customer: pls add two product to cart
Engine: Which product or items do you mean?
Reply: fish
Reconstructed engine input: pls add two fish to cart
Result: catalog search for fish, preserving quantity 2
```

The browser sends the answer plus the original question context. Python rechecks the original text with the engine; it does not trust a client-supplied intent. Supported product-name, cart/wishlist and numeric-quantity clarifications are composed deterministically and resolved again. Multi-step supported clarifications carry the latest reconstructed request forward.

Replies stay on the deterministic path: engine failure or an unsupported answer returns another question or asks for a new complete request, rather than silently sending the reply alone to the model. Complex request changes should use “Start a different request.” This is not unrestricted conversational slot filling for every engine intent.

Clarification context never authorizes a purchase. The gateway does not mint a direct-reorder capability for these replies. Existing cart review and checkout rules remain in force. Pending inline forms currently live in the active chat UI; historical transcript reload does not restore the form.
