# Architecture

## The components

| Component | Responsibility | Source of authority |
|---|---|---|
| React storefront | Chat, streamed progress, product cards, proposal review and checkout | Renders API results; customer initiates supported actions |
| Rust API gateway | Customer authentication, deployment tenant, rate limits and scoped delegation | Owns access to commerce domain services |
| Python AI service | Selects a journey, interprets constraints, invokes allowed tools and composes validated responses | Can act only through delegated tools |
| Commerce language engine | Resolves supported text into an intent, entities and clarification/confidence data | Text interpretation only |
| Model provider | Structured extraction and language reasoning only after an explicit engine `UNKNOWN` | Model output is validated, not trusted commerce state |
| Rust commerce domains | Catalog, pricing, inventory, carts, fulfillment, orders and payments | Authoritative business rules and transactions |
| AI history/knowledge storage | Conversations, metrics and approved retrieval data when configured | Separate from the commerce database |

```mermaid
flowchart TD
    C[Customer in store] --> UI[React storefront]
    UI --> G[Rust API gateway]
    G -->|Signed short-lived context| AI[Python AI service]
    AI -->|Ordinary text when enabled| LE[Commerce language engine]
    LE -->|Intent and entities| AI
    AI -->|When needed| M[Configured model provider]
    AI -->|Scoped tool requests| P[Assistant tools proxy]
    P --> G
    G --> D[Commerce domain services]
    D --> DB[(Store installation database)]
    AI --> H[(AI history and approved knowledge)]
    AI -->|Validated SSE events via gateway| UI
    UI -->|Approved cart and checkout actions| G
```

## Three different meanings of “engine”

**The commerce language engine** is the TypeScript service in `commerce-language-engine/`. It loads a compiled dictionary and resolves phrases using normalization, entities, rules, scoring and clarification. It is not the live catalog and does not create orders.

**The AI runtime/core** is Python orchestration in `ai-service/app/`. `language_gate.py` adapts language-engine JSON; `shopping.py` and `baskets.py` run shopping journeys. `core/`, `core_facade.py`, meaning and planning adapters provide typed policy, constraints and bounded execution. The optional core path is selected before execution; a failed partial execution is not replayed automatically through the legacy path.

**The commerce backend** is Rust. It decides actual prices, salable quantities, address eligibility, fulfillment reservations, order state and payment obligations. Both deterministic language routing and model-assisted routing eventually use these same business rules.

## Grounding the answer

The assistant discovers the store's catalog schema, translates supported constraints, fetches candidates through allowed tools and checks available product facts. Managed attributes, product/variant identity, currency, price and stock come from commerce projections. Unknown stock cannot satisfy an explicit in-stock requirement. Search examines a bounded candidate set; it is not proof of the globally cheapest product.

Catalog display prices do not replace the checkout total. Checkout re-evaluates prices, promotions, tax, delivery and fulfillment. Knowledge retrieval can explain an approved return policy, but cannot establish current stock or reserve a slot.

Conversation history and optional personalization help interpret follow-ups. They do not grant access or turn previously mentioned products/orders into authorized selections. Ownership and mutable facts are checked again through backend APIs.
