# APIs, stores and authorization

## Store identity

The browser enters through its store's configured commerce gateway. Rust takes `ASSISTANT_TENANT_ID` from deployment configuration; it does not trust a tenant ID invented in a chat message. Delegated tokens include that tenant, the customer/session when authenticated, request ID, scope and expiration. Python validates issuer, audience, signature, tenant and scope. Rust validates the tool capability again when a tool calls back.

An installation database is the commerce tenant boundary. Fulfillment stores inside that installation are a separate concept: the owned cart has `fulfillment_store_id`, which controls fulfillment policy/source eligibility. Changing a fulfillment store is not switching to another tenant database or automatically selecting a different AI provider/catalog installation.

The shared assistant code can serve different merchant deployments because tools read each deployment's actual catalog schema, managed attributes, currency, prices, inventory and policies. It does not assume that grocery, electronics and jewelry have identical attributes. This is not a federated cross-store shopping service: chat cannot query another installation by naming it.

## Browser-facing APIs

Paths below are gateway `/v1` routes; storefront proxy configuration may prepend `/api`.

| Method and route | Purpose |
|---|---|
| `POST /v1/assistant/chat` | Start a streamed turn |
| `GET /v1/assistant/history` | Restore owned conversation history |
| `POST /v1/assistant/feedback` | Record feedback on an owned response |
| `GET /v1/cart/shopping/{task}` | Read owned shopping-task context |
| `DELETE /v1/cart/shopping/{task}` | Cancel the task |
| `POST /v1/cart/proposals` | Create/requote a basket proposal |
| `GET /v1/cart/proposals/{id}` | Read an owned saved proposal |
| `POST /v1/cart/proposals/{id}/apply` | Apply an approved proposal with backend validation |
| `GET /v1/fulfillment/availability` | Read live receiving methods and eligible pickup locations |
| `POST /v1/fulfillment/plan-options` | Calculate eligible source groups/windows |
| `POST /v1/fulfillment/plans` | Atomically reserve the chosen plan |
| `POST /v1/customer/checkout/quote` | Quote the actual checkout |
| `POST /v1/customer/checkout/place` | Place the order through existing idempotent checkout |

Chat input includes `request_id`, `message`, and optional `conversation_id`, `order_id`, `shopping_mode`, ticket context or `clarification: {original_message, question}`. Clarification cannot be combined with an order, ticket or shopping-mode journey. These fields select a journey; they do not bypass ownership checks.

## AI-only commerce tools

The Python service uses the internal assistant-tools proxy and signed capability headers. These are not general-purpose model-accessible admin APIs.

| Method and route | Scope of work |
|---|---|
| `POST /v1/assistant-tools/shopper` | Read-only named catalog operations |
| `GET /v1/assistant-tools/cart` | Scoped cart projection |
| `GET /v1/assistant-tools/delivery` | Delivery context projection |
| `GET /v1/assistant-tools/orders/{id}` | Owned order status |
| `POST /v1/assistant-tools/support/tickets` | Authorized support creation |
| `GET /v1/assistant-tools/baskets/{cart}` | Bound basket context |
| `POST /v1/assistant-tools/baskets/{cart}` | Validate/quote and save a proposal; not apply it |
| `POST /v1/assistant-tools/reorder` | Explicit authorized numbered reorder |

The shopper tool accepts a named operation and arguments. Current operations are `get_catalog_schema`, `search_products`, `get_product`, `get_product_attributes`, `get_product_price`, `get_product_inventory`, `compare_products` and `get_category`.

Example read-only body:

```json
{"name":"search_products","arguments":{"query":"apples"}}
```

Rust owns validation and projection of these results. Product text and model output cannot supply authorization. The original customer commerce bearer token stays in Rust; Python receives narrow delegated capabilities instead. Basket scopes bind a cart; reorder scopes bind an order number and request/session context.

## Streaming back to the storefront

Python serves internal `POST /v1/chat` through assistant ingress. It emits Server-Sent Events with a version, request ID, sequence and type. A `message.delta` may carry explicit `clarification` context for the reply form. Types include `progress`, `message.delta`, `content.blocks`, `card.order`, `ticket.created`, `error` and `done`.

The TypeScript client validates envelopes, sequence, request identity and typed blocks. Product cards, comparisons and basket proposal references render through dedicated UI components. Progress reports stages, not raw tool arguments or hidden model reasoning. A missing `done` is treated as an interrupted stream.

## Persistence and freshness

Commerce records and transactions stay behind Rust domain services. AI history/metrics and approved knowledge use their own configured storage. Personalization is scoped and optional; `x-commerce-personalize: 0` can disable its use for a request. Previously saved assistant text is not a fresh stock/price guarantee. Proposal application, fulfillment reservation and order placement perform their own checks.
