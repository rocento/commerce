# Run and test the engine locally

These commands run the actual deterministic engine. They need Node.js **22.18 or later** and npm. They do not require a model key, Docker, a commerce database or real orders.

## Start the local inspector

From the repository root:

```sh
cd commerce-language-engine
npm ci
PORT=3187 npm start
```

Open [the local engine inspector](http://127.0.0.1:3187). Enable **Keep conversation context**. Enter a message and press **Analyze**. Replace the text with your answer and analyze again. **Clear** clears the displayed request; **Reset context** starts a separate conversation.

The engine loads `data/compiled.json` when available, otherwise builds its dictionary in memory. You do not need to run migrations or regenerate the dictionary for this semantic extension. The optional dictionary authoring/database workflow remains in the [engine README](../../commerce-language-engine/README.md).

## Try these conversations

| First message | Expected first result | Next answer | Expected completed request |
|---|---|---|---|
| `pls add two product to cart` | `NEEDS_CONTEXT`: which product? | `fish` | Add fish, quantity 2 |
| `create an order for two apples and deliver it there` | `NEEDS_CONTEXT`: which address? | `home` | Create order with two apples and HOME delivery reference |
| `repeat my last order and deliver it tomorrow morning` | `NEEDS_CONTEXT`: which previous order? | `order 15` | Repeat reference 15 with TOMORROW/MORNING delivery |
| `create the same order but send it to my work address` | `NEEDS_CONTEXT`: which previous order? | `order 15` | Copy reference 15 and create an order using WORK |

Reset context between rows. Otherwise an earlier address/order/product reference may intentionally answer a later reference.

Also try complete requests:

```text
create order for two apples and deliver to my home address
add two apples and one milk then checkout
find shoes and add them to the cart
create order for one book and deliver to home on 2026-10-05 between 9am and 11am
add one hundred and two "salt and pepper shakers" and three mugs then checkout
```

Quoted product names preserve internal conjunctions. Item counts are bound to individual products, while action connectors create separate clauses. The output includes the primary intent, items, operations, references and their relationships.

## Run the saved demonstration

In another terminal, from the engine directory:

```sh
npm run demo:context
```

This runs the five saved scenarios against the engine in-process and prints each response/context. It uses a fixed `referenceDate` of `2026-09-22` and `Africa/Cairo` so “tomorrow” produces a reproducible date. It does not need the HTTP server.

For an interactive terminal that carries context automatically:

```sh
npm run cli
```

Use `/context` to inspect the session and `/reset` to clear it.

## Call the HTTP API with context

A simple request:

```sh
curl -s http://127.0.0.1:3187/api/resolve \
  -H 'Content-Type: application/json' \
  -d '{"text":"create order for two apples and deliver to my home address"}'
```

For multi-message requests, send **the returned `context.next` as the next request's `context`**. Sending only `fish` discards the pending request. This runnable Node example carries the context correctly:

```sh
node --input-type=module <<'JS'
const url = 'http://127.0.0.1:3187/api/resolve';
let context = { referenceDate: '2026-09-22', timezone: 'Africa/Cairo' };
for (const text of [
  'create an order for two apples and deliver it there',
  'home',
]) {
  const response = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ text, context }),
  });
  if (!response.ok) throw new Error(await response.text());
  const result = await response.json();
  console.log(JSON.stringify({ text, status: result.status,
    primaryIntent: result.primaryIntent, entities: result.entities,
    operations: result.operations, missing: result.missing }, null, 2));
  context = result.context.next;
}
JS
```

Use the store's actual local calendar date and timezone in a connected client. Without a date anchor, “tomorrow” remains a symbolic relative date rather than an invented absolute date.

## Automated checks

From the engine directory:

```sh
npm run typecheck
npm run test:semantic
npm test
```

`test:semantic` covers semantic parsing and starts/stops a temporary HTTP server for a real context round trip. `npm test` includes existing intent/scoring regressions. Both are local correctness checks, not production load tests.

From the repository root, verify assistant-adapter compatibility with an existing Python development environment:

```sh
ai-service/.venv/bin/pytest -q ai-service/tests/test_language_gate.py ai-service/tests/test_assistant.py
```

## Connected assistant versus engine inspector

The inspector returns JSON and remembers context when its checkbox is enabled. It never adds cart items or creates orders.

The shopping assistant uses the same engine but has separate catalog, authentication and review flows. Compound operations currently produce review guidance; they are not executed as a batch. The narrowly authorized direct numbered reorder remains separate. Deploying this extension requires the engine and AI-service code together through the existing deployment workflow; these local commands do not deploy anything.
