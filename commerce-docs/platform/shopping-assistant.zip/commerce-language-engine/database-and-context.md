# Dictionary tables and conversation handling

This guide describes the **Commerce Language Engine database** (`commerce_language`), not the platform's operational catalog, customer, cart or order database. It has 20 public tables. Parser changes live in TypeScript; adding semantic clauses did not add a conversation table or modify customer data.

## Each table and its role

| Table | What it stores | Role and relationships |
|---|---|---|
| `industry_packs` | Named industry scopes with active/version flags | Vocabulary and entity terms refer to a pack, allowing grocery and other domain vocabularies. This is not a store or tenant table. |
| `intent_families` | Intent family codes | Groups related intents for dictionary organization. Referenced by `commerce_intents.family_id`. |
| `commerce_intents` | Intent code, description, action/risk classification, confirmation requirement, active/version and metadata | Defines recognized meanings such as `ADD_TO_CART`. Rules, action frames, patterns and transitions reference it. Risk metadata never authorizes an API write. |
| `semantic_groups` | Concept code, category, description and value type | Groups words expressing a common concept. Terms and rule conditions point here. |
| `semantic_terms` | Surface term, normalized term, matching/scoring metadata and industry scope | Connects text vocabulary to a semantic group. Compiler builds matching indexes from these groups/terms. Some stored tuning metadata is not independently consumed by runtime scoring. |
| `intent_rules` | Intent reference, rule code, base score, required states, active/version | A primary or alternative rule for an intent. Its conditions live in `intent_rule_conditions`. |
| `intent_rule_conditions` | Rule/group references, condition kind, score, occurrence/proximity/order constraints | REQUIRED/OPTIONAL/POSITIVE/BOOST/NEGATIVE/DISQUALIFY conditions describe evidence for or against an intent. Optional after/near group references express positional relationships. |
| `entity_types` | Entity type codes | Organizes dictionary entity aliases, for example product categories or attributes. |
| `entity_terms` | Alias, normalized alias, canonical value, entity type and industry | Current entity vocabulary read by `loadDictionary()`. Several phrases can map to one canonical value. Not a live product inventory. |
| `entity_aliases` | Legacy alias records with similar fields | Compatibility table retained by migrations; migrated into `entity_terms`. Current dictionary loading reads `entity_terms`, so editing only this legacy table does not update the runtime. |
| `commerce_operators` | Operator codes such as `<`, `BETWEEN`, `NOT_IN`, `BEFORE` | Vocabulary/inspection lookup. Actual quantity, price and date interpretation also requires parser code; this is not an executable SQL-operator registry. |
| `phrase_patterns` | Intent reference, ordered group list, score, active/source | Persisted pattern metadata; compiler validates it and builds `patternsByIntent`. The current resolver does not consume that index for scoring, so a row alone does not introduce a new grammar behavior. |
| `context_states` | Symbolic state codes | Dictionary vocabulary for states referenced by rules/transitions. These are **not saved customer conversations** or rows tracking each customer's cart. |
| `intent_transition_rules` | Previous intent, target intent, semantic group, required states and boost | Helps contextual classification when the caller supplies previous intent/state. Does not retrieve chat history or execute the next action. |
| `intent_conflicts` | Intent pairs and penalty metadata | Identifies incompatible interpretations. Loading currently reads pairs; do not assume editing the persisted penalty column tunes runtime scoring. |
| `request_prefixes` | Active introductory phrases | Reusable request wording handled by normalization/dictionary grammar. |
| `action_frames` | Intent plus action/target/preposition lists, excluded objects and selection requirement | Reusable grammatical frames. Compound parsing also uses code to detect boundaries and attach entities; frames are not complete sentence templates. |
| `generated_utterances` | Example text, expected intent/entities/status, context, difficulty, split, template family, source and unique content hash | Generated evaluation/training-style corpus. These are test examples, not customer chat logs and not an LLM fine-tuning job. Dictionary loading selects the canonical/legacy corpus families. |
| `evaluation_results` | Evaluation time, dictionary version and JSON metrics | Records measured results for a dictionary version. Old metrics do not validate newer code automatically. |
| `generation_runs` | Version, fingerprint, manifest, timestamp and active flag | Dictionary generation history. A unique constraint permits one active generation. Distinct from application deployment history. |

The central path is `intent_families → commerce_intents → intent_rules → intent_rule_conditions → semantic_groups → semantic_terms`. Entity vocabulary is organized separately as `entity_types → entity_terms`, with industry references. Transitions and conflicts connect intents to each other.

## Database versus running engine

The engine normally reads `data/compiled.json` at startup, or builds a dictionary in memory if no compiled artifact exists. It does **not** query PostgreSQL for every message. The database-backed compile command loads dictionary rows and writes a new artifact; offline compilation reads `data/generated.json`. Restart the engine to load a changed artifact.

The last local read-only inspection found **340 intents and active dictionary version 3**. The current database loader requires version 5 or later. That snapshot therefore does not represent the current source/compiled grammar. No regeneration was performed as part of this routing/documentation update. `npm run generate` replaces owned dictionary rows; it is not a read-only inspection command.

In DBeaver, inspect rows or run these read-only queries:

```sql
SELECT code, description, action_type, risk_level, requires_confirmation
FROM commerce_intents ORDER BY code;

SELECT dictionary_version, fingerprint, active, created_at
FROM generation_runs ORDER BY created_at DESC;

SELECT i.code AS intent, r.code AS rule, c.kind, g.code AS semantic_group, c.score
FROM commerce_intents i
JOIN intent_rules r ON r.intent_id = i.id
JOIN intent_rule_conditions c ON c.rule_id = r.id
JOIN semantic_groups g ON g.id = c.semantic_group_id
ORDER BY i.code, r.code, g.code;
```

## Multiple sentences in one message

The semantic parser detects action heads, clause boundaries and their arguments. It does not split every `and`: in `add two apples and one milk then checkout`, the first conjunction joins two items, while `then checkout` introduces another action. Quantity 2 binds to apples and quantity 1 to milk. Number phrases and quoted product names are preserved.

It builds `clauses`, `actions`, `entities.items`, optional `entities.delivery`, `references` and `relationships`, then orders preparation operations before checkout/order creation. An action's `itemIndexes` identifies its own products. Supported punctuation-separated action clauses use the same pipeline; unsupported prose is still limited by the implemented English grammar.

For `create an order for two apples and deliver it there`, the engine retains `CREATE_ORDER` and the two apples. `it` can refer to the order, but `there` requires an address reference. The status is `NEEDS_CONTEXT`, with the missing address identified, rather than discarding the recognized request as ambiguous.

## Multiple messages in a conversation

There are two integrations:

1. **Direct engine API, CLI and inspector:** the caller sends context and carries `response.context.next` into the next request. It can contain a pending request, selected item descriptors, prior order/address references, reference date/timezone and classifier states. The engine server is stateless; `context_states` does not store this per-user context.
2. **Storefront chat:** an engine clarification emits the original message and question. The inline reply form sends the answer attached to that context. Python re-resolves the original message, fills a supported missing detail, and sends the reconstructed request to the engine again. It does not blindly concatenate the whole transcript or trust a client-supplied intent.

Example: `add two products to cart` → `Which product?` → `fish` reconstructs `add two fish to cart`. Quantity and destination survive the reply. Supported repeated clarifications carry the reconstructed request forward. An unrelated new request should use **Start a different request**. Pending inline forms are currently maintained in the active UI; historical transcript reload does not restore them.

References describe language, not ownership. HOME/WORK must still be mapped to an owned address, products to real catalog variants, and dates to available delivery slots before execution. Compound plans currently show review guidance; they do not execute several writes automatically.

## Chat and LLM policy

| Engine outcome | Chat behavior | LLM allowed? |
|---|---|---|
| `RESOLVED`, supported read/search | Show engine text, then scoped API results/cards | No |
| `RESOLVED`, compound/mutation | Show engine text and review guidance; narrow authorized reorder remains separate | No |
| Known intent but low confidence/unsupported mapping | Show engine message without guessing an executable plan | No |
| `NEEDS_CONTEXT` or `AMBIGUOUS` | Show engine question and attached reply context | No |
| `UNKNOWN` | May use the existing model-assisted path | **Yes** |
| Timeout, invalid response, missing URL or unavailable engine | Show retry/unavailable message | No |

This gate applies to ordinary free text and explicit basket modes. Dedicated support submissions, selected-order reads and saved-address handlers remain deterministic. A question mark alone is not sufficient to create reply context. Known engine messages are streamed as `message.delta`; successful scoped handlers can append their results. Model availability and budgets still constrain an allowed UNKNOWN fallback.

See [local run/test instructions](local-run-and-test.md), [semantic contract](semantic-requests.md) and [assistant adapter details](../shopping-assistant/03_language_engine.md). Source definitions are in `commerce-language-engine/migrations/`, `src/database.ts`, `src/runtime.ts`, `src/semantic-*.ts` and `ai-service/app/language_gate.py`.
