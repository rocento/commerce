# Structured semantic requests

## Output contract

The extension preserves `intent`, existing diagnostic fields and legacy simple-request behavior. Structured requests additionally expose:

| Field | Meaning |
|---|---|
| `primaryIntent` | Main requested outcome; null for conflicting alternatives |
| `entities.items` | Product noun phrases with their own quantity/unit/reference |
| `entities.delivery` | Address reference, date/relative date and time window |
| `entities.order` | Prior-order reference and its contextual resolution, if supplied |
| `operations` | Ordered linguistic operations, not executed API calls |
| `actions` | Stable action IDs, source clause IDs and bound item indexes |
| `clauses` | Source text spans, intent, connector and negation |
| `references` | Pronouns/reference kinds and whether they were bound |
| `relationships` | Uses, precedes, modifies and refers-to edges |
| `missing` | Unresolved field paths |
| `context.next` | Bounded context the client can carry to the next turn |

Example projection for `create order for two apples and deliver to my home address`:

```json
{
  "status": "RESOLVED",
  "intent": "CREATE_ORDER",
  "primaryIntent": "CREATE_ORDER",
  "entities": {
    "items": [{"productText": "apples", "quantity": 2}],
    "delivery": {"addressReference": "HOME"}
  },
  "operations": ["ADD_ITEM", "SET_DELIVERY_ADDRESS", "CREATE_ORDER"],
  "requiresConfirmation": true
}
```

The complete response also includes the graph, legacy diagnostics and a `NOT_EXECUTED` fulfillment marker. Product phrases and HOME/WORK are linguistic references, not verified product IDs or owned addresses.

## Parsing stages

```mermaid
flowchart LR
    T[Customer text] --> C[Semantic clause detection]
    C --> A[Action heads and negation]
    A --> E[Per-clause items and delivery entities]
    E --> R[Bind pronouns and supplied context]
    R --> G[Relationships and operation ordering]
    G --> S{Missing or conflicting details?}
    S -->|Missing detail with known intent| N[NEEDS_CONTEXT]
    S -->|Conflicting alternatives| B[AMBIGUOUS]
    S -->|Supported complete request| O[RESOLVED]
```

Action heads and target grammar identify clause boundaries. `and` followed by another action creates a clause; an item-list conjunction binds another item when its noun/quantity structure supports that interpretation. Number syntax keeps `one hundred and two` together. Quoted names retain internal `and` terms. This is not an unconditional string split.

The implemented action families cover product search, cart add/remove, order creation/repetition/cancellation, checkout and delivery modification. Existing dictionary cart action aliases are reused. Preparation actions precede order creation/checkout, even when “create order” appears first in the text. Delivery modifiers attach to the overall request/order. Each item operation lists its `itemIndexes`; consumers must not add every mentioned item indiscriminately (a search and a removal can mention products too).

Connected actions with clear arguments can resolve together. Alternatives such as `create an order or cancel my order`, or opposing actions without distinct arguments, remain ambiguous. A known order request with an unresolved address remains `NEEDS_CONTEXT` and retains its items/primary intent.

## Context and references

Accepted context fields:

- `pendingRequest`: previous unresolved text, maximum 4,000 characters.
- `selectedItems`: at most 50 product descriptors with optional quantities/units.
- `orderReference`: explicitly selected prior-order reference.
- `deliveryAddressReference`: selected address label/reference.
- `referenceDate`: valid ISO calendar date for relative dates.
- `timezone`: valid IANA timezone name.
- Existing `collection`, `previousIntent`, and `states` fields remain available.

`it`, `that`, `them`, `same` and related product pronouns can refer to prior clause products or explicitly supplied selected items. `there` and “same address” require an address context. LAST/SAME order references need an order reference; the engine does not query customer order history. Short product, HOME/WORK and numbered-order answers can complete a pending request while preserving its other details. Context is stateless on the server: each client owns and sends its next context. Unknown fields, invalid quantities, oversized context and invalid dates/timezones are rejected by the HTTP boundary.

Context is interpretation data, not a signed customer session or authority to execute. A connected commerce adapter must revalidate real product/address/order ownership and current business rules.

## Dates and times

Current parsing supports ISO dates; today, tomorrow, tonight and day-after-tomorrow; named day periods such as morning; and explicit clock ranges such as `between 9am and 11am` or `from 09:00 to 11:00`. Relative dates become absolute only with `referenceDate`. Morning stays a named period: it does not invent a merchant's pickup or delivery window.

Invalid dates, invalid/reversed clock ranges and bare ambiguous ranges such as “between 9 and 11” require clarification. Timezone labels carry supplied store context; this parser does not perform fulfillment calendar admission, DST promise calculation or capacity reservation.

## Limits and compatibility

- English deterministic grammar, not a complete natural-language parser. Unsupported action syntax retains the legacy classifier or asks for clarification.
- Unquoted coordinated product names and complex modifiers can remain linguistically ambiguous. Use explicit item counts or quote compound names; there is no live catalog disambiguation inside this engine.
- At most 32 parsed action clauses and 50 items are admitted as a complete semantic request. Larger requests are marked incomplete rather than silently accepted as truncated plans.
- Short context replies currently fill product, address and order-reference questions. Other edits may require a complete restated request.
- Simple legacy requests retain their old fields and scores. Supported compound requests intentionally replace the old blanket `MULTI_ACTION` rejection with `COMPOUND` graphs. Conflicting alternatives still abstain.
- The Python assistant recognizes `COMPOUND` before the direct-reorder branch and returns review guidance. Parsing several actions never grants batch execution authority.
- Grammar confidence is heuristic. Legacy score/debug diagnostics describe the flat classifier and must not be mistaken for measured accuracy of the semantic graph.

## Source map

- [Clause grammar](../../commerce-language-engine/src/semantic-clauses.ts)
- [Item and delivery extraction](../../commerce-language-engine/src/semantic-entities.ts)
- [Reference/relationship orchestration](../../commerce-language-engine/src/semantic-request.ts)
- [Structured types](../../commerce-language-engine/src/semantic-types.ts)
- [HTTP context validation](../../commerce-language-engine/src/context.ts)
- [Legacy/semantic composition](../../commerce-language-engine/src/engine.ts)
- [Saved context demo](../../commerce-language-engine/scripts/context-demo.ts)
- [Semantic regressions](../../commerce-language-engine/tests/semantic-request.test.ts)
- [HTTP round-trip test](../../commerce-language-engine/tests/semantic-http.test.ts)
