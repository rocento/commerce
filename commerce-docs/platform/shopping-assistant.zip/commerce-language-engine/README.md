# Commerce Language Engine

The engine now exposes a structured semantic request alongside its legacy intent fields. It understands supported combinations of actions, item quantities, delivery details and conversational references without a model call.

- [Run locally and test multi-message conversations](local-run-and-test.md)
- [Semantic JSON contract, architecture and limits](semantic-requests.md)
- [How the shopping assistant uses the engine](../shopping-assistant/03_language_engine.md)
- [Existing deployment integration](../commerce-language-engine-integration.md)

Implementation date: 22 September 2026. This extension was implemented and tested locally; it has not been deployed by this task. `RESOLVED` means the request was understood, not that commerce operations ran.

## Recorded local verification

On 22 September 2026, all **106 engine tests** and **81 selected Python language-gate/assistant tests** passed. The engine tests include a real temporary HTTP-server context round trip, the supplied compound examples, chained missing fields, quantity bindings, pronouns, date/time cases, limits and existing classifier regressions. TypeScript and changed-file Ruff checks passed. Documentation links were checked. These results do not qualify production deployment, live commerce execution or general language coverage.

See [all 20 database tables, multi-sentence/context handling and the UNKNOWN-only LLM policy](database-and-context.md).

UNKNOWN-only routing follow-up: **172 Python tests passed** across language gate, assistant HTTP/SSE, shopping and runtime suites. Changed Python files passed Ruff. The local context demo passed again. Known, low-confidence, unsupported and unavailable engine cases are covered, including explicit basket mode; existing UNKNOWN model journeys remain covered. No production deployment was performed.
