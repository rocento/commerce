# Performance baseline — Stage 11

Architecture decision (2026-09-21): measure the Stage 10 publishing path before edits, using the same isolated database and production-built renderer for the Stage 11 comparison. Keep public documents uncached until precise invalidation has a demonstrated need and a verified design. Prefer measured query improvements and bounded admission over speculative caching. All measurements are synthetic local observations; historical pre-SEO field telemetry and production Web Vitals are unavailable and must remain explicit release-validation gaps.

The harness will report sample sizes, catalog/variant counts, HTTP timings and bytes, browser observations, gateway calls, process resource observations and bounded sitemap/feed work. Security tests will exercise two independent installation databases with deliberately identical resource identifiers and distinct private/public sentinels.

## Method and measurements

Environment: Apple M4 Pro, 24 GiB RAM, macOS arm64, Node 25.9.0, PostgreSQL 16 in Docker over loopback; exact versions in `Reports/evidence/stage11/environment.json` and `Tests/stage11/hardware.log`. Rust used the test/dev profile; React client and SSR used Vite production builds. This is not a release-build server capacity claim.

Data: 50,001 products, 100 product-family links, one category, one published CMS page and a published theme. The family sample stresses the bounded 100-item representation; it is not a full configurable-product or many-category workload. There is no primary image in this timing fixture. Separate privacy tests exercise real PNG bytes and image references. Database statistics were analyzed after seeding. Each of four paths received one warm-up and fifteen sequential measured requests per run. TTFB is client wall time through response headers, including local HTTP connection/client overhead. HTML is uncompressed response-body size. Every rendered page makes one gateway snapshot request; underlying SQL statements are not counted as separate API calls.

| Path | Before median / p95 ms | After median / p95 ms | Repeat median / p95 ms | HTML bytes, unchanged |
|---|---:|---:|---:|---:|
| Home | 10.89 / 18.80 | 10.83 / 18.54 | 11.77 / 18.41 | 29,422 |
| Product, 100 family links | 45.30 / 55.58 | 20.86 / 27.11 | 20.61 / 23.06 | 126,667 |
| Category | 9.09 / 10.18 | 10.21 / 10.84 | 9.28 / 9.91 | 23,285 |
| CMS | 7.96 / 10.53 | 9.11 / 22.44 | 7.92 / 8.32 | 10,738 |

The product median improved approximately 54%. Thirty repeated direct product lookups averaged 24.56 ms by slug / 25.14 ms by UUID before, versus 0.29 / 0.34 ms after. Separate indexed predicates remove the cast-and-OR scan while preserving UUID-first resolution and slug fallback. Existing unique slug and primary-key indexes suffice; no migration is required. Non-product timing variation did not persist in the repeat. These small samples do not establish statistical field percentiles or a sustained-load SLA.

For the same 68 renderer gateway calls (64 page requests including warm-ups, one sitemap index and three partitions), measured process CPU was 158.4 ms before and 165.1 ms after. OS process maximum RSS was 88,736 KiB before and 90,096 KiB after. These include Node bookkeeping and request handling, not isolated React CPU; they exclude PostgreSQL memory. The query optimization reduces database wait, not HTML/React workload. No material sustained regression was demonstrated; the CPU/RSS values remain observations, not universal budgets.

There is no public document cache: measured hit ratio is zero and all document responses are no-store. Assets retain their immutable build caching. The delayed-dependency probe previously admitted all 40 concurrent requests. With the test limit set to four, only four reach the gateway and 36 get no-store 503 responses with Retry-After: 1. Production defaults to 32 admitted dynamic requests per renderer; PUBLICATION_MAX_INFLIGHT accepts integers 1–256. Admission covers dependency/render work, not all TCP connections, static asset writes or global multi-process rate limiting. Liveness and static assets remain available; permits are released on every completion/error. Choose production limits with pool size and memory measurements.

At 50,001 products, the sitemap index contained 54 partition links and 7,687 bytes. After optimization it took 28.0 ms; three sampled partitions totaled 135,919 bytes in 23.4 ms. This measures bounded index/partition operations, not the whole sitemap download. The existing two-million-product test was explicitly run in Stage 09 and is not claimed as rerun here.

Three feed reconciliation/delivery batches processed 30 resources in 476 ms (repeat 438 ms), approximately 63–68 resources/s of active fixture work. The scheduler's one-second inter-batch pacing was deliberately advanced by the harness; this is not sustained worker throughput. Test-process RSS sampled after each batch peaked at 40,480 KiB, excluding the database and renderer. It is a sampled lower bound on peak memory, not a heap allocation profile. Feed jobs still cap each batch at ten; a complete 50,001-product feed rebuild was not benchmarked.

## Browser observations

Headless Chromium observed the real built documents through a fixed-host localhost proxy, with fresh contexts at 1440×1000 and 390×844, three loads per path (24 loads). There was no CPU/network throttling. The proxy only forwards to the fixed local renderer; the attribution endpoint is stubbed for this timing exercise. LCP was nonzero on every sample. Median LCP by page was 32–64 ms desktop and 36–48 ms mobile; maximum CLS was 0.000124 desktop and 0.010967 mobile. Raw per-load values are retained in browser-after.json.

The script focuses the hydrated search combobox and tabs away. Event Timing produced 32–48 ms interaction candidates. These are short lab interactions, **not field INP** or checkout/search workload results. Historical pre-SEO browser data was unavailable, so these are post-change observations only. No frontend rendering behavior was changed in Stage 11. Google's published LCP/CLS/INP guidance and percentile methodology are references for production validation, not a basis for calling these local results a field pass. [Web Vitals](https://web.dev/articles/vitals), [threshold methodology](https://web.dev/articles/defining-core-web-vitals-thresholds).

## Release validation gaps

Production release remains blocked on representative image-heavy/configurable catalogs, large taxonomies, production release builds and intended Node runtime, external CDN/network behavior, sustained concurrent traffic, full feed rebuild memory/throughput and real-user or representative throttled browser baselines. Historical pre-SEO telemetry cannot be reconstructed honestly from today's code. Obtain an agreed current-control baseline in the target environment before claiming no material SEO/GEO performance regression. Never substitute an empty legacy shell's fast response for useful-content LCP.
