# Merchant publication architecture

Stage 12A, 2026-09-22. **Implemented:** one authoritative public commerce view over existing catalog, merchant, content, pricing and media domains. It is not a separate SEO catalog. [Design](target-architecture.md), [public contract](public-commerce-contract.md), [implementation](../../backend/crates/api-gateway/src/public_commerce/snapshot.rs).

```mermaid
flowchart TD
  A[Catalog, pricing, approved merchant and CMS data] --> B[Installation-bound anonymous snapshot]
  B --> C[React server-visible storefront]
  B --> D[Metadata and JSON-LD]
  B --> E[Robots and canonical sitemaps]
  B --> F[Reference feed and reconciliation]
  G[Approved host and indexing policy] --> B
  C --> H[Hydrated browsing and private shopper navigation]
```

Each installation binds an approved HTTPS origin to its own gateway/database identity. Fixed upstreams and host checks precede publication. Node renders the same public React view for people and crawlers; private shopping/account flows use the existing client app. Dynamic output is no-store. The replica admission limit bounds active public rendering, not global ingress traffic. [Rendering](rendering-strategy.md), [host trust](domain-and-proxy-trust.md), [isolation](tenant-isolation.md).

Public prices use the existing evaluator where anonymous facts are supportable. Conditional prices, uncertain regional stock, private fields and unsupported identifiers/schema claims are omitted or conservatively described. Distinct eligible variants have their own canonical identities; CMS policy approval is bound to a published revision. [Facts](public-product-facts.md), [variants](variant-publication.md), [merchant identity](merchant-entity.md).

Media originals remain authoritative. Derived dimensions and quality-controlled WebP bytes are generated from originals; reference-based authorization governs public access. Existing stored images require explicit regeneration. Feed state/journals are rebuildable publication derivatives; five-minute scheduling is not a universal freshness SLA. [Images](image-publication.md), [feed operations](feed-operations.md), [Stage 11 image fix](../Reports/11-release-blocker-resolution.md).

**Verified:** local evidence and candidate regression results are indexed in the [Stage 12A final report](../Reports/SEO-GEO-final-report.md). **Partially verified:** this architecture's live operation. Deployment isolation, public-edge behavior and infrastructure rollback require [first-client validation](first-client-live-validation.md). No shared document cache, external feed transport or llms.txt publisher is claimed.
