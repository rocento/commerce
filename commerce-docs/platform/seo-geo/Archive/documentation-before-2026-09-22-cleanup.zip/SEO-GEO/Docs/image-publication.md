# Image publication

## Source and processing

Original bytes remain in private object storage under the existing media UUID. The public URL is `/api/v1/catalog/media/{id}/content`; optional `?width=480` or `?width=960` serves an actual WebP derivative only when its manifest entry exists. No filename, format, dimensions or derivative is guessed. Images narrower than a target are never upscaled. `srcset` includes available derivatives plus the original with its measured width; `sizes` distinguishes cards from detail/media content.

PNG/JPEG/WebP decoding is limited to 12000 pixels per axis and a 128 MiB decoder allocation budget. API uploads retain the existing 5 MiB cap. A semaphore bounds processing to two concurrent tasks. Derived manifests are written only after all derivative uploads succeed. Original upload success is retained on processing failure, with a server warning and an explicit retry path; the public renderer omits unprocessed images. Object-store outages can still prevent delivery after a snapshot, and are not silently represented as successful files.

New uploads attempt processing automatically. Existing images require `POST /v1/admin/catalog/media/{id}/publication` with an admin session, `X-Commerce-Request: 1`, an allowed Origin and catalog.write permission. The SEO image picker offers this action for the selected social image. Run this endpoint for every referenced legacy image before enabling the renderer in production. Repeating processing is safe because the existing media API does not replace original bytes. Alt text remains merchant-editable in the existing media library. Product/category names provide deterministic contextual alternatives when necessary.

The primary product image, or the first configured hero/content image, is eager/high priority. Other public images are lazy. Width/height reflect actual bytes. A missing product image has a labeled placeholder, and no missing image is advertised in social metadata. Missing logo processing falls back to visible merchant text.

## Access and crawlers

Anonymous eligibility is evaluated on every request from active products with active parents, category thumbnail/banner references, current CMS releases, the assigned published storefront theme, or an explicitly selected default social image. Unreferenced files require catalog.read. Public metadata clears object_key; private originals and variants require the same authorization. All media responses use no-store so revocation is not defeated by a new shared-cache entry. Pre-existing cached images require a one-time purge on rollout; already downloaded public media cannot be recalled.

Production robots adds a narrow allow rule for catalog image content beneath the existing API disallow. Other API paths remain disallowed, and protected environments retain their global disallow. The existing gateway/ingress API `X-Robots-Tag: noindex, nofollow` is retained: image fetching for page rendering/sharing is enabled, but standalone image indexing is not claimed. No user-agent bypass grants access to private files.

[Google's robots specification](https://developers.google.com/crawling/docs/robots-txt/robots-txt-spec) documents wildcard path matching and the precedence of more specific rules. Robots is crawler guidance; authorization protects private bytes. The merchant nginx config already proxies these requests to its fixed gateway. External CDN/WAF rules were not accessible or modified; deployment verification must fetch originals/variants as approved crawlers, confirm status/MIME/body, purge stale caches and verify private IDs fail without a session. Do not relax demo/admin protection.

## Migration and rollback

`20260921160000_publication_metadata.sql` adds presentation settings, image manifests and a read-only public-reference view. Existing catalog rows and originals are retained. Apply on an isolated restored database first, build matching server/client artifacts, process referenced media, and inspect all four public page types before rollout. Back up the new settings and manifests. Roll back application deployment as a unit while retaining additive tables; do not remove the private-media authorization fix. No production migration, backfill, cache purge or CDN change was performed in Stage 05.

Actual derivative bytes and private access are tested through the real catalog router against an isolated HTTP object-store fixture. That proves gateway behavior, not deployed S3/CDN operation. Reference lookup latency and codec throughput on a production-sized catalog remain partially verified.
