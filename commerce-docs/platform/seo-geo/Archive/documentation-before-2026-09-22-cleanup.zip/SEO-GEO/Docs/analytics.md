# Discovery attribution

Architecture decision: preserve the existing ClickHouse reports and six legacy source categories (`direct`, `search`, `social`, `email`, `referral`, `unknown`). Add a discovery evidence projection using the same `browse-session` UUID, rather than rewriting historical analytics or using shopping-assistant data. Detailed discovery channels are `organic_search`, `paid_search`, `social`, `email`, `referral`, `direct`, `unknown`, `ai_chatgpt`, `ai_google`, `ai_perplexity`, `ai_claude`, `ai_other`.

## Evidence and precedence

The gateway classifies observations; the browser cannot submit a channel or revenue. Explicit paid-search, email and social medium patterns take precedence, followed by an exact recognized AI referrer host, the documented ChatGPT UTM claim when there is no contradictory external referrer, generic `utm_medium=ai`, organic medium, recognized search/social hosts, other external referrals, unknown evidence, and direct/internal navigation. Hostnames are parsed, not substring-matched. Lookalike domains, URL credentials, unknown provider names and conflicting Google referrers do not establish a specific AI provider. Unknown AI campaign claims use `ai_other`; an unrecognized ordinary referring site remains `referral`.

A `referrer_host` label means a host matched the registry, not that a browser observation is cryptographically authentic. UTM-only provider attribution is explicitly `utm_claim`; campaign medium claims are `campaign`. All can be spoofed by a client. The admin table separates referrer-host evidence from campaign claims. These are observational analytics, never authorization or proof of a human/AI identity.

Provider evidence reviewed on 2026-09-21:

| Channel | Exact recognized hosts | Source |
|---|---|---|
| ai_chatgpt | chatgpt.com, www.chatgpt.com, chat.openai.com | [OpenAI publisher FAQ](https://help.openai.com/en/articles/12627856-publishers-and-developers-faq) documents `utm_source=chatgpt.com`; [ChatGPT search](https://openai.com/index/introducing-chatgpt-search/) identifies the product host. |
| ai_google | gemini.google.com | [Gemini web app](https://support.google.com/gemini/answer/14886647?hl=en). |
| ai_perplexity | perplexity.ai, www.perplexity.ai | [Perplexity product documentation](https://www.perplexity.ai/help-center/en/articles/10352155-what-is-perplexity). |
| ai_claude | claude.ai, www.claude.ai | [Claude account access](https://support.claude.com/en/articles/13189465-log-in-to-your-claude-account). |

Ordinary Google referrals remain organic search. AI Overviews and AI Mode are not separately inferred from them; Google includes those clicks in organic search. [Google channel definitions](https://support.google.com/analytics/answer/9756891?hl=en). Other providers' UTM aliases are not invented.

## Sessions and conversions

A browser-tab session shares the existing UUID and rotates after 30 minutes without a tracked event. First touch is the first accepted observation. Last touch updates on later non-direct observations, using server ingestion order; direct/internal navigation does not overwrite it. Anonymous sessions are not joined across devices or retroactively associated with customer profiles.

A checkout callback may link an order only with a verified customer token, matching order ownership and an order created within 24 hours. It freezes first/last touch and the session's AI-observed flag. The order ID is unique in the attribution table: retries cannot double count or replace attribution. Browser-supplied revenue is not accepted. The callback is best effort; ad blockers, disabled JavaScript, missing authentication, blocked storage and lost callbacks cause undercounting. This is not a complete financial ledger or causal conversion measurement.

“AI-attributed” means the frozen last non-direct channel is one of the AI channels. “AI-assisted” means an AI channel was observed at some point before linking that order. It is an overlapping subset, never a number to add to attributed conversions. No assistant interaction, conversation or model data is consumed.

Conversion count uses linked orders except cancelled/delivery-failed orders. Revenue uses actual collected payment amount minus recorded refunds, grouped by currency. Uncollected orders contribute zero collected revenue. Money still collected on a cancelled order remains in net collected revenue until refunded; this is cash measurement, not booked sales. Revenue access additionally requires `reports.read`; discovery permission alone cannot read it.

## Privacy, windows and coverage

The browser sends only the referrer origin, public landing path and three allowlisted campaign tokens. The gateway stores only a parsed host, never referrer paths, query strings or fragments. Tokens are limited to 80 ASCII alphanumeric/dot/underscore/hyphen characters; email-like values are dropped. Do not put personal data into campaign labels. No customer identity, IP, address, query text, credential or chat content is added to discovery events.

Canonical 301s preserve campaign claims in a `Secure; SameSite=Lax; Path=/` cookie lasting at most 120 seconds. It contains only sanitized campaign tokens and referrer origin. The first hydrated page consumes and deletes it; it carries no session/authentication identifier. It is an untrusted claim, and simultaneous redirects in different tabs can compete for this short-lived cookie. GPC/DNT requests do not set it. Both new and legacy browser tracking respect browser GPC/DNT signals. No new consent-management system is introduced.

Accepted discovery observations use PostgreSQL within the existing installation database. An hourly worker deletes discovery rows at 90 days, matching the existing browser analytics retention window; cascading session removal also removes linked attribution rows. It does not delete commerce orders or payments. UTC rolling windows accept 1–90 days (default 30); the admin view uses 30 days. Session trends use session creation date; conversions use order creation time. Top products count distinct observed sessions per public product path. No extrapolation is applied to unobserved traffic. Do not add the legacy report's sessions to discovery sessions: they are overlapping views.

## Stage 12A reconciliation — 22 September 2026

Candidate classification, attribution/privacy and health regression results are indexed in the final report. Historical provider-source verification dates remain unchanged. Browser-reported referrers and campaign claims remain observations, not authenticated provider identity or causal revenue attribution. Live client traffic coverage and external alert delivery are not certified. See the [final report](../Reports/SEO-GEO-final-report.md), [architecture](architecture.md) and [operations](operations.md) for current acceptance scope and first-client gates.
