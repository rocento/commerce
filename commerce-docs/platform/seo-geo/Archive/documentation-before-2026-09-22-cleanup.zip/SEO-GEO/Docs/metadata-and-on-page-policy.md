# Stage 05 architecture decision

The existing repeatable-read publication snapshot will resolve metadata from current catalog/CMS facts, existing discovery identity, and revisioned optional presentation settings. The authenticated preview calls the same assembler with proposed settings. Canonical and robots remain owned by stages 04 and 02. Settings use discovery.read/write, optimistic revision checks and transactional audit. Overrides bind to stable resource IDs, never historical slugs.

Images will expose only public references from active catalog items, published CMS releases and assigned published themes, or explicitly selected social images. Private originals require catalog.read. Image dimensions and bounded WebP renditions are derived from actual bytes; legacy media requires regeneration before dimensioned public rendering. Public HTML uses a shared image component, and no fictitious image fallback.

Public theme rendering uses a dedicated primary heading and subordinate section headings; category ancestry and bounded same-category recommendations use real anchors. Existing private storefront behavior remains separately supported.

## Resolution and editing

Existing SEO identity controls own the site name, default description and locale. Save those changes before previewing metadata. The new section owns four page-type title/description templates, one default social image and optional product/category/CMS overrides keyed by stable UUID. It uses discovery.read/write, CSRF/origin checks, optimistic revisions and `discovery.metadata.updated` audit events. Media processing additionally requires catalog.write. The image picker requires catalog.read.

Resolution is nonblank resource override → expanded page-type template → factual default. Product/category names and descriptions come from the public catalog; content descriptions use the first nonblank published block; absent descriptions use saved merchant description. Home title is the merchant name; other defaults are `{page_name} | {merchant_name}`. Page 2 and later append a page number. Blank values fall back, not to marketing claims. Allowed tokens are page_name, product_name, category_name, content_title, merchant_name, description and default_description. Expansion is single-pass; braces inside merchant data remain data.

The optional title guidance is 60 Unicode characters and description guidance 160; resolved text is never sliced. Inputs have a 2000-character ceiling and reject control characters, unknown template tokens and unknown resource IDs. At most 500 overrides are accepted in this bounded initial settings document. Large-catalog pagination of override administration is a future enhancement.

Preview resolves proposed metadata settings against currently published catalog/content and saved identity in the same snapshot assembler used by production HTML. It does not publish drafts. Preview is a point-in-time result; a concurrent catalog edit can legitimately change the next response. Error pages have an error title and no canonical/social claims.

The Node head writer escapes all attributes and text, emits one title/description/robots/canonical, uses the Stage 04 canonical for og:url, and emits OG title/description/type/site name plus Twitter summary title/description. An image is emitted only with a known dimensioned media record; fallback tries product, category, published content images, then default social image. No country is inferred from a language-only locale; `ar-EG` can emit `ar_EG`. No account handles, product claims or rich-result promises are invented.

Public themes use one page h1, subordinate hero/section headings, text descriptions, labeled specifications, real anchors and labeled search/navigation. Their private editor/storefront rendering remains supported. The public home does not use the built-in stock apple photograph when a merchant has supplied no image.

## Sources checked 2026-09-21

[Open Graph protocol](https://ogp.me/) defines the emitted core and image properties. [Google image guidance](https://developers.google.com/search/docs/appearance/google-images) supports descriptive alt text and discoverable image sources. These references do not guarantee search or social display. The legacy official X card documentation URL redirected to [X's overview](https://docs.x.com/overview); current external X rendering was not verified. The emitted Twitter summary tags are covered locally, not represented as an observed X preview.
