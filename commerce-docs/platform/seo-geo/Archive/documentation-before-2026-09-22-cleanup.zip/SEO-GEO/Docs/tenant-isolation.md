# Tenant isolation — Stage 11

Rocento's current publishing model is installation isolation: one configured database, gateway/renderer binding and private media-store scope per merchant installation. It is not a shared-table tenant_id architecture. The gateway verifies the persisted installation UUID at deployment setup and again on publication paths; the renderer validates snapshot installation, origin and schema. Canonical URLs come from approved policy, never forwarded request headers.

The Stage 11 matrix creates two migrated PostgreSQL databases and two real HTTP renderers. Both contain identical product/category/media/CMS IDs, product slug apples, SKU APPLE, locale en, and identical attribution event/session IDs. Public names, merchant entities, descriptions, images and attribution channels deliberately differ. Test-only local object stores return different real PNG bytes for identical object keys.

| Surface | Proof |
|---|---|
| Page HTML, title/description/canonical, JSON-LD | Four page types per merchant contain their own sentinels and approved origin; foreign sentinel/origin and private data absent. Product hostile markup remains escaped and inert in Chromium. |
| robots.txt | Each response names only its own approved sitemap origin. |
| Sitemaps | Index and partitions are fetched separately; inactive product excluded and locations remain in merchant scope. |
| Redirects | Identical old slug resolves to the local canonical path; wrong host receives 421. |
| Feeds | Independent workers/export watermarks contain only that installation's current public facts; withdrawal in A does not alter B. |
| Images/media | Identical media IDs project different own alt text; actual API content decodes to each store's distinct PNG color. Private media gets 401 before object-store access. |
| Merchant entity/policies | Same document/revision IDs produce each merchant's entity and approved pages; unpublished contact/address excluded from public output. |
| Health/analytics/admin settings | Each own session can read its installation; the other installation's session gets 401. Identical analytics IDs remain separate; A records ChatGPT and B Claude. Foreign sentinels/origins are rejected in own admin responses. |
| Cache/background work | Dynamic responses are no-store; A withdrawal immediately changes its HTTP result to 404 while B remains 200. Worker task interruption and restart use durable state; no process-global cross-tenant public cache exists. |

Raw evidence: Reports/evidence/stage11/tenant-matrix.json, tenant-A-snapshot.json, tenant-B-snapshot.json and browser-xss.json. Tests: publication_hardening.rs plus retained policy/rendering/discovery/feed/media/measurement regressions. Evidence is synthetic and contains intentional attack strings, not real customer data.

Deployment validation must separately prove host ingress routing, installation UUID, database credentials and isolated storage scope. A shared object-store endpoint/bucket without installation namespacing violates this model. No test can make that unsupported configuration safe. Production infrastructure validation and cross-replica testing remain partially verified.
