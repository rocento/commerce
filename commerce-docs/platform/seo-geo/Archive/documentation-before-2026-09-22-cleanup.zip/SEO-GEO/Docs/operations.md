# Merchant publication operations

Stage 12A, 2026-09-22. This is an operator procedure; **Blocked** live steps await the first client's agreed environment and named operators. Follow the [pilot plan](first-client-live-validation.md) and [deployment handoff](stage11-deployment-handoff.md).

## Candidate and rollout

Select exact source/dependency bytes and retain the last working gateway/client/SSR set. The current Stage 12A candidate is a separately assembled working-tree snapshot, not a deployable Git-only baseline. Consult its [source manifest](../Reports/evidence/stage12a/candidate-source.json) and [reproduction notes](../Tests/stage12a/README.md). Never assume unrelated current workspace changes were covered by an older passing test log.

Build matching storefront client/SSR artifacts and seal them together. Startup rejects mismatched template/SSR hashes. Use intended Node 22, bind the fixed gateway and approved installation/origin, mount artifacts read-only, supply matching private observation tokens and retain noindex for the new prelaunch surface. Existing live store routing/indexing stays unchanged during isolated pilot preparation. [Runtime entry](../../frontend/apps/storefront/server/start.mjs), [overlay](../../compose.publication.yaml).

Run the read-only deployment preflight on the actual host before opening access. Independently inspect external DB/object-store IAM and public DNS/TLS/CDN/WAF behavior. A local or empty inventory cannot pass a real host gate. Noindex is not access control. [Preflight procedure](../Tests/stage11-release/README.md).

## Health, freshness and media

Check renderer `/health` for liveness and `/ready` for snapshot readiness; inspect authenticated discovery health for evidence/remediation. Health checks sample content and do not certify every product or edge route. Private probes use the fixed target and secret; retain noindex/no-store for APIs. [Health engine](health-engine.md), [observability](observability.md).

Inspect bounded feed job progress, retry/dead-letter conditions and generation/cursor movement. Reconcile create, price, availability, image and withdrawal changes against pages, JSON-LD, sitemap and reference feed. Full exports pin a watermark and apply tombstones. Keep failed-item diagnostics redacted; avoid claiming a five-minute full-catalog SLA. [Feed operations](feed-operations.md), [freshness](publication-freshness.md).

Regenerate existing image derivatives in bounded sequential batches through the own-installation authenticated media publication endpoint. Preserve original bytes, record outcomes and verify displayed dimensions/quality/bytes. Stop on repeated processing failures and retry explicitly. [Image procedure](../Tests/stage11-release/README.md).

## Failure and rollback

A false fact, cross-tenant leak, private-data exposure, incorrect canonical/status, failed noindex safeguard or material unexplained regression stops advancement. Restore the retained matching gateway/frontend release through the agreed deployment procedure, preserve additive schema/feed state and check public and protected paths again. Do not drop tables or attribution records as a rollback shortcut. [Failure contract](failure-and-rollback.md).

Run destructive outage/saturation and overlapping-tenant fixtures in an isolated synthetic copy. Verify actual infrastructure switching and recovery in the agreed client pilot window without active-order disruption. Local proxy switch tests and prior-renderer compatibility are evidence of application behavior, not proof of a real CDN or infrastructure rollback.

## Live evidence and release decision

Assign names and calendar dates to the [first-client checklist](first-client-acceptance.md) before pilot admission. Store redacted evidence with candidate/configuration identifiers and sample provenance. Public indexing/cutover and broader release are separate recorded decisions. Mandatory unverified live safety gates keep the public/general release recommendation NO-GO; local regression success alone cannot change it.
