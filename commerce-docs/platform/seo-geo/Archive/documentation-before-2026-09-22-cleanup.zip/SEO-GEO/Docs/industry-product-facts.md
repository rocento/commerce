# Industry product facts — Stage 08

Product pages and comparisons use the existing catalog, pricing resolver and merchant-defined public attribute labels. They never inspect private attribute values, pending enrichment suggestions, uploaded private files or hidden nested metadata. Values explicitly recorded with AI_INFERRED or DERIVED provenance are excluded; merchant, verified and legacy merchant-maintained values remain eligible. Eligibility is not a guarantee that a merchant-entered statement is true.

| Industry | Useful merchant-supported facts | Do not infer |
| --- | --- | --- |
| Grocery | Ingredients, pack/unit, storage instructions | Dietary certification, allergen absence, unrestricted availability |
| Jewelry | Material, purity, dimensions, care | Hallmarks, laboratory certification, investment value |
| Fashion | Material, size and fit guidance, actual variants | Universal sizing, sustainability certification |
| Skincare | Ingredients, merchant label usage, care | Medical efficacy, diagnosis, treatment or safety guarantees |
| Electronics | Model specifications, compatibility, warranty page | Compatibility not in catalog, certifications, warranty duration |
| General retail | Capacity, dimensions, materials, care | Brand identifiers, ratings or return promises absent from data |

Visible labels and `<dl>` specifications provide stable anchors; comparisons use row and column headers and explicit missing-value text. Existing family links remain independently canonical. Prices use the same eligibility and conditional-promotion behavior as Stage 06. Delivery and availability retain the existing location-sensitive caveat.

Admin coverage is deliberately diagnostic: configured industry profile, each visible definition's label, sampled active products and sampled products with an eligible public nonempty value. The sample is the first 1,000 active product IDs, with up to 100 visible definitions. It does not measure all inventory, verify claims, or assign a vanity score. Required-attribute and full-catalog analytics remain with the existing catalog schema tools.

Regression fixtures exercise grocery, jewelry, fashion, skincare, electronics and retail labels. The representative Stage 08 merchant additionally publishes grocery and jewelry products, compares two rings and proves an explicitly AI-inferred health claim is absent from public HTML, snapshot facts and structured data.
