# Failure and rollback — Stage 11

The safe degraded state is unavailable or omitted public claims, never another merchant's data or an unverified stale offer. Dynamic HTML, discovery APIs, media responses and findings retain no-store behavior. Cached immutable assets are identified by the build; they are not product-data caches.

| Failure | Behavior and evidence |
|---|---|
| Snapshot/database blocked | PostgreSQL table-lock fixture reaches the statement/request deadline, returns 503 with a fixed noindex page and no product/SQL details; releasing the lock restores 200. |
| Renderer/gateway unavailable or malformed | Existing bounded transport/deadline tests and health checks return 503/findings; no stale public document is substituted. |
| Excess dynamic concurrency | Reject work beyond PUBLICATION_MAX_INFLIGHT with 503, Retry-After: 1, no-store and noindex; liveness remains available; subsequent work succeeds. Default 32, validated range 1–256. |
| Host/installation mismatch | Fail closed through approved Host, database binding and snapshot identity checks. Never fall back to another tenant. |
| Product withdrawal/stale prior output | No document cache; next HTTP read returns 404/410 as policy dictates. Feed export/delivery rechecks eligibility and tombstones withdraw old entries. |
| Feed interruption/restart | Persisted generation/cursor/version, bounded batches, duplicate/out-of-order protection and retry/dead-letter rules from Stage 09 remain in force. Stage 11 interrupts a worker task and resumes against the same durable state. |
| Partial feed item failure | Existing regression proves invalid/permanently failing items are isolated, transient retries bounded and repaired replacements proceed. A malformed snapshot can still stall its reconciliation batch; report and repair it rather than publishing invented facts. |
| Mixed deployment artifacts | Startup refuses template/server hash mismatch before listening. The prior committed Stage 10 renderer was exercised against current schema-v1 snapshots and built artifacts; dependency failure gives 503 and recovery gives 200. |

Stage 11 introduces no database migration, API schema change or stored representation change. Local rollback compatibility is verified for the Stage 10 renderer source and current schema-v1 snapshot. The rollback fixture uses unchanged helper modules; it is not a cloud rolling-deployment exercise. Retain the previously deployed gateway image and matching client/template/SSR artifact set before release. Roll back the renderer/gateway pair through existing deployment tooling, keeping database state and feed journals intact. Do not delete attribution rows or feed state to roll back query/admission behavior.

Before changing traffic, validate the approved origin/installation binding, /ready, one public page, a real missing-page status, robots/sitemap, media access and protected admin health. Keep deployment noindex protections until the approved production policy is deliberately enabled. If rollback restores the prior unbounded renderer, compensate with existing ingress concurrency/rate controls while the fix is reviewed; do not silently accept renewed overload risk.

Production rollout, ingress/CDN cache purging, infrastructure rollback, multi-process saturation and disaster recovery remain unverified. Production release requires target-environment evidence and the performance/storage checks in performance-baseline.md and security-and-privacy.md. No deployment was attempted in this stage.
