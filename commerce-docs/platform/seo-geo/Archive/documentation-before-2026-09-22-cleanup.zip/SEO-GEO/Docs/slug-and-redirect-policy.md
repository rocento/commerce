# Stage 04 slug lifecycle decision

Decision recorded before implementation: installation-local, stable-ID route history, maintained transactionally by PostgreSQL triggers so domain writes and imports cannot omit history. Products and categories have separate namespaces. Current/previous slug and legacy ID aliases reserve the same resource identity permanently; resolver reads its current slug, collapsing rename chains without rewriting every alias. Physical deletion leaves reservations but returns 404 unless an explicit approved 410/replacement rule exists. Reusing another resource's old slug is rejected.

Normalize English/Latin diacritics and Arabic using a fixed, deterministic transliteration table to lowercase ASCII words and hyphens. Remove Arabic vocalization/tatweel. This policy supplies URL labels, not translations. Unsupported-script-only names receive a resource-prefixed stable-ID fallback. Explicit merchant slug overrides remain supported; blank slug generates from name. Auto-generated collisions receive a stable UUID suffix; explicit collisions fail. Name changes do not silently change a nonempty slug.

Canonical public paths have no locale prefix: only the installation's actual configured default content locale is published. No invented translations or hreflang variants. Existing ID APIs remain unchanged. Public ID document URLs redirect to slugs; the explicitly private `?shop=1` legacy purchase view retains its ID because the existing app uses that ID in APIs.

Approved Stage 03 route overrides remain operator-controlled; Stage 04 resolves replacement paths to live resource identities and emits only the final destination. Cycles, dead destinations and excessive chains fail closed. Canonical paths cannot be retired/redirected through a conflicting alias to evade resource retirement. All publication documents remain no-store.

## Query and normalization decision

Resolve the resource before sending a normalization redirect, so case, trailing slash, encoded ASCII, legacy ID and rename history collapse into one 301. Decode once; reject encoded separators, dot segments and malformed paths. Public `page=1` is omitted; valid listing pages above 1 are self-canonical. Duplicate keys, unsupported filter/sort/variant parameters and unknown query keys return 404 rather than silently publishing a different selection. The existing `/search` interface retains filtering/search behavior and remains private/noindex with no public canonical. Known tracking keys are removed by 301 after resource resolution; future attribution capture must happen before this redirect.

The `lang`/`locale` query may only repeat the installation's current default locale; it is then removed. Unsupported locale paths/queries return 404. Distinct, active child products receive their own canonical slug; option selection belongs to the private purchase view.

## Normalization and ownership details

`platform.public_slug` applies Unicode NFKD, removes Latin combining marks and Arabic vocalization/hamza combining marks/tatweel, applies the checked Latin/Arabic map, collapses non-ASCII-word separators and trims hyphens. The base is limited to 100 ASCII characters. Reserved route words and UUID-shaped overrides receive a product/category prefix. Generated-name collisions append the full stable UUID without hyphens; this is a collision/fallback mechanism, not the preferred public route for ordinary names. A merchant can supply an explicit meaningful override.

`platform.publication_aliases` has a primary key on `(resource_kind, route_key)`, scoped by the installation's own database. There is no cross-installation lookup. Alias values are lowercase, including migration-era values. Existing ID aliases and historical slugs remain reserved after deletion. New slugs also cannot take an existing approved redirect/retirement route. Explicit duplicate overrides return the existing API's conflict response (409); generated collisions use the suffix. Catalog attribute codes retain their existing validator.

BEFORE INSERT/UPDATE OF slug triggers use the catalog's existing transaction advisory lock (2002). Name-only changes preserve a nonempty slug. Domain writes, raw imports and upserts therefore share normalization/history rules; aliases and the entity update roll back together. Published resource eligibility is checked when resolving, never inferred from an alias row. Automatic history uses resource IDs and consequently has no rename chain. Explicit operator replacements are followed with cycle detection and a 16-visit bound, and only the final live route is emitted.

Missing, inactive or physically deleted resources return 404. A 410 remains an explicit decision in `platform.publication_routes`; no deletion history is fabricated. For installation-wide retirement/replacement, operators must review and record every intended alias when the entity is already missing. If a live resource's canonical route is overridden, aliases resolve through that decision. Retained alias rows prevent a newly created product from impersonating a deleted one.

## Migration plan

1. Back up the installation database and record the current release, discovery settings, slug/ID exports and existing approved route decisions. Rehearse on a restored database before deployment; do not point tests at a merchant database.
2. Audit duplicate lowercase spellings, normalization collisions, UUID-shaped slugs that conflict with another record's legacy ID, and conflicting approved routes. Existing ASCII catalog validation normally avoids many of these cases. Explicit ambiguities must be repaired by an operator; migration does not guess which product owns an old URL. Previously unsupported non-ASCII URLs are not promised as aliases; their stable ID URLs remain the compatibility route.
3. Apply `20260921110000_publication_slug_history.sql` through the existing SQLx migration runner. In the migration transaction, reserve existing spellings first, install the normalization/history triggers and backfill current slugs plus ID aliases. A collision aborts the entire migration. Existing catalog uniqueness constraints remain in place.
4. Deploy matched Stage 04 gateway/renderer/client artifacts with the normal publication build/seal. Keep the deployment noindex override until host, canonical, direct/legacy/renamed paths, private purchase flow and current merchant themes pass verification.
5. Verify representative canonical 200 responses, single-hop ID/history 301s, deletion decisions and absence of foreign origins at the real TLS/CDN ingress. No production migration or deployment was performed during development.

## Rollback plan

Prefer preserving the additive database schema/history and fixing forward. The fast safety rollback is to retain noindex and disable public publication while leaving authenticated commerce APIs available; route management and database recovery require an operator's deployment controls. Restore matched application artifacts rather than mixing gateway/renderer contracts. Reverting to the Stage 03 resolver loses automatic historical-slug resolution, so it is not a transparent SEO rollback after new URLs have been published.

Do not delete alias history, rewrite SQLx migration checksums, or restore an old whole database over subsequent commerce writes. Before any post-traffic reversal, export the alias table and route overrides and prepare equivalent redirects. Exact data rollback is appropriate only on a restored rehearsal database or before intervening writes, using the pre-migration backup and an explicitly reviewed migration procedure. The test suite rehearses migration from pre-stage rows, collision abort, and transaction rollback; it does not perform production backup restoration.
