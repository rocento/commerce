# Stage 02 indexing policy

Architecture decision before implementation: add one Rust policy resolver, immutable deployment configuration and a stable installation identity. Preserve the existing discovery configuration API; add an authenticated effective-policy endpoint. Admin renders the server's decision without recomputing it.

Stage 02 uses an opt-in gateway HTML shell adapter to apply policy to actual initial HTML and headers before Stage 03 introduces SSR. The adapter reads a configured built storefront index at startup; it does not render products or introduce a separate SEO document. Existing demo/static deployments remain protected by their existing proxy headers. A dedicated production-merchant proxy configuration forwards HTML and robots to the policy adapter, while serving assets statically. No deployment or production indexing is enabled by this change alone.

Private routes and APIs remain non-indexable. Host selection is an exact operator-controlled allowlist; forwarded headers never select an installation or canonical. Dynamic policy is read on each request with no-store. The configured deployment override is authoritative; external CDN behavior is explicitly unobserved rather than falsely reported as verified.

## Implemented resolver and precedence

`backend/crates/api-gateway/src/public_commerce/policy.rs` owns the policy. Precedence is protected environment, missing runtime configuration, unverified/mismatched canonical origin, deployment noindex override, merchant preference, then INDEXABLE. All non-indexable outcomes emit `noindex, nofollow`; INDEXABLE emits `index, follow`. These are origin eligibility decisions, not proof of search-engine indexing.

The authenticated `/v1/admin/discovery/effective` endpoint returns the saved settings revision, installation UUID, merchant preference, state, publication environment, verified canonical origin, origin header/meta policy, robots text, deployment override and actionable warnings. `external_headers=NOT_OBSERVED` is always explicit: no request is made to arbitrary merchant URLs and no unsupported claim is made about CDN headers. The UI renders this endpoint directly, refreshes after saving and polls every 30 seconds. Unsaved form edits do not represent effective state. Existing settings request/response shapes are unchanged.

Every settings write keeps discovery.write, expected_revision and transactional audit/outbox behavior. The router now also applies the existing request-header/origin policy. Effective reads require discovery.read. Canonical settings accept only root public HTTPS DNS origins and, when provisioned, must match the operator-approved origin. Generic demo link fields keep their prior validation.

## HTTP behavior

The opt-in gateway adapter reads a built storefront `index.html` at startup, inserts exactly one robots meta before `</head>` and emits the matching X-Robots-Tag. Policy/settings are freshly read from the installation database for each HTML request; responses use no-store. Requests to the home page and single-segment product/category/CMS routes can receive the public policy. Query-bearing, private and other client routes remain noindex. Unknown API routes are 404, never HTML. Wrong/missing/duplicate authority is 421. Missing template/database errors are non-indexable 503. Internal APIs/health/metrics/OpenAPI also receive noindex from the main gateway middleware.

This is still the existing client-rendered shell. Actual product rendering, resource existence checks and replacing unknown client-page soft-404 behavior belong to Stage 03; no SEO completion claim is based on the shell. Stage 04 owns page canonical tags and aliases. Existing demo/admin static vhosts retain their noindex headers.

Production robots.txt allows crawling so a newly disabled merchant page's noindex can be observed; it disallows `/api/`. Protected environments return `Disallow: /` in addition to noindex HTML. This is a general policy, not provider-specific bot access or the full Stage 07 discovery feature. Robots directives are not authorization.

## Opt-in deployment sequence

No existing deployment was changed or restarted during implementation. Use an isolated production-like fixture before any merchant rollout.

1. Apply the additive migration through the normal gateway deployment. Query that installation's database: `SELECT installation_id FROM platform.publication_installation WHERE singleton;`. This is a public-commerce identity independent of assistant identity.
2. Provision the merchant DNS/TLS mapping through the operator. Choose one approved production origin such as `https://shop.merchant.example/`; it must be an origin with trailing slash. Do not approve a host owned by another installation. The code treats the operator mapping as approval, not a DNS ownership probe.
3. Build the storefront and set `PUBLICATION_ARTIFACT_DIR` to its absolute built directory. Mount that same release into the gateway; serve matching `/assets`, `/brand`, `/fonts` and `/data` paths at the edge.
4. Set `PUBLICATION_INSTALLATION_ID` to the database identity, `PUBLICATION_APPROVED_ORIGIN` to the approved origin and keep `PUBLICATION_NOINDEX=true`. Add `compose.publication.yaml` only to the intended merchant project's existing Compose command, preserving that project's credentials, network and volumes. The overlay sets the explicit production publication environment and read-only index path; never use it with an admin/demo service.
5. Generate a reviewable storefront-only vhost with `python3 deploy/ec2/publication.py --host shop.merchant.example --gateway-port 8080`. Adapt only the port to the installation's existing private gateway. Install alongside the existing protected admin/demo configuration, validate Nginx syntax, and verify CDN cache bypass. The merchant vhost rejects a mismatched Host before forwarding any location.
6. Save merchant identity and canonical through Admin, enable merchant indexing preference, then verify the displayed deployment override still blocks it. After verifying the correct external host, set PUBLICATION_NOINDEX=false and restart only that merchant gateway. The settings then control origin HTML/header output per request.
7. Verify real external HTML, X-Robots-Tag, robots.txt and private/admin responses. A CDN-injected noindex is more restrictive and cannot be cancelled by an index meta tag. Do not treat the origin's INDEXABLE state as confirmation that an unobserved external CDN has been cleared.

Missing PUBLICATION_ENVIRONMENT defaults to development; noindex override defaults true. Production startup requires matching installation identity, approved origin and readable built index. Unsafe configuration fails startup instead of silently enabling publication. Existing API-only/demo installs retain protected defaults without configuring a template.

Rollback: re-enable deployment noindex first, return the affected merchant to its previous static release/proxy only after confirming noindex protection, and retain the additive identity table. Do not roll back by dropping installation identity or altering unrelated vhosts.

## Validation state

**Verified:** policy units, real local HTTP against built HTML, two separate databases, settings permissions/revisions/audit, protected environments, Admin state rendering, generated proxy checks and existing backend regressions. **Partially verified:** actual Nginx/TLS/CDN deployment and whole-workspace frontend checks; see the Stage 02 report. No production indexing was enabled.
