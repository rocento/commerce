# Product feeds

**Implemented:** `reference-v1`, a provider-neutral, installation-local feed adapter. It consumes the same anonymous public snapshot as the storefront. Authoritative products, pricing rules, approved attributes, measured images and canonical URLs remain in their existing domains. Publication state and the append-only delivery journal are rebuildable derivatives, not an editable SEO catalog.

Each event has `version`, `installation_id`, `item_key`, `product_id`, `operation` and `payload`. The item key is `installation:locale:market:product UUID`. Versions are increasing journal identifiers with permitted gaps; the snapshot's separate `representation_version` is SHA-256 of public content. Upserts cover both creation and updates. Deletes contain only identity and locale/market scope. Receivers must persist the greatest version for each item key; duplicate and older versions must not overwrite it. Keep tombstones when applying incremental exports.

Upsert fields include canonical URL, title, description, SKU, type, parent ID, variant dimensions, approved scalar attributes, eligible anonymous price/currency, price diagnostic, measured image and the exact public availability caveat. Conditional prices and products requiring selection have no feed price. Inventory internals, customer context, private attributes, object-storage keys and unpublished products are excluded. Public currency remains USD, matching the current checkout/database constraint. There is one configured locale and an explicit `default` market. A locale change deletes the previous locale identity before publishing the new one; it does not translate content.

The reference receiver validates item identity, version, scope, title and representation digest. Invalid items become `failed` with `invalid_item`; a corrected product emits a newer independent event. Delivery failures use a fixed redacted error code. No external credentials are needed by this adapter, and no credentials or provider response bodies are accepted in feed API inputs or serialized diagnostics.

## Exports

All endpoints use the existing admin session, `discovery.read`, installation binding, no-store and noindex policies. There is no anonymous feed URL.

- Full: `GET /v1/admin/discovery/feeds/export?full=true`. Start with an empty receiver map. Pin the returned `until`; continue with `full=true&until=...&key=<next_key>` while `has_more`. Each page contains at most 100 latest events per item at that watermark. Apply upserts and deletes.
- Incremental: `GET /v1/admin/discovery/feeds/export?after=<last_watermark>`. Pin `until` for that run; continue with `after=<next>&until=...`. Once complete, persist `until` as the next run's starting watermark.
- Full exports are a journal snapshot, not a globally locked catalog snapshot. A fresh publication check redacts withdrawn products/scopes to tombstones even when an older watermark is requested. Therefore privacy takes precedence over historical replay fidelity. Later changes arrive through subsequent incrementals.

The authenticated export exposes canonical queued events; delivery status describes the separate reference receiver. Export does not imply successful delivery. A production remote receiver would need its own delivery queue/cursor rather than sharing the reference receiver's acknowledgements.

## Provider extension boundary

`FeedAdapter` defines item delivery; `SubmissionIntent` reserves a separate sitemap/webmaster submission value. A concrete remote adapter must specify provider identity mapping, required fields, credential source, request timeout, quotas, idempotency and acknowledgement/reconciliation semantics, and pass contract tests before it is enabled. Current retry/savepoint behavior is verified for the local reference adapter only. A network adapter must use a lease/outbox boundary without holding catalog transactions or pretending that remote success is transactionally atomic.

**Not implemented:** Google Merchant, Meta, Search Console and IndexNow transports, provider credentials, externally downloadable feeds, provider approval monitoring or generated market prices. Missing global availability must not be fabricated merely to satisfy a provider schema.

Official requirements checked on 2026-09-21:

- Google Merchant API identifies inputs by language, feed label and offer ID and requires a configured API data source. Input acceptance does not imply product approval. [Add and manage products](https://developers.google.com/merchant/api/guides/products/add-manage).
- Search Console's sitemap submission uses a site property, sitemap URL and authorization. [Sitemaps: submit](https://developers.google.com/webmaster-tools/v1/sitemaps/submit).
- IndexNow requires host ownership verification with a key file; batch submissions are limited to 10,000 URLs. [IndexNow documentation](https://www.indexnow.org/documentation).

These references inform the boundary only. No provider submissions were performed, and no Meta adapter requirements are claimed to have been verified.

## Stage 12A reconciliation — 22 September 2026

The local adapter remains reference-v1; no external provider delivery is implied. Stage 11 recorded a full paced synthetic rebuild of 2,204 resources/2,001 product upserts, not a production throughput guarantee. Stage 12A reruns candidate feed consistency/recovery regressions; Stage 12B measures the actual first-client environment. See the [final report](../Reports/SEO-GEO-final-report.md), [architecture](architecture.md) and [operations](operations.md) for current acceptance scope and first-client gates.
