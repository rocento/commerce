# Canonical public commerce view contract

Stage 01 design specification. Stage 03 implemented the initial internal snapshot; Stage 04 implemented its canonical identity and alias lifecycle. Remaining fields below continue to describe later-stage targets. Use one typed Rust assembler and generated TypeScript contract. Existing domain objects are not the public contract.

## Context and envelope

`PublicContext`: stable commerce installation ID; approved canonical authority; channel; supported locale; currency; public region (`unspecified` initially); anonymous audience; environment policy. Server constructs this context from trusted configuration, never customer input selecting another installation.

`PublicPageView`: contract version; page kind; route outcome/status; canonical URL when permitted; effective indexing state/directives; merchant identity; page facts/content; anonymous published theme; metadata defaults/overrides; `evaluated_at`; public dependency revision/generation; `valid_until` at the next schedule boundary; non-sensitive diagnostics for missing optional data. Private diagnostics stay in admin/observability.

Canonical URLs are absolute HTTPS on the approved production authority. For nonproduction environments and invalid domain configuration, omit public canonical output rather than output localhost/demo/admin. Locale must describe actual content. Initially publish only the approved default content locale and USD supported by the schema; reject unsupported contexts. Future locale/currency variants require explicit content and authoritative price records, separate cache dimensions and tested alternate URLs. No invented translations, FX conversions or hreflang alternates.

## Field ownership and exposure

| Public field | Authoritative source | Publication rule |
| --- | --- | --- |
| Product ID, SKU, slug, title, description, unit, updated time | `domain-catalog` | Active eligible product only; escape text on output; IDs are stable internal references, slug is a route label |
| Category identity and ancestry | Catalog categories | Bounded acyclic hierarchy; do not infer category publication state from nonexistent active fields; only expose intentional public categories |
| Price and currency | Catalog base price; approved public pricing semantics from pricing domain | Decimal amount plus currency, no float arithmetic; describe base versus validated public offer explicitly |
| Availability | Inventory domain | Public state plus scope; no stock quantity, warehouse address, reservation/cart ID or promise of nationwide deliverability |
| Product type and variants | Catalog type/configuration/link records | Filter inactive children and nonpublic attributes; preserve variant identity, option labels and quantity relationships |
| Attributes/specifications | Approved active attribute definitions and product values | Strict allowlist of front-visible facts and separately authorized variant selectors. Unknown keys, inactive/private definitions and admin labels are excluded |
| Images and alt text | Catalog media | Approved public media URL and stored alt description; no object-store credentials, bucket key or signed admin URL |
| CMS content | `domain-cms::published` equivalent at captured time | Released title/blocks and revision only; no drafts, editor IDs, release internals or cancelled/expired material |
| Reviews and aggregate | `domain-reviews` | Only approved public reviews; approved aggregate computed over eligible set, not a page slice; no customer IDs or moderation reasons |
| Merchant name/domain/description/locale | Validated installation discovery identity | Stored default platform name is not proof of merchant identity; require merchant confirmation before rich merchant claims |
| Merchant policies/contact/legal facts | New approved merchant fields and published CMS references in Stage 08 | Explicit merchant-supplied public facts only, with stable policy page references and revisions |
| Theme | Published domain-theme version in anonymous context | No drafts, customer segments, preview credentials or personalized theme rules/data in the DTO |

Do not serialize orders, customers, addresses, carts, coupons, private prices, staff details, audit payloads, secrets, internal costs or exact delivery pins. Internal fields useful for invalidation stay server-side unless explicitly public. Query composition must never broaden access because an output is called SEO.

## Price and regional availability semantics

The current public product endpoint returns base price, while promotions may depend on cart/customer/coupon conditions. The initial view may expose that base price as visible base price. Emit an Offer only after its displayed amount is validated as the actual anonymous public purchase price under the declared context. Stage 06 should reuse/extract the pricing evaluator for unconditional catalog rules; do not copy pricing arithmetic into metadata code. If ambiguity remains, omit the offer markup/feed entry with a diagnostic rather than invent a discount or shipping/tax total. Checkout remains authoritative.

Use `availability = in_stock | out_of_stock | requires_location | unknown` with a public scope description. When area coverage is configured and no public region is selected, choose `requires_location` unless a defensible broader statement is explicitly derived. Do not equate aggregate warehouse stock with delivery eligibility. With no configured area constraint, inventory can supply its normal anonymous availability. A storage error is `unknown` or 503 according to whether the page remains truthful, never `out_of_stock`.

The public family view must work without a precise location: assemble active child descriptions/options and clearly scoped availability without invoking the current location-required family endpoint. Preserve delivery enforcement in cart/checkout. Future regional URLs use a finite merchant-approved public region identifier, never customer coordinates or address data.

## Variant and bundle representation

Simple SKUs are individual product facts. Configurable parents contain active child references and approved option labels; each child keeps its own authoritative price and availability. Parent range or aggregate offers require actual child facts and eligibility; do not advertise the parent placeholder price. Grouped items are a collection of separately priced products. Choice bundles preserve groups and quantities, but have no unconditional total until a valid selection is defined. Never fabricate a bundle-wide stock state.

Stage 04 keeps existing ID URLs accessible and adds installation-local slug history. A child with a genuine distinct public product page has its own canonical; selection-only parameters canonicalize to the family page when they do not define a separately published page. The canonical resolver, link builder, sitemap and feed must use the same decision. Stage 06 maps these facts to supported Product/ProductGroup constructs after checking current provider requirements.

## Merchant content references

Policies are typed references to approved published CMS pages (returns, shipping, warranty, privacy/contact as applicable), with source revision and locale. Missing policy information stays absent; never fill it from platform demo text or delivery fee assumptions. Policy expiry/unpublication invalidates all referring outputs. CMS may support useful guides and product comparisons, but the platform must not auto-generate unsupported claims.

## Failure and representation rules

- Missing or inactive entity: not-found outcome, no public record. Known removal tombstone may return gone. Missing publication revision: unpublished/not found.
- Invalid/unapproved host: reject before reading tenant data. Merchant indexing disabled: allow shopping HTML but emit blocking policy and exclude discovery entries.
- Invalid required identity/price data: do not emit misleading commerce markup; where a truthful page cannot be rendered, 503 with no-store. Record operator diagnostics without leaking internals.
- Optional image, brand, GTIN, review or policy absent: omit that property; never substitute invented values. A feed adapter may reject an entry if its own required fields are absent.
- Keep content, head metadata and JSON-LD derived from one evaluated view. Cross-request artifacts agree when source revisions match; concurrent changes require measured convergence, not an impossible promise of global instantaneous equality.
- Schedule boundaries clip validity. Consumer job results carry installation/generation and cannot overwrite newer output. Atomic artifact publication is validated against current eligibility and configuration.

## Validation mapping

Stage 03 proves public/private separation, no-pin rendering and status behavior; Stage 04 canonical/alias consistency; Stage 05 metadata/escaping; Stage 06 price, variant, attribute and JSON-LD parity; Stage 07 route enumeration; Stage 08 policy/CMS publication; Stage 09 artifact freshness and recovery; Stage 11 two-installation cache/job isolation. Follow `target-architecture.md` for cache keys, invalidation dependencies and schedule handling.
