# Security and privacy — Stage 11

Architecture decision: retain database-per-installation isolation, approved-host binding and anonymous public projections. Review the complete path from published database facts through renderer, discovery files, feeds, media, admin health and attribution. Robots is advisory. Treat browser attribution and crawler user agents as claims. Fixed operator-configured service addresses must never become caller-selected network destinations. Review changes against adversarial fixtures before assigning a finding status.

## Review and evidence

The reviewed source is the public projection in domain-catalog, public_commerce policy/snapshot/canonical/images/entity/metadata/facts/discovery/feeds/attribution/health, the Node transport/renderer and public React presentation. Existing unrelated assistant, corporate-site and general application logic was not modified. This is a bounded source-and-test review, not an independent penetration test or dependency vulnerability scan.

| Threat | Control and evidence | Status |
|---|---|---|
| Host/forwarded injection | Exact approved Host; forwarded values ignored; wrong/duplicate hosts covered by HTTP/policy tests; private gateway receives only approved Host. | Verified locally |
| Cross-tenant cache poisoning | One database/renderer/storage scope per installation; no-store dynamic documents; two tenants with identical IDs/slugs/SKUs/locales and differing sentinels. | Verified locally under the deployment invariant |
| Stored XSS | React text escaping; metadata escaping; script-safe JSON/JSON-LD serialization; hostile product names/descriptions tested in real HTML and both Chromium contexts. | Verified locally |
| Enumeration of unpublished data | Active-resource/parent visibility and published CMS release projection; sitemaps/feed export recheck eligibility; private image access denied before object fetch. | Verified locally |
| Open redirects/loops | Bounded canonical relative destinations and approved origin; unknown destinations fail closed; existing loop/foreign-target regressions retained. | Verified locally |
| SSRF | Request data cannot select gateway/media/probe destinations; fixed operator service configuration; credential-bearing/non-root/unsupported health targets rejected; redirects not followed. | Verified locally |
| XML/CSV injection | Canonical paths and origins are constrained; XML locations escaped and tested. Feeds are JSON; no SEO/GEO CSV endpoint is introduced. | Verified locally / CSV not applicable |
| Crawler impersonation | User agent labels and UTM/referrer evidence remain untrusted claims; no authorization or alternate privileged rendering follows from them. | Verified locally |
| Private customer/order/cart/pricing data | Anonymous DTO projection, conditional-price rules, stripped browser credentials, private attribute/contact/storage sentinels, protected admin revenue and order linkage. | Verified locally |
| Admin authorization/audit | Session permissions, CSRF/origin middleware, optimistic revisions and audit rows; rejected foreign installation sessions and unauthenticated requests. | Verified locally |
| Dependency amplification | Previously 40 simultaneous requests reached the gateway; bounded admission now rejects excess work, alongside transport byte caps and deadlines. | Implemented and verified locally |

No high/critical finding remains open in the reviewed application path under its tested deployment invariant. Resource amplification was addressed by bounded admission. There is no claim that one test suite proves absence of all vulnerabilities.

Separate storage is a required invariant: the current Store uses a fixed commerce-media bucket and catalog object keys within its configured endpoint. Reusing a storage endpoint/bucket and credentials across merchant installations is unsupported and can collide for identical IDs/keys. The matrix proves actual bytes through separate local object-store endpoints, not safety of a shared bucket. Such deployment reuse is a release blocker until storage is isolated or a separately designed migration introduces installation namespaces. Verify ingress, credentials, database and storage binding before production release; local tests cannot attest existing cloud configuration.

No new telemetry identity or retention policy was added. Stage 10's bounded campaign/referrer evidence, GPC/DNT behavior, ninety-day discovery retention and revenue permissions remain in force. The new renderer admission response has a fixed body and contains no submitted URL, customer identity or exception details. Robots/noindex is advisory and does not protect private endpoints.

Review references: OWASP's [SSRF prevention](https://cheatsheetseries.owasp.org/cheatsheets/Server_Side_Request_Forgery_Prevention_Cheat_Sheet.html) and [XSS prevention](https://cheatsheetseries.owasp.org/cheatsheets/Cross_Site_Scripting_Prevention_Cheat_Sheet.html), reviewed 2026-09-21. Their allowlist and contextual-output principles inform this review; passing these tests is not an OWASP certification.
