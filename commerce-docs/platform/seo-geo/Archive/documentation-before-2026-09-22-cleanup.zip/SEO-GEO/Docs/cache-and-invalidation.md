# Stage 03 cache and freshness policy

## Decision

Continue the Stage 01 approved initial mode: **no shared HTML or DTO cache**. Dynamic documents, snapshot JSON, errors, redirects and private shells use `Cache-Control: no-store`; the merchant Nginx document route has `proxy_cache off`. Introducing reusable cached prices before publication generations exist would contradict the accepted design. This is the deliberate interpretation of Stage 03's cache-isolation requirement, not a claim that a shared cache has been implemented.

Each request binds one approved Host, one fixed gateway address, the deployment installation UUID, the configured locale, and one route/page. The gateway verifies its database UUID; the renderer independently checks UUID, origin, path, page, locale shape and schema version. Cookies, authorization, IP-derived location and forwarded host headers are not sent to snapshot assembly. No process-global React Query cache exists. The optional browser search widget owns its own browser QueryClient and does not replace page content.

## Invalidation and consistency

Catalog, public attribute definitions, current CMS release, delivery-area presence, discovery settings and the anonymous default published theme are read in one REPEATABLE READ, READ ONLY transaction. A 3-second statement timeout and 4-second assembly deadline bound work; the renderer has a 5-second transport deadline and cancels upstream work on document disconnect. Products are paginated in stable name/UUID order, 24 per page with one lookahead row. Theme collections are independently bounded to 24 and use catalog text/category predicates within the same transaction. They do not claim personalized recommendation or search-engine ranking parity.

A committed product/category/content/theme/settings change is visible on the next request. There is no purge queue or stale response fallback. Scheduled CMS release selection uses the transaction timestamp, including end dates and explicit withdrawal. Requests already in progress retain their consistent transaction snapshot. Cross-request pagination is not frozen across catalog edits.

Built Vite assets use content-hashed names; the standalone Node static handler permits only flat `/assets/` files and marks successful assets immutable for one year. Nginx may serve these files directly from the per-installation release. Public brand/font/data assets retain existing ingress handling. Dynamic HTML is never placed in the immutable asset cache.

## Future enhancement

A shared cache requires installation + approved host + actual locale + canonical route/page + public publication generation in its key; transactional publication events and delete/rename invalidation; no private request context; measured freshness limits; and cold/warm isolation tests. Catalog-scale load and CDN purge behavior have not been measured in Stage 03.
