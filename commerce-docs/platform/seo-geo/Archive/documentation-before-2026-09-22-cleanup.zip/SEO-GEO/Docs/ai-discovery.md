# Merchant AI discovery — Stage 07

Public merchant HTML, canonical identity, structured product facts, accessible images and XML sitemaps remain the discovery foundation. No corporate marketing pages, demo links, assistant context, private customer data or whole-catalog text dump are published through this feature.

**Not implemented** — optional llms.txt generation. GET `/llms.txt` explicitly returns 404, including when the legacy reserved llms_txt_enabled field is true. Admin explains this limitation and no longer presents that field as an operational publishing switch. The legacy field and corporate section settings remain in the API for backward compatibility but are not advertised as merchant publishing capabilities in the AI settings screen. Approved merchant policy/support modeling belongs to the following stage; absent policies are not invented here.

**Implemented** — separate OpenAI search retrieval and training crawling preferences. See [crawler policy](crawler-policy.md) for provider scope, registry and authentication. Other AI providers have no dedicated preference in this stage and follow applicable wildcard rules. No robots or sitemap setting guarantees indexing, citations, retrieval or rankings.

## Stage 12A reconciliation — 22 September 2026

Approved merchant identity, revision-bound policy/guide publication and comparisons were implemented in Stage 08. The earlier statement that these belong to a following stage is historical. llms.txt and external-provider ingestion remain Not implemented; useful factual public content remains the foundation. See the [final report](../Reports/SEO-GEO-final-report.md), [architecture](architecture.md) and [operations](operations.md) for current acceptance scope and first-client gates.
