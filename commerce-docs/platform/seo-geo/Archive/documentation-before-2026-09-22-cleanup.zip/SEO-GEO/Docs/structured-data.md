# Structured-data publication

## Output

Every successful canonical public document receives one initial-HTML `application/ld+json` script. The graph contains Organization (the visible merchant name), WebSite, and WebPage with its own canonical URL. Resource pages add visible BreadcrumbList ancestry. Product pages add Product; actual configurable parents add ProductGroup and their active variants. Known measured product media becomes ImageObject. Eligible individual simple SKUs have Offer with the resolved price/currency, canonical URL and merchant seller reference.

Graph IDs are anchored to the approved installation origin and canonical resource. Main product/page URLs reuse Stage 04's JSON-LD canonical adapter; related products use identities constructed by the same canonical context. Homepage/category/content do not claim to be a Product. Error, redirect, private and unbound/nonproduction responses have no public product graph. Merchant noindex does not change a valid resource's identity or public facts.

Name and description use visible catalog facts, not optional search-title overrides. SKU and seller are visible on product pages; family names, descriptions, prices and specifications are also server-rendered. No AggregateOffer is invented for configurable, grouped or bundled products. Configurable members have individual offers only when each member qualifies.

## Serialization and failure behavior

The backend builds JSON values rather than concatenated text. Node serializes once and escapes `<` and Unicode line separators before embedding. Merchant text cannot close the script element. A renderer check compares the graph's merchant identity, product name/description/URL and eligible offer price/currency/seller to the typed snapshot, including variants. Contradictions produce the existing no-store/noindex 503 response instead of publishing conflicting facts. Tests deliberately mutate each material field to verify rejection.

Local validation checks JSON syntax, the emitted node/property shapes, canonical relationships, script escaping and raw HTML parity. This is not a claim of a successful external Schema.org validator or Google Rich Results Test, nor a ranking, indexing or citation guarantee. Missing fields can affect eligibility for a particular search feature.

## Sources checked 2026-09-21

[Schema.org Product](https://schema.org/Product) supports additionalProperty for merchant specifications. [Schema.org Offer](https://schema.org/Offer) defines price/currency, seller and optional availability. [Google product snippets](https://developers.google.com/search/docs/appearance/structured-data/product-snippet) distinguishes individual offers from aggregate offers and cautions against using AggregateOffer for variants. [Google variant guidance](https://developers.google.com/search/docs/appearance/structured-data/product-variants) describes ProductGroup and hasVariant/isVariantOf. Merchant configuration labels are retained as Schema.org textual variesBy values; provider-specific eligibility for custom dimensions remains unverified.

Tests: `backend/crates/api-gateway/tests/publication_rendering.rs`, `public_commerce::facts::tests`, and `frontend/apps/storefront/server/structured-data-checks.mjs`. Captured initial HTML is in `SEO-GEO/Tests/stage06`.

## Stage 12A reconciliation — 22 September 2026

Candidate regression checks validate the emitted graph and raw-HTML agreement. Approved merchant Organization details were added in Stage 08. Typed return/shipping policy schema, fabricated stock/identifiers/reviews and external rich-result approval remain outside the verified output. No provider documentation was newly reverified in this documentation-only reconciliation. See the [final report](../Reports/SEO-GEO-final-report.md), [architecture](architecture.md) and [operations](operations.md) for current acceptance scope and first-client gates.
