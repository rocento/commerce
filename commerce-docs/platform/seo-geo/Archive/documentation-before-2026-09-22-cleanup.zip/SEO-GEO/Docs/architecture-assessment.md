# Stage 01 repository assessment

Date: 21 September 2026. **Verified** means inspected source or the specific recorded check; it does not mean live deployment verification. Read with `program-contract.md`.

## Provenance

Stage 00 is committed as `a3da74e`. The application, original prompt package and prior assessment remain untracked. That commit cannot reproduce the application reviewed here. `../Reports/01-source-manifest.json` records SHA-256 fingerprints of the inspected source files and prompts; it contains no environment-file values. No historical application revision is available to establish when changes occurred. The original assessment's principal findings are still present; the refinements below are newly established evidence, not claims about historical changes.

## Host to installation to data

1. `scripts/ec2-compose.sh` selects grocery, jewelry or electronics and runs a distinct `rocento-$store` Compose project, with that installation's environment and Compose overrides. Named database, object, search and event volumes belong to those projects. The same frontend build is reused.
2. `deploy/ec2/configure.py::nginx` routes grocery/admin API traffic to localhost:8080, jewelry/jewelry-admin to 58080, and electronics/electronics-admin to 59080. `/api/` is stripped by the proxy. Static storefront hosts serve the shared storefront directory; admin directories are distinct builds. The apex website is a separate excluded surface.
3. Each `api-gateway/src/main.rs` process opens one `DATABASE_URL` pool and constructs its domain services from that pool. Catalog and CMS rows are installation-local; they do not contain a general merchant tenant key. Discovery configuration is a singleton in that database.
4. The proxy forwards Host, but the inspected catalog/discovery paths do not use Host to select a pool or validate a merchant identity. `ALLOWED_ORIGINS` and identity middleware govern browser-origin checks; they are not tenant resolution. Do not treat `ASSISTANT_TENANT_ID` as the commerce installation ID: it belongs to an excluded subsystem.
5. Local Vite sends `/api` to a configured fixed backend (`API_PROXY_TARGET`) and rewrites the prefix. It likewise does not resolve tenants from arbitrary hosts.

**Verified conclusion:** the current isolation model is one commerce installation per gateway/database, selected by deployment routing. **Not implemented:** a shared-database merchant host resolver. Stage 02 should bind an explicit commerce installation ID and approved storefront authority to this existing model, rather than retrofit all commerce tables with tenant IDs.

The generated Nginx has no explicit rejecting default host server in the inspected function. A default-vhost fall-through is therefore a design risk, not proof of a deployed exploit. Future public handlers must reject unknown authorities even if the proxy configuration is wrong. Trusted proxy boundaries and explicit default rejection belong to Stage 02.

## Source assessment verification

| Finding | Exact source surface | Status and refinement |
| --- | --- | --- |
| Client-only initial storefront | `frontend/apps/storefront/index.html`, `src/main.tsx`, `package.json`, `vite.config.ts` | **Verified**: empty root, fixed title, createRoot, Vite client build. No SSR entry or runtime is defined. |
| Product data loads later | `src/catalog.tsx::ProductDetail`, `src/product-types.tsx` | **Verified**: React Query loads product, images and family. Public content waits on the main session gate and theme loading. |
| Browser-dependent theme | `src/themes.tsx::ThemeProvider` | **Verified**: window/sessionStorage, delivery and session-specific query keys. Cannot import the existing entry into Node unchanged. |
| ID URLs despite slugs | `src/main.tsx`; `domain-catalog/src/lib.rs`; `20260913020000_catalog.sql` | **Verified**: ID routes, unique slugs per database. No reviewed slug history or public redirect registry. IDs remain valid compatibility identifiers. |
| Metadata/discovery outputs absent | Storefront source and public file inventory; gateway routing | **Verified** source search found no storefront canonical/head manager, Product/Offer/Breadcrumb JSON-LD, robots, sitemap or llms generator. Corporate output is outside this assessment. |
| Soft-404 risk | `src/main.tsx` fallback; `deploy/ec2/configure.py::nginx` | **Verified**: client not-found UI sits behind index.html fallback. API 404 does not make the HTML request a 404. |
| Configuration without storefront publishing | `api-gateway/src/discoverability.rs`, settings migration, admin settings component, API-client discovery module | **Verified**: persistence, validation, permissions, revision conflict and audit exist. No storefront consumer was found. HTTPS validation does not establish host ownership or production approval. |
| Demo/admin indexing suppression | `deploy/ec2/configure.py::nginx` | **Verified**: noindex/nofollow headers, including API locations. Keep protection; add explicit production-merchant configuration separately. |
| Limited attribution | `src/analytics.ts`; gateway analytics/reporting | **Verified**: fixed direct/search/social/email/referral/unknown categories. No dedicated AI attribution in browser classifier. |

## Authoritative data and important edge cases

- Catalog has price, currency, descriptions, images, public attributes and active state. The original catalog migration restricts currency to USD; no currency expansion migration was found. Do not infer multi-currency support from a string field. Several frontend product choices format `$` directly.
- Configurable/grouped/bundle relationships live in `domain-catalog/src/types.rs`. The public family endpoint in `api-gateway/src/attributes.rs` filters inactive children and recalculates stock, but requires deliverability. `inventory.delivery(None)` is not deliverable once areas are configured. By contrast, the product endpoint only rejects an undeliverable selection when a pin was supplied. The public assembler must avoid inheriting this no-pin family failure while retaining checkout checks.
- `domain-catalog::visible_attributes` removes known hidden/inactive definitions; it does not construct a strict allowlist from all values. The new public DTO must enumerate permitted definitions, so unknown/stale attribute keys cannot leak by default.
- `domain-pricing-promotions::assess` evaluates customer groups, coupon and cart conditions in a transaction. Catalog's public product read exposes base price. Do not label base price as an unconditional discounted offer or replay checkout with synthetic customer data.
- CMS public reads select a released revision at statement time, excluding cancelled, expired and unpublished content. Admin document revisions, creator IDs and schedules must not be serialized as public content.
- Reviews provide a dedicated `PublicReview` excluding customer ID and moderation reason. Only approved published data is eligible; a 50-row page cannot stand in for a full rating aggregate.
- `api-gateway/src/merchant/mod.rs` is an authenticated merchant analytics/questions API, not a public merchant entity registry. Do not reuse its orders or reporting DTOs for merchant schema.

## Cache, event and deployment findings

`infra-events` persists transactional outbox events and delivers at least once through NATS JetStream. Catalog emits specific changed/deleted events. Admin audit also calls `infra_events::record`: discovery, CMS, theme, promotion and moderation writes can produce audit action events indirectly. Their envelope commonly contains `entity_id` and actor ID, not a complete versioned public object. Re-query authoritative state; never publish audit payloads directly. Review resubmission can remove approved public content without using that admin audit path, and clock-based CMS/promotion transitions occur without writes. Event-only invalidation is insufficient.

Themes resolve by sales channel plus city, delivery area/stock and optionally authenticated customer segments. Responses use private/no-cache, Vary and an ETag. These cannot be copied into an anonymous shared cache without isolating the resolution context. CMS frontend polling is 10 seconds; theme polling is 30 seconds; family polling is 5 seconds. Polling is not server-publication invalidation.

Media content currently uses a public one-day cache. Deployment serves static HTML with no-cache and APIs with no-store. The Cloudflare deployment guide instructs bypassing cache on demo/admin hosts; no live CDN rule inspection was performed. `deploy/ec2/build-frontend.sh` currently produces only static storefront assets, so SSR requires an explicit runtime and coordinated client/server artifact deployment.

## Migrations and regression boundaries

`infra-db` runs embedded SQLx forward migrations at startup. Use additive fields/tables and compatibility defaults; never rewrite shipped migrations. Preserve existing discovery API fields, ID links and admin permissions. Domain tests, gateway SQLx tests, frontend Vitest, Playwright and Python deployment tests are the established runners. No feature tests were invented in this design stage.

**Partially verified:** actual domains, CDN enforcement, installation data sizes, query plans, latency, traffic and production freshness were not observed. The selected architecture includes explicit implementation gates for these unknowns.
