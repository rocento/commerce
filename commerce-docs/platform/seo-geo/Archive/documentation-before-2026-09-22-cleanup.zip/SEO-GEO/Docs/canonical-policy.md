# Stage 04 canonical URL policy

## Trusted identity

`public_commerce::canonical::Context` is constructed from the installation UUID read from the current database, its matching deployment binding, the operator-approved root HTTPS origin, and the saved discovery identity. Production context requires the saved canonical origin to equal that approved origin. Request Host/Forwarded values never construct a canonical URL. Host is checked separately before data access; foreign hosts receive 421.

The service returns an `Identity` with installation, actual default locale, path, absolute URL, and HTML/JSON-LD/sitemap/feed adapter values. Every adapter uses the same computed URL. Stage 04 emits the HTML `<link rel="canonical">`; JSON-LD, sitemap and feed values remain contract placeholders for their later stages. They are not newly implemented feeds or structured data.

Nonproduction environments, invalid origins and mismatched bindings have no public canonical context. A valid canonical can coexist with merchant noindex: disabling indexing does not change resource identity. Missing/retired/error/private pages do not emit a canonical, and unrelated pages are never canonicalized to the home page.

## Routes and variants

| Surface | Policy |
| --- | --- |
| Active product | `/products/{current-slug}`; self-canonical |
| Category | `/categories/{current-slug}`; self-canonical |
| Legacy ID or historical slug | One 301 directly to the latest live slug |
| Distinct active child product | Own slug/canonical; hidden if its parent is inactive |
| Selection-only variant/filter/sort parameters | Unsupported on anonymous publication URLs: 404, no canonical |
| Purchase/options | Existing private ID view with `?shop=1`, noindex/no-store, no public canonical |
| Home / published CMS | Existing `/` and `/pages/{key}`, self-canonical |
| Search, account, cart and other known app flows | Existing private entry, noindex/no-store; no public canonical |
| Unsupported locale route | 404; no invented translated pages or hreflang |

Only the configured default content locale is published, with no locale path prefix. `lang`/`locale` equal to that locale redirects to the clean URL; a different value returns 404. This does not translate merchant content. Product/category IDs stay in domain APIs and internal references; server-visible discovery links use slugs. Authenticated/interactive legacy navigation and merchant-authored theme links may still contain IDs, which remain backward compatible.

## Query/path normalization

Resolve existence and latest resource identity first, then issue one redirect combining all applicable normalization. Case is lowercase, a trailing slash is removed, and percent-encoded ASCII is decoded once. Encoded separators, malformed encodings, dot segments and paths outside the known route grammar are rejected. Legacy underscores/repeated hyphens can resolve through their reserved aliases; newly generated slugs use single hyphens.

Listing `page=1` is omitted. Pages 2–10000 are self-canonical, including their page query; nonexistent pages return 404. Leading zeroes are normalized. Products/CMS do not accept page numbers above 1. Pagination links preserve the resolved page route and point only to previous/next listings.

Tracking keys `utm_*` (lowercase letters/underscores), `gclid`, `fbclid`, `msclkid` and `campaign` are removed by 301. Duplicate keys, unknown keys and unsupported filter/sort/variant combinations return 404. This prevents arbitrary combinations from becoming discoverable duplicates or silently masquerading as filtered content. Existing search/filter workflows remain in `/search`. Tracking capture is not implemented here; future measurement must capture approved attribution before redirecting.

The explicitly private purchase and theme-preview routes retain their separate application handling. Purchase links resolve the resource before serving the legacy ID view; an old slug/ID cannot reopen an unavailable product. The default public ID URL still redirects to its slug.

## Consumer and cache boundary

The snapshot carries the canonical identity. Node verifies installation, origin, locale, route/page and equality of all adapter URLs before emitting a link. Canonical and redirect responses use `no-store`. Existing external caches and production ingress were not altered or deployed in this stage. Canonical links express preferred identity; they do not guarantee indexing or ranking.

## Stage 12A reconciliation — 22 September 2026

The Stage 04 adapter placeholders described above are now consumed by JSON-LD, sitemap and reference-feed implementations. Tracking capture was added in Stage 10 as sanitized short-lived campaign evidence before canonical redirects; it is not an authentication signal. Independent variant canonicals, one public locale, unsupported-query rejection and no-store responses remain the policy. See the [final report](../Reports/SEO-GEO-final-report.md), [architecture](architecture.md) and [operations](operations.md) for current acceptance scope and first-client gates.
