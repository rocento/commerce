# Stage 03 HTTP status policy

The merchant ingress sends documents to the installation's Node renderer, `/api/` to its Rust gateway, and static files to the matching release. The corporate website and demo/admin configurations are outside this change.

| Condition | Response |
| --- | --- |
| Published home, active product, category, current CMS release | 200 with meaningful HTML |
| Unknown path/resource, inactive product, unpublished/expired content, invalid/out-of-range pagination | 404, noindex, no-store |
| Explicit approved route retirement | 410, noindex, no-store |
| Approved old route with a currently public destination | 301 to same-installation relative path; noindex, no-store |
| Redirect destination missing/inactive, cyclic or exceeding the resolver bound | 404; valid replacement/history chains collapse to one 301 |
| Unexpected host | 421; Forwarded and X-Forwarded-Host never select a store |
| Unsupported document method | 405, Allow: GET, HEAD |
| Gateway timeout, invalid snapshot/binding, invalid published theme | 503; never an empty 200 shell |
| Known account/cart/search/checkout/auth/support/assistant route | Existing client entry, noindex, no-store; existing API authorization applies |

GET and HEAD have identical status/header policy; HEAD sends no body. Arbitrary query variants are noindex; `page` is the only public listing query. The installed locale comes from the same snapshot as the content; there is no Accept-Language or cookie-based HTML variant.

`?shop=1` opens the existing interactive product view after resolving public existence/status. It does not bypass a missing/retired resource at the renderer. `theme_preview` remains a private, noindex app entry; its existing admin preview authorization still governs draft access. Private shells do not convey authorization to private APIs.

The direct gateway is not a public document origin: anonymous catalog document requests there return 503, unknown paths return 404. This replaces Stage 02's temporary public SPA shell. The internal `/v1/publication/snapshot?path=...&page=...` returns a typed envelope with authoritative `status`; the API response itself is always noindex/no-store. Node converts that field into the document's HTTP status. No temporary 302/307 rule is fabricated without a business reason.

## Explicit route decisions

Migration `20260921100000_publication_routes.sql` adds an installation-local operator registry with `path`, `status` (301/410), optional relative `target`, approval timestamp and required reason. Only simple product/category/page paths are accepted by its database constraints. It is a route registry, not a second catalog or automatic product-deletion detector. Operators must review all aliases when retiring a resource. Missing rows are never interpreted as removal history.

Stage 04 owns automatic slug history, canonical identity and management workflows. Stage 03 emits only deliberate registry decisions; no merchant records are added by deployment. Active products with unavailable stock remain browsable. Personalized stock and final pricing remain in existing shopper APIs.

Stage 04 supersedes the initial registry-only behavior with stable-ID history and centralized canonical URLs. See `canonical-policy.md` and `slug-and-redirect-policy.md` for current normalization, query and lifecycle behavior.
