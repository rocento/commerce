# Merchant crawler policy — Stage 07

The gateway generates robots.txt from the effective indexing resolver and installation-local, revisioned preferences. The Node publisher checks the gateway's installation UUID before returning successful artifacts. Host input never supplies an output origin. All discovery artifacts use no-store and X-Robots-Tag: noindex, nofollow; the latter describes the artifact itself, not the pages it lists.

Production public documents remain crawlable while indexing is disabled so traditional crawlers can observe their noindex headers. Disabled publication suppresses sitemap output and its robots advertisement. Demo, staging, development and admin environments emit wildcard Disallow: /. Private routes and preview/purchase queries are disallowed. Each permitted provider group repeats the private exclusions because specific groups do not inherit the wildcard group. The public media-content exception allows image fetching; it does not bypass reference-based media authorization or remove API noindex headers.

`backend/crates/api-gateway/src/public_commerce/crawlers.json` is the executable provider registry, with purpose, exact token, official source, verification date and preference key. The wildcard describes the baseline for traditional search and other unspecified crawlers; it cannot classify unknown AI agents. OpenAI is the explicitly supported AI provider in this stage. Provider preferences default to search retrieval allowed and training crawling disallowed, subject to effective publication eligibility.

OpenAI documents independent controls for OAI-SearchBot (search) and GPTBot (training). ChatGPT-User is user initiated and robots rules may not apply. This implementation does not claim to control those requests. [Official OpenAI crawler guidance](https://developers.openai.com/api/docs/bots), verified 2026-09-21. Group-specific rules follow the [official Google robots interpretation](https://developers.google.com/crawling/docs/robots-txt/robots-txt-spec), verified 2026-09-21.

Admin AI discoverability provides separate named search and training checkboxes. GET/PUT `/v1/admin/discovery/crawlers` require discovery.read/write respectively; writes retain origin/CSRF enforcement, optimistic revisions and an audit event. The effective-policy endpoint returns the same composed robots body. Robots rules are voluntary crawler instructions, never authorization or a guarantee that previously indexed URLs disappear.

Reverify the registry before changing provider tokens or semantics. Additional providers require their own verified entries and independently meaningful controls; do not alias them to an “Allow AI” preference.

## Stage 12A reconciliation — 22 September 2026

Candidate tests cover the local policy/host matrix and Node output checks. Provider registry references retain their recorded 2026-09-21 verification date; this reconciliation is not a new provider-documentation review. Reverify official provider behavior at first-client rollout or before changing the registry. Public-edge crawler access remains Blocked pending Stage 12B. See the [final report](../Reports/SEO-GEO-final-report.md), [architecture](architecture.md) and [operations](operations.md) for current acceptance scope and first-client gates.
