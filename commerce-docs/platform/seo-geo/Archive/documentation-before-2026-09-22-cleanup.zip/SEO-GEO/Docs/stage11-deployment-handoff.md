# Stage 11 — replacement-host deployment handoff

2026-09-22. **Partially verified:** local merchant publication engineering checks have recorded evidence. **Blocked:** acceptance on an actual replacement host. Under the user-approved [first-client plan](first-client-live-validation.md), Stage 12 preparation may proceed; remaining live gates run during the first-client pilot.

## Verified baseline and release inputs

Use the [release-blocker report](../Reports/11-release-blocker-resolution.md) and [source manifest](../Reports/11-release-source-manifest.json) as the recorded baseline. A [fresh integrity audit](../Reports/evidence/stage11-resume/integrity-audit.json) verifies all 60 manifest file hashes against commit `4b3e047`. The current `backend/Cargo.lock` differs; no new runtime test results are claimed for that change. Preserve concurrent work and choose an explicit release revision before building.

The repository includes working-tree dependencies outside the release commit; the manifest records their contextual hashes. A checkout of the commit alone must not be assumed to recreate the tested complete workspace. Assemble a complete release source/dependency set, record its hashes, build matching client and SSR artifacts, seal them together and rerun the relevant checks against that exact release. The [rehearsal instructions](../Tests/stage11-release/README.md) document runtime, workloads and limits.

## Required environment details

The deployment owner must supply the replacement server/access method, approved merchant HTTPS domain, separate demo/admin domains, intended release revision, and database/object-store topology. Do not place credentials in this document or evidence. Host `63.182.240.84` is retired and must not be retried. No replacement target or cloud provisioning authorization is inferred from this handoff.

## Acceptance sequence

| Step | Required action and evidence | Current status |
|---|---|---|
| Release assembly | Record complete source revision/context, dependencies, gateway image, client/template/SSR hashes and previous rollback artifact set. Build with the intended Linux runtime. | Partially verified — local recorded build only. |
| Installation isolation | Inspect each merchant's persisted installation UUID, approved origin and separate database/media scope. Include two installations with overlapping IDs/slugs; inspect external storage IAM separately if applicable. | Blocked — replacement topology unavailable. |
| Protected deployment | Use the merchant publication overlay with indexing disabled initially, matching private observation secrets and sealed artifacts. Keep demo/admin protections. Verify private health and readiness through the intended topology. | Implemented — overlay and local contracts exist; live configuration unobserved. |
| Read-only preflight | Run the command below on the actual host. Exit 2 stops release. External managed services require independently recorded isolation evidence. | Verified — local contract/negative tests; live run Blocked. |
| Public ingress | Verify DNS and trusted TLS, unknown-host rejection, canonical authority, robots and response headers. Compare origin and CDN responses; prove dynamic HTML/API cache bypass and stale-offer withdrawal. Verify intended crawler access through WAF rules. | Blocked — public ingress unavailable. |
| Existing images | Use the authenticated image publication endpoint in bounded sequential batches; retain originals, record IDs/results and inspect representative output. | Implemented — procedure and endpoint; live regeneration Blocked. |
| Target workload | Repeat image-bearing desktop/mobile measurements, two-renderer load and full paced feed reconciliation with representative merchant data. Record host limits, timings, errors and memory scope. | Verified — synthetic local workload; target run Blocked. |
| Infrastructure rollback | Switch the selected release back to the retained matching gateway/frontend set, preserve additive DB/feed state, verify statuses, privacy, host protections and recovery. Record before/after revision and responses. | Partially verified — local application/proxy rehearsal only. |

Read-only host preflight, from the assembled release root:

```sh
python3 SEO-GEO/Tests/stage11-release/deployment_gate.py --output /tmp/publication-deployment-gate.json
```

A successful exit verifies the collector's stated scope only. The collector is an operator gate, not automatically enforced by every existing deploy launcher. Its output must not contain environment secrets or authenticated customer/admin response bodies. Do not substitute the synthetic empty local inventory for deployed-host evidence.

Image regeneration uses the existing `POST /v1/admin/catalog/media/{id}/publication` endpoint with an own-installation `catalog.write` session; the app proxy adds `/api`. Follow the limits and retry procedure in the rehearsal README. No remote mutation is performed by this handoff.

## Gate to Stage 12

Start [Stage 12 Phase A](../../Rocento-SEO-GEO-Staged-Prompts/12-final-validation-and-release-report.md) with documentation, evidence reconciliation and candidate regression work. Carry the outstanding Stage 11 target-environment findings into Phase B with the first client. Close them with recorded live evidence before public/general release; Stage 12 then produces the final recommendation. No production release or indexing approval is granted by the local rehearsal or this document.
