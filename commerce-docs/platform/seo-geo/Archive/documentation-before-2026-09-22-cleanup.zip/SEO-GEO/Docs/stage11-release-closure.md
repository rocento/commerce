# Stage 11 release-blocker closure decision

2026-09-21. Scope: merchant platform storefront SEO/GEO.

The owner confirmed Quality host 63.182.240.84 is retired. Stop attempting that host. Use a disposable local Linux release rehearsal to resolve independently testable engineering blockers, while keeping the real deployment gate explicit. No public DNS, indexing, production routing, live data or infrastructure was changed.

Preserve the original Stage 11 report and source manifest as historical evidence. The follow-up report `../Reports/11-release-blocker-resolution.md` records additional measurements and fixes. Historical pre-SEO telemetry cannot be reconstructed: the recorded Stage 10-to-11 comparison and the new controlled image-encoding comparison are the available baselines.

Keep dynamic HTML uncached. Retain bounded renderer admission, database/media isolation per installation and noindex by default. Supply a matching private observation secret to gateway and renderer, connect the gateway's private renderer probe and mount the same sealed artifact directory. Before a real release, the read-only topology gate must pass on the actual merchant host; its local empty-inventory failure must never be relabeled a production pass.

Quality-controlled WebP derivatives address the measured image transfer bottleneck. Preserve originals, dimensions and alpha. Existing media require explicit authenticated regeneration using the current bounded image endpoint; deployment of the encoder does not silently rewrite stored media. The reproduction and migration procedure is in `../Tests/stage11-release/README.md`.

Local TLS/Nginx replica-switch and recovery evidence establishes application/proxy compatibility. It does not establish public certificate issuance, CDN/WAF behavior, IAM isolation, field Web Vitals or infrastructure rollback. Those remaining acceptance checks need the first client’s hosting environment before production release. The user-approved [22 September amendment](first-client-live-validation.md) permits Stage 12 preparation now and carries these checks into its first-client live phase; no live gate is waived.
