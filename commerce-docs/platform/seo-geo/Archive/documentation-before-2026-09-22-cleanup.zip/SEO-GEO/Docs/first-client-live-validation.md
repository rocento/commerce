# First-client live validation — approved plan

Approved by the user on 22 September 2026: perform the remaining live SEO/GEO tests with Rocento's first client. Scope is the merchant platform/storefront. Corporate-site and shopping-assistant work remain excluded.

## Sequencing decision

**Implemented:** the plan now permits Stage 12 preparation from the recorded local Stage 11 evidence. Stage 12 Phase A covers documentation, claim reconciliation, an exact candidate build and local regression work. Phase B runs live acceptance during the first-client pilot. No pilot, deployment or Stage 12 test execution is claimed by this planning change.

**Verified:** prior local results remain documented in the [Stage 11 follow-up](../Reports/11-release-blocker-resolution.md). **Blocked:** missing live evidence stays open until client onboarding supplies the environment. No replacement server is required merely to begin Phase A; public/general release still requires the mandatory live gates. The retired Quality server is not part of this plan.

## Onboarding record

Before pilot admission, assign named people to the Rocento release owner, infrastructure operator and client approver roles. Record the client installation, approved merchant domain, demo/admin domains, access method, hosting/storage topology, exact release revision and source/artifact hashes, previous working release, agreed test window, approved public catalog/policies and representative sample routes. Credentials stay in the deployment secret system, not the report.

Record calendar deadlines at onboarding. The gate deadlines below are mandatory even before dates are known. Client and host details are currently unassigned; this is not approval to deploy to an arbitrary account or environment.

## Gates and responsibilities

| Gate | Required evidence/action | Responsible role | Deadline |
|---|---|---|---|
| Pilot admission | Local privacy/isolation/security and relevant regressions pass for the exact candidate; complete release inputs and rollback artifacts recorded; named owners and test window agreed. No open high/critical security issue. | Rocento release owner | Before deploying the candidate pilot |
| Protected live validation | Real installation UUID/origin match; isolated DB/media storage and IAM; trusted TLS; private health; approved access boundaries; demo/admin protections. Start prelaunch merchant publication with noindex and controlled access. | Infrastructure operator | Before exposing pilot access |
| Public-content correctness | HTML/status, one-hop redirects, canonicals, visible price/currency/availability, JSON-LD, approved identity/policies, media, sitemap and feeds agree. Verify region-restricted, simple/variant, published/unpublished, renamed/deleted cases. | Rocento release owner + client approver | Before public indexing/cutover |
| Live operations | Origin/CDN/WAF checks, no stale dynamic output, bounded image regeneration, representative browser measurements, approved bounded load/feed checks, redacted telemetry and tested infrastructure rollback. | Infrastructure operator + release owner | Before public indexing/cutover |
| Public indexing/cutover | All mandatory live checks pass, client public facts/domain approved, explicit go/no-go recorded. Verify indexable merchant responses after policy transition while demo/admin remain noindex. Abort or restore the prior policy/release on failure. | Rocento release owner + client approver | During agreed launch window |
| General release | Stage 12 acceptance matrix and relevant regressions reconciled against actual evidence; every critical finding resolved; final recommendation and report committed. | Rocento release owner | Before broader rollout or release claims |

For an existing live storefront, keep existing production routing/indexing intact while testing a separate prelaunch environment. Do not globally set the client's current store to noindex. For a new merchant storefront, retain noindex until the public-launch gate. Robots/noindex are discovery controls, not protection for private data.

## Test execution

Use the [Stage 12 acceptance suite](../../Rocento-SEO-GEO-Staged-Prompts/12-final-validation-and-release-report.md) and [deployment handoff](stage11-deployment-handoff.md). Carry forward all Stage 11 live findings without relabeling local tests as live results.

1. Assemble the complete candidate source/dependency set and matching gateway/client/SSR artifacts; prior evidence is revision-specific and the repository has contextual working-tree dependencies. Rerun relevant regressions for the chosen candidate.
2. Inspect actual storage/network identity and run the read-only deployment collector. Separately verify external storage/IAM where the collector cannot inspect it. An absent or failed inventory does not pass.
3. Validate the protected first-client environment with agreed public catalog samples. Use a separate synthetic tenant with deliberately overlapping IDs/slugs for isolation checks; do not insert another client's data into the client database.
4. Run destructive fault injection, saturation, mutation/retry and rollback rehearsals in an isolated copy with synthetic/sanitized data. Run only agreed bounded checks on the live pilot; a fixture-mutating test suite must never be pointed at the client's live database. Verify the actual deployment rollback in the agreed pilot window without risking active orders.
5. Regenerate existing image derivatives sequentially through the authenticated publication endpoint, recording successful IDs and failures while preserving originals. Validate results before broadening the batch.
6. Measure origin and public-edge behavior with the same representative samples. Record TTFB, LCP/CLS and lab interaction scope, resource bytes, errors, feed wall time and memory scope. Retain the current-control baseline; missing historical pre-SEO data remains unavailable. Collect field metrics when enough real traffic exists; never rename lab interaction timings as field INP.
7. Record the launch decision, then verify the intended indexable merchant response and unchanged demo/admin protections. Observe the agreed pilot window and resolve findings before general release.

## Stop and recovery conditions

Stop advancement for cross-tenant leakage, private-data exposure, false public facts, incorrect canonical authority/statuses, failed indexing protections, broken checkout regression, material unexplained performance regression or unsuccessful recovery. Preserve evidence, restore the known working release/policy where appropriate, fix and repeat the affected checks. Do not waive these failures because the client is the first pilot.

Use **NO-GO** for public/general release while mandatory live safety gates are unverified or critical failures remain. **CONDITIONAL GO** is only for bounded noncritical gaps with named owners and calendar deadlines. **GO** requires the full Stage 12 release gate. A controlled pilot is a validation activity, not a general release recommendation.

## Evidence and reporting

Keep original stage reports/manifests unchanged. Add first-client evidence under `SEO-GEO/Reports/evidence/first-client/` when execution starts, with redacted response samples, commands/results, release/configuration identifiers, sample provenance, limitations and rollback results. Maintain the acceptance matrix and final report at `SEO-GEO/Reports/SEO-GEO-final-report.md` during Stage 12. No private client/customer records or secrets belong in committed evidence.

This amendment supersedes earlier instructions that prevented Stage 12 preparation solely because no replacement host existed. It does not mark Stage 11 live acceptance Verified or authorize live mutations before a client environment and test scope are identified.
