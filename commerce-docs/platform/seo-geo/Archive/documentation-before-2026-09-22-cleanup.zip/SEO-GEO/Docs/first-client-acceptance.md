# First-client Stage 12B acceptance record

**Blocked:** execution awaits client onboarding. This is a prepared checklist, not live acceptance evidence. Policy: [first-client plan](first-client-live-validation.md).

Client/installation: unassigned. Merchant origin: unassigned. Demo/admin hosts: unassigned. Candidate revision/source hash: unassigned. Prior rollback release: unassigned. Release owner, infrastructure operator and client approver: unassigned. Agreed window and calendar deadlines: unassigned. Assign all before pilot admission; do not include credentials.

| ID | Evidence required | Owner role | Gate deadline | Status |
|---|---|---|---|---|
| LIVE-01 | Exact source/dependencies, sealed artifacts, regression results and prior compatible release | Release owner | Pilot admission | Blocked |
| LIVE-02 | Actual DB/media/IAM separation, persisted installation/origin binding; overlapping synthetic-tenant isolation | Infrastructure operator | Protected access | Blocked |
| LIVE-03 | Public DNS/trusted TLS, Host rejection, CDN dynamic bypass, WAF/crawler observations, demo/admin noindex | Infrastructure operator | Public cutover | Blocked |
| LIVE-04 | Raw HTTP home/product/category/CMS: 200, one-hop 301, 404, applicable 410; no-JS content, canonicals and metadata | Release owner | Public cutover | Blocked |
| LIVE-05 | HTML/JSON-LD fact parity for simple/variant/regional products; approved client identity/policies; no private fields | Release owner + client approver | Public cutover | Blocked |
| LIVE-06 | Actual robots/sitemap eligibility and public image access/revocation; bounded legacy-image regeneration | Release owner | Public cutover | Blocked |
| LIVE-07 | Create/update/withdrawal consistency, full reference reconciliation, failure/retry recovery in isolated copy | Release owner | Public cutover | Blocked |
| LIVE-08 | Representative theme/mobile rendering and Admin walkthrough; browser search/cart/checkout/account regression | Release owner + client approver | Public cutover | Blocked |
| LIVE-09 | Target browser/load/resource measurements against current-control baseline; sample sizes and limits recorded | Release owner | Public cutover | Blocked |
| LIVE-10 | Actionable health failures/recovery, redacted logs, attribution semantics and available traffic coverage | Release owner | Public cutover | Blocked |
| LIVE-11 | Actual release rollback/recovery with preserved order/feed data and no stale/public private output | Infrastructure operator | Public cutover | Blocked |
| LIVE-12 | Agreed indexing transition, post-transition merchant verification, protected-host checks and signed release recommendation | Release owner + client approver | Launch window / broader release | Blocked |

Each executed row must acquire a named owner, calendar date, exact command/check, result, redacted evidence link and unresolved findings. Use the supported evidence levels. Do not change a row to Verified because configuration exists. Performance observations on synthetic catalogs do not become field Web Vitals; external search ingestion/citations are not guaranteed.
