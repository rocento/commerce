# Variant publication

Stage 04's URL decision is unchanged. Every distinct active child SKU has its own current slug and self-canonical document. Parent inactivity hides its children. Legacy IDs/history redirect to the current slug. Selection-only variant/filter parameters remain unsupported on anonymous routes; the private purchase/options view remains noindex.

A configurable parent is a ProductGroup. Its actual active family links supply hasVariant entries; the stable catalog UUID supplies productGroupID. Active definitions explicitly enabled for configurations supply textual variation dimensions. The same variant names, SKU, descriptions, public selector/specification values and individual prices appear in visible HTML. A child references its public configurable parent with isVariantOf and a visible family link. Related canonical identities come from Stage 04's context.

There is no synthetic parent offer or computed min/max price. Grouped and bundle parents display their actual component links and require shopping selections for pricing; they are not called ProductGroup and have no unsupported aggregate or parent offer. Their component prices are displayed as individual catalog prices, not as a bundle total. No cross-currency sum or currency conversion is performed.

Family results are bounded at the existing domain maximum of 100 linked children. Inactive children are omitted from HTML and schema. Duplicate historical URLs are handled by the existing redirect registry, not by duplicated JSON-LD entities. No new variant-selection landing-page combinations are generated.

Verified fixtures cover visible configurable selectors, individual child prices/canonicals, parent references, inactive-child removal and inactive-parent rejection. Composite offer suppression is also unit-tested. External rich-result display and every merchant-defined custom configuration remain partially verified.
