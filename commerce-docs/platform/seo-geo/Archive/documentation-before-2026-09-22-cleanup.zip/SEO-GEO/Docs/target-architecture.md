# Public commerce target architecture

Stage 01 decision, 21 September 2026. **Implemented:** architecture specification. **Not implemented:** the runtime described below.

## Ownership and data flow

```text
Approved host -> one installation gateway/database
                         |
Catalog + Inventory + CMS + approved Merchant settings
                         |
Rust PublicCommerce assembler + effective indexing policy
       |                 |                   |
Vite/React public SSR   discovery writers   feed adapters
HTML + metadata        robots/sitemap       reference feed
       + JSON-LD        optional llms
```

Create a small `backend/crates/api-gateway/src/public_commerce/` module first, using existing domain services and transaction-aware readers where needed. Extract a crate only if later reuse justifies it. It produces an explicit allowlisted DTO, not arbitrary serialization of domain objects. Do not persist duplicate product records. Add new `/v1/public-commerce/...` contracts without changing existing catalog consumers. The renderer uses a fixed internal gateway origin, never an origin derived from a request header or canonical URL.

The Rust module owns eligibility, approved canonical identity, price/stock semantics, CMS publication, variant visibility, public revision/freshness metadata and discovery policy. React owns presentation and matching client/server rendering; JSON-LD and metadata are deterministic projections of the same view. Gateway discovery/feed writers consume that view through shared application functions, not the renderer's HTML. Deployment owns the trusted mapping from external host to renderer/gateway and the environment's non-indexing overrides.

## Installation and host contract

Keep one commerce installation per database/runtime. Stage 02 adds a stable commerce installation UUID, generated once in installation metadata, and a deployment-supplied installation binding checked at startup. Backups retain the ID; a cloned independent installation must receive a new binding before serving public traffic. Never reuse the assistant tenant ID.

Deployment supplies environment kind, a finite list of approved public authorities and their canonical authority, plus an indexing override. Merchant settings may choose only an approved production domain for that installation. Configuration approval is operator-owned and tied to actual routing/TLS provisioning; typing any HTTPS URL is not verification. No arbitrary host can select a database or become a canonical.

Public request context: installation ID, approved host, public sales channel, supported content locale, supported currency, explicit public region or `unspecified`, policy revision and anonymous audience. Ignore arbitrary forwarded-host headers. Trust a forwarded authority only from the configured ingress which strips client values; validate it against the same allowlist. Unknown authority: 421, no-store, no canonical, noindex. An approved alias redirects only to its installation's approved canonical host.

Do not use APP_ENV alone to identify a production merchant: the current deploy generator can use development notification mode for otherwise hosted demo installations. Stage 02 needs a distinct publication environment. Do not globally remove noindex from existing demo/admin vhosts.

## Consistency and initial caching decision

Stages 02–08 use fresh authoritative public reads, **no shared HTML/commerce DTO cache**, and no-store responses for dynamic publishing. Static hashed frontend assets remain cacheable. Metadata and JSON-LD are derived from the exact DTO used for visible HTML. Query catalog, publication state, allowed attributes and associated facts within a bounded consistent read where possible; add transaction-aware domain readers rather than move catalog ownership into unrelated code. Capture one database evaluation time for scheduled content and pricing.

The initial renderer must not call existing product, family and theme endpoints independently and combine mismatched snapshots. It loads one page view with only anonymous published theme/configuration and bounded data. Enforce pagination and batch queries for lists and children. No full-catalog memory load per page and no fallback to eventually consistent search as the source of current price/stock.

First response after a committed change must observe current eligibility on a new request; an already-started database snapshot may finish with its earlier consistent state. Stages 09/11 introduce caching only after proving freshness gates below. These are proposed acceptance budgets, not measured production SLAs.

## Freshness and invalidation design

Any later cache key includes `(installation_id, canonical_host, channel, locale, currency, public_region, normalized_route, public_contract_version, relevant_publication_revision, renderer_build_id)`. Customer/session/precise location/coupon data never enters a public cache value. Preview and personalized responses bypass it. Unknown filter combinations are not cacheable.

| Change | Invalidation/dependency action |
| --- | --- |
| Product, media or attribute definition | Product/family views, affected category pages, discovery eligibility and feed entries; public attribute visibility changes invalidate all dependent products |
| Inventory reservation, release, fulfillment or source/area change | Re-evaluate affected offers and availability; source topology may affect many SKUs and requires an installation-wide dirty generation |
| Promotion or pricing schedule | Re-evaluate public pricing at writes and the next start/end boundary; exclude private/cart-conditioned rules |
| CMS publish/unpublish or release boundary | Page, linked policy and merchant outputs; a clock boundary invalidates without waiting for an event |
| Review approval, rejection or customer resubmission | Visible reviews and full approved aggregate; add missing invalidation to resubmission if caching is introduced |
| Theme assignment/version, merchant policy or discovery settings | Dependent public pages; domain/indexing changes immediately deny old-host publication and invalidate discovery outputs |
| Deletion, inactive product, slug change | Tombstone/redirect handling, category lists, sitemap and feed removal; retain durable removal knowledge where required |

Use the transactional outbox. Consumers deduplicate event ID, scope to the installation, map entity dependencies and re-read current state. Reordered/duplicate events must never replace newer artifacts. Add an installation publication generation advanced in the transaction for public-affecting writes; it is invalidation metadata, not a product copy. For high-volume stock changes use per-product generations plus an installation dirty marker where suitable, with contention measured in Stage 11. Audit events alone lack a sufficient monotonic public version; add explicit publication events/generations as needed without changing their existing meaning.

Initial optional cache ceiling: 30 seconds, clipped to the next known schedule boundary; no stale-while-revalidate for price, availability, domain, eligibility or policy. At every serve, check authoritative environment/indexing policy and safety generation before returning a cached response; if that check fails return no-store 503. Domain unapproval, unpublish and privacy removals must not wait for TTL. If those conditions cannot be proven, keep shared caching disabled.

Stage 09 feed/sitemap artifact workers stream bounded database pages under a defined snapshot/generation, write to a temporary installation namespace and atomically publish only if generation is still valid. Proposed normal update target: within 60 seconds; scheduled transitions must be gated by the next boundary, and a dirty or expired artifact is not served as current. Artifacts are rebuildable, with generation/created-at/expires-at recorded. Source errors return 503 or suppress invalid entries explicitly; no silent stale offer fallback. Reconciliation every five minutes catches missed dependencies and supports full rebuild. These numbers must be tested under load, not presented as achieved.

## File-impact map for later stages

All new module names are proposed; existing paths are relative to the repository root.

| Stage | Existing code surfaces | Proposed additive surfaces and validation |
| --- | --- | --- |
| 02 | `api-gateway/src/discoverability.rs`, `src/main.rs`; admin discovery component; API-client discovery/OpenAPI; `deploy/ec2/configure.py` | `public_commerce/policy.rs`, installation/domain migration; effective-policy DTO/UI; edge header and HTML policy integration. Gateway permission/host tests, admin tests, generated-config and real HTTP fixture tests. |
| 03 | Storefront `src/main.tsx`, `catalog.tsx`, `themes.tsx`, `content.tsx`, package/Vite configuration; deploy build/service wiring | Public view assembler/readers; `src/public/*`, client/server entries and Node server. Production-built HTML/status/hydration tests. No assistant module edits. |
| 04 | Catalog slug model/writes, route builders, frontend product/category links | Installation-local redirect/history migration and canonical resolver. Alias, loop, deleted-ID and overlapping-slug tests across two installations. |
| 05 | Product/category/CMS admin editors; public view/presentation and media | Additive SEO overrides, deterministic head renderer, metadata/image/link checks and escaping coverage. |
| 06 | Catalog families, inventory, pricing, reviews, attribute definitions | Typed public fact assembly and structured-data serializer; page/JSON-LD parity tests, hidden attribute and private-price exclusion tests. |
| 07 | Effective policy, public route enumeration, proxy configuration | Gateway robots/sitemap writers, optional llms writer and provider rules; sitemap streaming and crawler-access HTTP contracts. |
| 08 | Discovery settings, domain-cms, content admin and public presentation | Approved merchant entity/policy fields and references, useful content publishing, safe locale handling and draft exclusion tests. Existing merchant analytics module remains outside the publishing model. |
| 09 | infra-events outbox, domain write boundaries, export-worker conventions | Public feed adapters/workers and publication-generation migrations; idempotence, schedule, deletion, stale artifact and recovery tests. Do not alter unrelated export behavior. |
| 10 | Storefront analytics, gateway analytics/reporting, infra-observability | Additive source detail preserving old categories, publication health metrics; attribution and privacy regression tests. |
| 11 | Public assembler/renderer, ingress, cache/worker modules | Query indexes only with plan evidence; bounded concurrency, tenant isolation, escaping, resource budgets and load checks. |
| 12 | Existing test runners and CI/deployment fixture surfaces | Dedicated two-installation production-like fixture and end-to-end acceptance evidence; release/rollback report. No production rollout inferred. |

## Migration risks and mitigations

| Risk | Required mitigation |
| --- | --- |
| New runtime replaces static serving | Atomic release of matching Node/server/client manifests; health check before switch; retain previous artifact; renderer failure returns 503, not a successful empty shell. |
| False production enablement | Separate environment kind, approved host binding and observed header state; preserve demo/admin defaults. |
| Domain/slug edits break old links | Backfill existing IDs/slugs; preserve ID routes and same-installation redirect history; test collisions, loops and rollback before canonical switch. |
| Expanded public DTO leaks data | Construct allowlists including unknown-attribute rejection; strict anonymous theme context; never serialize audit/admin records. |
| Direct reads increase database load | Bounded page size, batched child/media reads, timeouts and measured query plans; initially fail explicitly rather than mask failures with stale commerce data. |
| Event/schedule coverage gaps | Transactional generations, boundary timestamps, reconciliation, replay and lost-event tests. |
| API schema breaks clients | Additive fields/endpoints, regenerate contracts and run existing consumers; no rewrites of shipped migrations. |
| Currency/locale overclaim | Current USD and actual approved locale only; reject unsupported publication contexts. No translation or FX generation. |
| Untracked application baseline | Capture reviewed file hashes, stage exact new files only, and record that commits do not contain the application source. |

## Stage boundaries

Stage 02 owns an effective policy and proves it on an actual HTTP fixture, even before full public SSR exists. Stage 03 introduces a minimal coherent public view with rendering/status behavior; Stage 06 extends its facts rather than introducing a competing assembler. Stage 08 supplies optional richer entity/policy records. Do not delay privacy and installation validation until Stage 11.
