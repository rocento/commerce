# Internal linking policy

Public category navigation and breadcrumbs use current slugs from the installation snapshot. Breadcrumbs walk category parents with a visited set; bad legacy cycles cannot loop rendering. Categories expose direct subcategories and their own products, with bounded pagination. Product pages link to their category ancestry and at most four other active public products from the same category. Theme recommendation collections exclude the current product and other categories; other merchant-configured collections retain their approved scope.

A published CMS block may explicitly reference a product or category with a real anchor. The referenced resource can display up to six currently released guides that link to its current path or legacy UUID path. Expired, cancelled and draft content is excluded. Historical slug links remain usable through Stage 04 redirects; reverse guide lookup does not yet match every historical alias. No inferred brand or guide relationship is fabricated when no such data exists.

Root/category pagination retains `?page=N` in canonical identity. Search, delivery, cart and account controls stay private/noindex. Merchant-authored links remain subject to existing CMS/theme validation. This stage does not create tag pages, facet combinations, automatic brand landing pages or mass-generated text.

Verification lives in `backend/crates/api-gateway/tests/publication_rendering.rs` and the existing no-JavaScript/hydration browser check. Raw HTML evidence is under `SEO-GEO/Tests/stage05`.
