# Stage 06 architecture decision

Extend the existing typed, transaction-scoped public catalog projection, not a second SEO database. Public SKU, parent identity, existing approved scalar specifications and active family members come from catalog records. Snapshot pricing reuses the existing decimal promotion evaluator for unconditional catalog rules. Ambiguous conditional catalog pricing or automatic cart discounts suppress Offer output, with a diagnostic; coupons and customer/session data never enter publication.

JSON-LD is derived from the same snapshot used for visible HTML. The approved Stage 04 canonical remains authoritative. Distinct active variants retain separate canonical pages, while configurable parents expose their actual linked variants; grouped/bundle relationships are not mislabeled as variants. Availability stays the existing conservative location/checkout summary; no warehouse flag is converted to global InStock. Shipping/returns await complete approved policy data (Stage 08), so free-text policy pages alone cannot create policy schema.

## Ownership and consistency

`domain_catalog::public::Product` is the typed anonymous representation. It contains stable identity/slug/SKU/parent, public type, catalog price/currency/unit, category relationship, primary media reference and approved scalar specifications. `offer_eligible` and `price_diagnostic` are computed per request, never persisted. The snapshot adds current family members, configuration dimensions, canonical identities, measured media and a conservative availability summary. There is no new migration, SEO product table, job or cache.

The transaction remains repeatable-read/read-only. Active promotion times use its timestamp. The same transformed Product values render cards, primary detail, family details and JSON-LD. Pricing loads rules once per snapshot, preserves priority/ID ordering, and calls `domain_pricing_promotions::evaluate`; no percentage, rounding or stacking arithmetic is reimplemented. A 10% discount on USD 3.25 resolves through the existing evaluator to USD 2.92.

Offer eligibility requires a simple SKU in USD, valid nonnegative decimal price, and unambiguous unconditional catalog pricing. Any active conditional catalog rule (customer group, subtotal threshold or attribute conditions) or automatic cart rule conservatively suppresses all snapshot offers. This initial broad suppression favors correctness over coverage, even when an ambiguous rule may concern another product. Visible price then remains the catalog base with the existing cart-confirmation notice. Optional coupon rules do not change the no-coupon publication context. No coupon, session, delivery pin, private customer price or cart enters the snapshot.

The catalog API and database currently accept USD only. Unit tests also prove unsupported imported EUR/EGP/JPY values are not converted or offered; the database rejection is tested. Multi-currency selling is not added here.

## Specifications, availability and policies

Active product attribute definitions permit front-visible scalar values and explicit configuration selectors. Private/inactive/unknown definitions, files and nested values remain excluded. Merchant-defined labels and string/number/boolean values become visible labeled specifications and `PropertyValue` entries. This supports grocery, jewelry, fashion, pharmacy/skincare, electronics and general retail without generating domain claims. No medical or performance statements are inferred.

The legacy catalog in_stock flag is not a reliable location-independent stock promise: real stock depends on sources, reservations and delivery-area eligibility. The visible availability summary remains authoritative for this context, and JSON-LD availability is omitted for both flagged-out-of-stock and region-restricted cases. No InStock or OutOfStock is guessed.

Native SKU is published and visible. Brand, GTIN, MPN, condition, ratings and reviews have no verified typed publication mapping here and are omitted rather than inferred from arbitrary attribute labels. Approved scalar merchant brand/identifier facts can remain visible as specifications without being promoted to those special properties.

Stage 01 assigns approved policy fields/references to Stage 08. Published free-text pages named returns/shipping do not supply complete machine-readable return windows, destinations, fees or delivery times. Accordingly no MerchantReturnPolicy or OfferShippingDetails is emitted. The omission is tested.
