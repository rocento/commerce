# Rendering strategy

Stage 01 decision: **hybrid — request-time SSR for anonymous public pages, client-side behavior for private and transactional flows**, using existing Vite and React versions. No framework migration is selected.

## Alternatives considered

| Option | Catalog size/update behavior | Isolation, status and operational implications | Decision |
| --- | --- | --- | --- |
| Full-app SSR | Request-time reads handle changing catalogs without rebuilding every SKU | Requires moving account, location, map and theme bootstrap into SSR-safe paths; risks unrelated assistant and private flows | Rejected for this scope; too broad |
| Browser-driven prerendering | Requires crawling each URL again after changes; expensive with large catalogs | Existing session/theme/location gates and live API fan-out complicate consistent capture; stale price and static 404 handling require extra machinery | Rejected as primary publishing path |
| Static/incremental regeneration | Efficient reads after generation, but catalog churn needs job/dependency scheduling | New cache invalidation and deletion machinery must precede trustworthy price/stock; host-specific artifact isolation required | Deferred until freshness pipeline is proven |
| Hybrid public SSR | Work proportional to requested page and bounded related data; current facts read at request time | One Node renderer per installation beside the existing gateway; private app remains client-side; status chosen before body | Selected |
| Rust-generated separate SEO HTML | Avoids Node, but duplicates existing React/theme presentation | Risks divergence between visible React content and independently maintained HTML and loses reuse | Rejected as default |

Actual catalog size and request rate are unknown. The decision avoids requiring a full-catalog build and does not claim measured latency or scale capacity.

## Feasible implementation boundary

Vite supports separate client and SSR build entries, and React supports server rendering with matching hydration. The installed React 18.3.1 rendered a small HTML tree without browser APIs in the Stage 01 probe. This verifies the primitive only; the current storefront is **Not implemented** for SSR. [Vite SSR guide](https://vite.dev/guide/ssr), [React server rendering](https://react.dev/reference/react-dom/server/renderToPipeableStream), [React hydration](https://react.dev/reference/react-dom/client/hydrateRoot).

Add `src/entry-public-server.tsx`, `src/entry-public-client.tsx`, reusable `src/public/` presentation and a small `server/` Node HTTP adapter in the storefront package. Exact filenames may be refined without changing ownership. Build client and server artifacts with the installed Vite toolchain. Production runs the built renderer, never the Vite development server. Node 22.12+ is the repository's intended deployment baseline; the local feasibility probe ran on Node 25.9.0, so Node 22 runtime validation remains a Stage 03 gate.

Do not import `main.tsx` on the server: it mounts the DOM and imports browser-dependent flows. Extract only public presentational boundaries needed for home, category, product and published CMS pages. Move data loading into the public page view. Reuse theme tokens/components where safe; supply an anonymous published theme explicitly instead of executing ThemeProvider's session/preview effects on the server. Preserve configured theme appearance through regression screenshots, not a second stripped-down crawler theme.

Serve the same anonymous HTML to users and crawlers; no user-agent-selected content. Hydrate the same component tree and exact serialized DTO. Initialize per-request/per-browser query caches; no process-global query cache. Escape serialized state, including `<`, and never embed credentials, customer IDs or private props. Browser-only widgets may mount after hydration, but public text and links remain visible when account restoration or JavaScript fails. Never replace server-rendered content with a session-loading screen.

Cart/account/checkout/login and existing assistant routes continue through the legacy client app with noindex/no-store. Navigation from public pages to private routes can use normal document navigation initially to avoid an unrelated router refactor. Public navigation must load matching view data and update metadata; unknown routes go through the server's status resolver. Do not modify assistant modules or their behavior.

## Request lifecycle and statuses

1. Validate approved host and installation binding before any public data request.
2. Resolve path/alias, normalized public locale/currency, and eligibility in the gateway. Use the fixed internal gateway target; do not forward browser cookies, bearer tokens, arbitrary delivery coordinates or proxy headers into the assembler.
3. Obtain one page DTO with authoritative status, canonical policy, public facts, published theme and freshness boundary. Determine status before streaming. Bound upstream timeout and cancel work if the client disconnects.
4. Render useful initial HTML, metadata and later JSON-LD from that DTO. Do not send 200 while waiting to discover whether the product exists.
5. Hydrate public UI with matching props; initialize customer/session-dependent controls separately.

| Route/result | Response |
| --- | --- |
| Eligible public page | 200; indexing policy applied; initial dynamic response no-store |
| Existing but sold-out product | 200 with truthful availability; not automatically 404 |
| Missing/inactive product or unpublished content | 404, noindex, no-store; no data from inactive records |
| Deliberate permanent removal with an explicit tombstone | 410; do not infer removal history from missing data |
| Approved old slug or same-installation host alias | Permanent redirect to approved target; no redirect loops or untrusted destinations |
| Unknown/mismatched host | 421, noindex, no-store, no canonical |
| Database/view service unavailable or malformed required view | 503, no-store, noindex; retry guidance where appropriate |
| Private/transactional route | Existing client entry; noindex/no-store; API authentication unchanged |
| Arbitrary unknown route | Real 404 rather than unconditional SPA fallback |

Stage 04 defines slug routing and redirect details; Stage 03 must already distinguish known public, known client-only and unknown routes using current IDs.

## Runtime and rollout

Run a renderer bound to each installation's fixed gateway on a private interface/container network. The existing proxy maps approved storefront hosts to that renderer, assets to the corresponding immutable build, and `/api/` to the existing gateway. Admin/apex behavior remains separate. Publication routes such as robots/sitemap/feed can proxy to gateway writers, with content types and statuses preserved.

Extend storefront-only build and deployment wiring; preserve the corporate build branch unchanged. Version the renderer, client manifest and public contract together, and retain a compatible previous build for rollback. Health/readiness must distinguish process liveness from gateway and manifest compatibility. No origin/CDN HTML caching at first. Introduce shared caching only under the target architecture's generation and safety rules.

## Stage 03 proof obligations

Use built production artifacts and an isolated gateway/PostgreSQL fixture: anonymous no-JavaScript home/category/product/CMS HTML; real 404/503; theme parity; hydration without mismatch; cart/login/private-route regression; direct deep links and browser navigation; matching client/server builds; host spoof rejection; two installations with overlapping IDs/slugs; a configured-delivery-area store without a selected location. Run an upstream-failure case without serving an empty shell as 200. Preserve image/media and variant behavior. A synthetic React probe alone does not satisfy these gates.

## Stage 03 implementation record — 21 September 2026

The selected hybrid is implemented in `src/entry-public-server.tsx`, `src/entry-public-client.tsx`, `src/public/`, and `server/`. Both entries render the same `PublicPage` from the exact serialized snapshot; script state escapes `<` and Unicode line separators. Theme tokens, global/section renderers and CMS blocks have been extracted from their browser providers and are shared with the existing app. Product presentation reuses the storefront's product/gallery/purchase CSS and published presentation choice. No crawler-specific content or User-Agent branch exists.

Rust `public_commerce::snapshot` owns the page/status envelope. `domain_catalog::public` projects explicit anonymous fields rather than serializing administrative products. Unknown/hidden/disabled attributes, media object keys, draft themes, unpublished CMS revisions and private customer context are excluded. Public attributes are currently scalar values with active visible definitions. Only primary image metadata is included in the initial projection; the existing interactive gallery/options remain in the shopper view.

The initial response includes catalog base price for simple products. Configurable/grouped/bundle items invite option selection rather than suggesting the parent's numeric placeholder is a purchasable price. Availability is deliberately conservative: configured regional stores say availability varies by delivery location; non-regional stores still confirm stock during shopping. No InStock or personalized offer assertion is generated.

Published theme product collections use bounded anonymous catalog queries, not personalized recommendation ranking. The existing live-search widget loads after hydration with its own query client; the server form works without JavaScript. Product purchase/options and personalized stock continue through a document navigation to `?shop=1`. This is an explicit transitional integration: inline cart/variant islands are not implemented. The meaningful product content never waits for that navigation or session restoration.

Build from `frontend/apps/storefront` using the installed toolchain:

```sh
node ../../node_modules/vite/bin/vite.js build
node ../../node_modules/vite/bin/vite.js build --ssr src/entry-public-server.tsx --outDir dist-server
node server/seal-build.mjs
```

`build:publication` runs this sequence. Deploy `dist`, `dist-server`, server runtime and installed workspace dependencies from the same release. The seal records SHA-256 of the public template and SSR entry; startup rejects mismatches. Use Node 22.12+ with `NODE_ENV=production`. `PUBLICATION_APPROVED_ORIGIN`, `PUBLICATION_INSTALLATION_ID`, `PUBLICATION_GATEWAY`, `PUBLICATION_ARTIFACT_DIR`, `PUBLICATION_SSR_ENTRY`, `PUBLICATION_PORT` and `PUBLICATION_BIND` govern the runtime. Defaults bind localhost:8081 and fixed gateway localhost:8080. `/health` is process liveness; `/ready` validates a live snapshot/binding/schema and artifact validity is checked at startup.

`compose.publication.yaml` adds an opt-in Node 22 renderer, read-only release mount and localhost-only port. `deploy/ec2/publication.py --host <approved-host> --gateway-port <port> --renderer-port <port>` sends merchant documents to Node and APIs to Rust. Keep PUBLICATION_NOINDEX=true through installation-specific rollout checks. No deployment was performed in Stage 03. Do not apply the overlay to demo/admin services.

Local evidence uses real PostgreSQL and the Rust gateway, production-built Vite entries, curl, Chromium with and without JavaScript, an assigned published theme distinct from its draft, and a second installation with overlapping catalog identifiers. Full merchant-theme screenshot parity across every published theme and a deployed TLS/CDN response remain separate rollout checks; local screenshots are retained as fixtures, not production screenshots.

## Stage 12A reconciliation — 22 September 2026

The Stage 01 feasibility text above is historical. Public hybrid SSR is implemented; candidate client/SSR builds, raw HTTP tests and Node 22 checks are recorded in the Stage 12A report. The supported interaction remains document navigation to private shopping flows. Full theme/live-client parity is a Stage 12B requirement. See the [final report](../Reports/SEO-GEO-final-report.md), [architecture](architecture.md) and [operations](operations.md) for current acceptance scope and first-client gates.
