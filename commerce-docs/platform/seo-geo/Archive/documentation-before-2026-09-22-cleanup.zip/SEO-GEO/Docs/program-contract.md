# Rocento SEO/GEO program contract

Established: 21 September 2026. Stage 00.

## Scope and sequencing

Follow `Rocento-SEO-GEO-Staged-Prompts/00-program-contract.md` and the numbered stage prompts. Execute one stage at a time. The acceptance gate must pass and its report must be committed before the next stage starts. A failed critical gate stops progression and is recorded with its dependency and recovery action.

Approved amendment, 22 September 2026: the user requested that remaining live validation take place with the first client. Stage 12 preparation may proceed from the recorded local Stage 11 evidence; its live acceptance phase incorporates all remaining Stage 11 target-environment checks. Missing live evidence remains Blocked until the client environment is available. This exception does not authorize bypassing a failed security/privacy test, enabling public indexing, or issuing a release GO. See [the first-client live-validation plan](first-client-live-validation.md).

Included: merchant storefront publishing, supporting catalog/content/admin APIs, merchant identity and policies, SEO metadata, public product facts, deployment indexing, feeds, measurement and validation.

Excluded: the corporate website under `frontend/apps/website`, shopping assistants, prompts, LLMs, tools and orchestration, unrelated administration and deployment work. Shared changes must be additive where possible, justified and regression-tested against existing consumers. Reading excluded code for boundary identification does not authorize modifying it.

Stage 00 changes documentation only. Stage 01 verifies the architecture and designs the public commerce contract; neither stage authorizes broad feature implementation.

## Binding engineering rules

1. Catalog and approved merchant/content domains remain authoritative. Never introduce a second SEO-only product database.
2. Do not fabricate price, discounts, availability, identifiers, brand, reviews, ratings, shipping, return policies or medical claims.
3. Visible pages, metadata, JSON-LD, sitemaps and feeds must agree, with documented freshness and failure behavior.
4. Every public output must be scoped to its installation/tenant and approved host. Host/tenant resolution is a Stage 01 design gate, not an assumption.
5. Canonicals must not target localhost, admin, demo, staging, another tenant or an unapproved host.
6. Demo, staging and admin remain non-indexable by default. Stored indexing preferences must not falsely imply deployment headers have changed.
7. Never publish customer, order, cart, address, private-price or credential data for discovery. Robots directives are not authorization controls.
8. Public catalog content must not wait for customer-session restoration.
9. Missing or removed pages need appropriate HTTP statuses; a client not-found screen with HTTP 200 is insufficient.
10. Avoid keyword stuffing, doorway pages and mass-generated low-value content.
11. Treat llms.txt as optional. Do not promise rankings, indexing, rich results or external AI citations.
12. Verify provider-specific crawler behavior from current official documentation when implementing it.
13. Preserve existing tests. Never disable tests to obtain a passing build.
14. Preserve unrelated working-tree content; stage and commit only intentional program files.

## Repository findings confirmed for the starting contract

- Storefront uses Vite and React (`frontend/apps/storefront/package.json`, `vite.config.ts`), an empty initial root and generic title (`index.html`). Product data is loaded with React Query (`src/catalog.tsx`).
- `src/main.tsx` uses ID-based product/category routes and gates route content on completion of session restoration. Product/category models already include slugs.
- Admin discovery screens persist settings through `frontend/packages/api-client/src/discoverability.ts` to the Rust discovery API. No storefront consumer was found in the source assessment; Stage 01 must verify the whole publishing path.
- `deploy/ec2/configure.py` applies noindex headers to demo/admin hosts and uses an index.html fallback. This is evidence about generated configuration, not observed production responses.
- Public catalog availability depends on delivery context (`backend/crates/api-gateway/src/catalog.rs`). Attribution currently has no dedicated AI-referral category (`frontend/apps/storefront/src/analytics.ts`).
- No storefront metadata, Product/Offer/Breadcrumb JSON-LD, robots, sitemap or llms publishing implementation was found in the source assessment. These remain subject to Stage 01 end-to-end confirmation.
- Git has an unborn `master` branch and existing project files are untracked. Do not import the entire workspace into the Stage 00 commit. No application baseline commit or live indexing evidence is implied.

## Naming and implementation conventions

Keep the requested `SEO-GEO/Docs`, `SEO-GEO/Reports` and `SEO-GEO/Tests` casing. Use numbered kebab-case report names matching the prompts. Never overwrite a prior stage report during a later stage; add new evidence in that stage's report.

Rust lives in `backend/crates`, with forward-only timestamped SQL under `backend/migrations`. Preserve existing migration history. React TypeScript lives in `frontend/apps/storefront/src` and `frontend/apps/admin/src`; shared contracts live in `frontend/packages/api-client/src`. The gateway OpenAPI output and generated TypeScript schema must remain aligned when contracts change.

## Test-location mapping

| Program area | Existing execution location |
| --- | --- |
| Rendering, metadata, canonicals, redirects, HTTP status | Rust public publishing tests under `backend/crates/api-gateway/tests`; frontend unit tests beside changed source; production-like HTTP contracts to be selected in Stage 01 |
| Structured data, robots, sitemap, crawler access, feeds | Unit tests beside the responsible Rust module and integration tests in the gateway test directory; deployment tests in `scripts/tests` where relevant |
| Attribution | Vitest tests beside storefront analytics; gateway/reporting integration tests if event contracts change |
| Tenant isolation | Gateway integration tests plus deployment/host-routing tests and production-like HTTP coverage |
| Admin controls and browser regressions | Existing Playwright tests under `frontend/e2e`, using the appropriate existing configuration |

`SEO-GEO/Tests` is a coverage index, not a second test runner. Its area directories are prepared for evidence or contracts that do not belong to an established runner. New default suites must not contain intentionally failing characterization cases. Stage 01 may refine this mapping once ownership is decided.

## Commands and prerequisites

These commands are recorded from manifests, CI and test configuration; this document does not claim they were executed successfully.

Prerequisites: repository-documented Node 22.12+, pnpm 10.32.1, stable Rust, Python for deployment checks; isolated PostgreSQL with CREATEDB for SQLx integration tests. Browser tests require installed Playwright browsers and their configured fixture services. Do not read or copy private credentials into reports.

From `frontend`, start with the relevant narrow checks:

```sh
pnpm exec vitest run apps/storefront/src/<changed-area>.test.ts
pnpm --filter @commerce/storefront typecheck
pnpm --filter @commerce/admin typecheck
pnpm --filter @commerce/storefront build
pnpm --filter @commerce/admin build
```

`<changed-area>` is a template, not an existing test. Existing broad frontend CI commands are `pnpm lint`, `pnpm typecheck`, `pnpm test`, `pnpm build`. Recursive typecheck/build includes the corporate website: do not edit its source to resolve unrelated failures. Record unrelated failures separately. Vitest excludes `e2e/**`.

Browser commands from `frontend`: `pnpm test:admin`, `pnpm test:improvements`, `pnpm test:search`, `pnpm test:themes`, `pnpm typecheck:admin-tests`. Select coverage appropriate to the change; do not run fixture-mutating tests against a real merchant environment. The default admin config targets localhost:5174 unless explicitly configured otherwise.

From `backend`:

```sh
cargo test -p api-gateway discoverability::tests --locked
cargo test -p api-gateway --test catalog --locked
cargo fmt --all -- --check
cargo clippy --workspace --all-targets --locked -- -D warnings
cargo test --workspace --locked
cargo build --workspace --locked
```

Database-backed tests need an isolated `DATABASE_URL`; no connection secret is embedded here. From the repository root, the existing deployment test command is `python3 -m unittest discover -s scripts/tests -p 'test_ec2_deployment.py'`.

For shared API changes, from the root run `python3 scripts/generate_openapi.py`; from `frontend` run `pnpm generate:api`, then inspect the exact generated diff and relevant consumers. Existing CI also checks `node ../scripts/sync-theme-contract.mjs --check` from `frontend`. Do not regenerate excluded assistant contracts without an actual compatible-contract requirement.

Full-stack smoke commands are recorded in `.github/workflows/ci.yml` and `README.md`. They create fixture data and sometimes interrupt services; use only an isolated test stack. Stage 00 does not start containers or run application suites because it changes no behavior.

## Evidence and stage reporting

Use these levels: **Implemented**, **Verified**, **Partially verified**, **Not implemented**, **Blocked**, **Future enhancement**. Separate source evidence from executed checks and live observations. Do not label the platform complete, optimized, GEO ready or production ready without the applicable acceptance evidence.

Each implementation stage inspects the current tree, records an architecture decision before major edits, implements the minimum coherent slice, adds material unit/integration/HTTP coverage, runs narrow checks before broader relevant suites, and records exact commands, exit results, limitations and acceptance evidence.

Reports use all headings required by the prompt: Repository findings; Architecture decision; Implemented; Files changed; Tests run and results; Acceptance evidence; Performance/security observations; Partially verified; Not implemented; Blocked; Follow-up for the next stage.

## Justified deviations

Reuse existing test runners and source-adjacent test locations instead of duplicating them under `SEO-GEO/Tests`, as expressly permitted by Stage 00. Empty area directories are local scaffolding; Git records the coverage index, and future evidence files will preserve the individual directories as needed.

The initial commit contains only Stage 00 program documents. The existing untracked application tree is preserved, so the document commit alone is not a reproducible application baseline. Stage 01 must record this limitation when describing source revision provenance.
