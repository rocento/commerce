# Domain and proxy trust — Stage 02

## Installation boundary

One gateway process uses one database. The new singleton `platform.publication_installation` holds a generated UUID. Production configuration must name that UUID; a missing, malformed or mismatched binding rejects startup. The ID is not selected by Host and is not the assistant tenant ID. A restore of the same installation retains the UUID. Provision a distinct UUID and approved host mapping for an independent clone before allowing it to serve public traffic.

The operator supplies one `PUBLICATION_APPROVED_ORIGIN` per installation. This is an explicit deployment trust boundary, not an automatically verified customer claim. Merchant canonical changes cannot expand this mapping. Public origin values require HTTPS, a normalized root URL, DNS labels and no credentials, query, fragment or nonstandard port. IPs, localhost, local/internal labels and admin/demo/staging labels are rejected. No localhost canonical exception is implemented: local tests connect to loopback with a production-like Host. Normalized HTTPS port 443 is accepted; arbitrary local ports cannot become production canonicals.

## Proxy behavior

The gateway validates the single Host header for public HTML and robots against its configured origin (case-insensitive DNS; optional explicit :443). It ignores Forwarded and X-Forwarded-Host entirely. The production merchant vhost passes `$host` for HTML, strips both forwarded authority headers and rejects any unexpected `$host` before location handling. The API location pins the configured merchant host and remains noindex/no-store. No host or canonical input determines an upstream URL, database DSN or filesystem path.

The deployment keeps gateways private. Configure a rejecting ingress default server once per ingress, without duplicating existing default_server declarations. Even if a request falls through to the merchant vhost, its explicit host guard and gateway guard prevent HTML publication under an unknown authority. Existing demo/admin proxies are not globally changed.

No public HTML cache is enabled. The generated vhost disables proxy caching and forwards origin policy headers. Operators must preserve CDN bypass for dynamic HTML and APIs. The Admin screen explicitly reports external headers as unobserved. This stage does not claim it can discover unknown CDN overrides or prevent a privileged deployment operator from configuring the wrong origin.

## Threat cases covered

- Forwarded host cannot authorize an attacker Host or change canonical output.
- Unknown or duplicate Host is rejected for publication.
- Merchant cannot save another installation's approved canonical through its own configured API.
- A valid admin session in database A cannot mutate database B.
- Production on/off preferences cannot override noindex deployment protection.
- Demo, staging, admin and development environments remain blocked regardless of preferences.
- Configuration changes retain permission checks, revision conflicts, CSRF request-header/origin checks, audit and outbox entries.
- Internal API responses remain non-indexable, including direct gateway responses.

## Limits and next-stage work

This stage allows one approved canonical authority; aliases and redirect lifecycle are Stage 04. No real public DNS/TLS/CDN configuration was modified or probed. Public-page data and real resource statuses remain Stage 03. Provider-specific crawler handling remains Stage 07 and requires current official provider documentation. Full UI browser interaction was not run; the effective panel's rendered output and server/API parity were tested independently.
