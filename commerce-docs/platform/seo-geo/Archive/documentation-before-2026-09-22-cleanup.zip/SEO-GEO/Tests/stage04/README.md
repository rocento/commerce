# Stage 04 evidence

All data belongs to isolated synthetic merchant fixtures. HTTP captures are actual `curl --include` output from production-built React/Vite public entries, the Node renderer, Rust gateway and PostgreSQL 16. CRLF headers are preserved by the local Git attributes.

Core sources:
- `backend/crates/api-gateway/tests/publication_rendering.rs`: retained Stage 03 checks plus Stage 04 canonical lifecycle, normalized queries, Unicode/collision/concurrency, deleted resources, active variants, independent installation origins, migration backfill and rollback checks.
- `backend/crates/api-gateway/tests/publication_policy.rs`: settings/environment/host isolation regressions.
- `backend/crates/api-gateway/src/public_commerce/canonical.rs`: canonical adapter equality unit test.
- `frontend/apps/storefront/server/publication-checks.mjs` and `url-policy-checks.mjs`: Node 22 HTTP, hostile canonical identity and URL-policy contracts.
- `frontend/e2e/publication-check.mjs`: real browser hydration, navigation and JavaScript-disabled documents; explicit mocks only for the existing search/account/cart widget regression segments.

`legacy-id-301`, `history-first-301`, `history-previous-301`, and `normalized-history-301` all point directly to the URL in `canonical-product-200`. `canonical-pagination-200` preserves page identity. `canonical-identities.json` records equal HTML/JSON-LD/sitemap/feed values from the central service. `tenant-b-canonical-200` proves a separate database/host produces its own origin. The remaining captures retain prior rendering/status regressions under Stage 04.

Reproduce after building/sealing the storefront using an isolated DATABASE_URL and:

```sh
PUBLICATION_BROWSER_CHECK=1 PUBLICATION_EVIDENCE_DIR=/absolute/path/to/SEO-GEO/Tests/stage04 cargo test --manifest-path backend/Cargo.toml -p api-gateway --test publication_rendering --test publication_policy --locked
```

Run Node contracts separately with `node --test frontend/apps/storefront/server/publication-checks.mjs frontend/apps/storefront/server/url-policy-checks.mjs`. Local listeners and the browser require the appropriate execution permissions. Fixture timestamps, installation UUIDs and local ports vary per run.
