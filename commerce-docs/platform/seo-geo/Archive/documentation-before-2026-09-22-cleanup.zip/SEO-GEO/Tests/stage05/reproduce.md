# Local validation

Run from the repository root with an isolated PostgreSQL database in DATABASE_URL. Do not target merchant data.

```sh
# Build in frontend/apps/storefront
node ../../node_modules/vite/bin/vite.js build
node ../../node_modules/vite/bin/vite.js build --ssr src/entry-public-server.tsx --outDir dist-server
node server/seal-build.mjs

# Repository root; export PUBLICATION_EVIDENCE_DIR to this evidence directory
PUBLICATION_BROWSER_CHECK=1 cargo test --manifest-path backend/Cargo.toml -p api-gateway --test publication_metadata --test publication_rendering --test publication_policy --locked
cargo test --manifest-path backend/Cargo.toml -p api-gateway --lib public_commerce --locked
cargo test --manifest-path backend/Cargo.toml -p api-gateway --test catalog --test catalog_schema --test attributes_types --test identity --test cart_inventory --test delivery_areas --test themes --test media_library --locked
cargo clippy --manifest-path backend/Cargo.toml -p api-gateway --all-targets --locked -- -D warnings
node --test frontend/apps/storefront/server/publication-checks.mjs frontend/apps/storefront/server/url-policy-checks.mjs frontend/apps/storefront/server/metadata-checks.mjs

# From frontend
node node_modules/vitest/vitest.mjs run
node node_modules/typescript/bin/tsc -p apps/storefront/tsconfig.json --noEmit
node node_modules/typescript/bin/tsc -p apps/admin/tsconfig.json --noEmit
```

Runtime: local Node 25.9.0 for build/browser; Node 22 container additionally verifies server checks. PostgreSQL 16 is disposable. `media-eligibility.log` retains an initial fixture failure (missing required product description); corrected coverage passes in integration.log/media-http.log. Raw metadata HTML uses synthetic dimension manifests; media-http.log separately verifies actual generated files through the real catalog endpoint and a local object-store fixture. No production observations or customer data are included.
