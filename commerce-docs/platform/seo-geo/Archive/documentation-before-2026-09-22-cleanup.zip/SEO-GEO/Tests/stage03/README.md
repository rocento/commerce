# Stage 03 evidence

Synthetic merchant fixtures only; no production customer data. `.http` files are actual `curl --include` responses from the built Node renderer backed by the live Rust gateway and isolated PostgreSQL. HTML before `publication-state` contains the visible catalog/content. Screenshots are Chromium output from the same fixture.

Sources:
- `backend/crates/api-gateway/tests/publication_rendering.rs`: SQLx fixtures, published/draft theme separation, raw HTTP statuses, policy, session independence, immediate freshness, two databases, upstream failure, optional curl/browser evidence.
- `backend/crates/api-gateway/tests/publication_policy.rs`: Stage 02 precedence, settings authorization, host and database isolation; now asserts the snapshot policy consumed by Node rather than the superseded public shell.
- `frontend/apps/storefront/server/publication-checks.mjs`: Node HTTP isolation, headers, query, status and serialization contracts; `node --test` runner, deliberately not a Vitest filename.
- `frontend/e2e/publication-check.mjs`: real built-page hydration/navigation and JavaScript-disabled checks. Search/account/cart regression segments explicitly mock shopper API responses; catalog HTML/status portions use the live database.

Run the two SQLx tests with an isolated DATABASE_URL, PUBLICATION_BROWSER_CHECK=1 and PUBLICATION_EVIDENCE_DIR set to this absolute directory after building and sealing the storefront. The test creates an ephemeral second database and removes it. Node server processes are killed on test exit. Browser screenshots and curl responses are reproducible fixture evidence; timestamps, ports and generated installation UUIDs vary.

HTTP captures preserve wire-format CRLF headers; the local Git attributes retain those bytes. Validation logs omit trailing blank lines.
