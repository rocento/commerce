# Stage 07 local reproduction

Use a disposable PostgreSQL 16 database, set DATABASE_URL, and run from the repository root. Tests create isolated databases and apply all migrations. PUBLICATION_EVIDENCE_DIR can point to `SEO-GEO/Reports/evidence/stage07` using an absolute path. The source tree also contains concurrent work excluded from this stage's commit.

```sh
cargo test --manifest-path backend/Cargo.toml -p api-gateway --test publication_discovery --test publication_policy --test publication_metadata --test publication_rendering --locked
cargo test --manifest-path backend/Cargo.toml -p api-gateway --test publication_discovery two_million_product_capacity --locked -- --ignored --nocapture
cargo test --manifest-path backend/Cargo.toml -p api-gateway --lib public_commerce --locked
cargo clippy --manifest-path backend/Cargo.toml -p api-gateway --lib --tests --locked -- -D warnings
node --test frontend/apps/storefront/server/*checks.mjs
python3 SEO-GEO/Tests/stage07/validate_xml.py
```

The capacity test is explicitly selected because it inserts two million synthetic catalog rows and four million alias reservations. Its bulk fixture temporarily bypasses only the per-row slug-normalization trigger, supplies already-normalized keys and all equivalent alias records, then restores that trigger before making any requests. It is not silently skipped for the stage's capacity evidence.

From `frontend/apps/storefront`, build the existing client/SSR publication artifacts before the rendering suite:

```sh
node ../../node_modules/vite/bin/vite.js build
node ../../node_modules/vite/bin/vite.js build --ssr src/entry-public-server.tsx --outDir dist-server
node server/seal-build.mjs
```

From `frontend`:

```sh
node node_modules/typescript/bin/tsc -p apps/admin/tsconfig.json --noEmit
node node_modules/typescript/bin/tsc -p apps/storefront/tsconfig.json --noEmit
node node_modules/eslint/bin/eslint.js apps/admin/src/crawler-settings.tsx apps/admin/src/discoverability-settings.tsx
node node_modules/vitest/vitest.mjs run
```

`validate_xml.py` uses system xmllint and the official unchanged schemas downloaded on 2026-09-21 from https://www.sitemaps.org/schemas/sitemap/0.9/sitemap.xsd and https://www.sitemaps.org/schemas/sitemap/0.9/siteindex.xsd. It validates the index and every resource class captured by real gateway tests. Node HTTP tests need permission to bind local sockets. In the desktop sandbox, rerun with the approved local-socket permission if listen EPERM occurs.

When other tasks are building this workspace, use unique Vite `--outDir` directories for both builds, seal those specific template/server files, and set absolute `PUBLICATION_ARTIFACT_DIR` and `PUBLICATION_SSR_ENTRY` before the Rust rendering suite. The fixture honors the artifact directory for its legacy shell too. Stage 07's final regression run used `.stage07-dist` and `.stage07-dist-server` to avoid a concurrent default build deleting the shared manifest.
