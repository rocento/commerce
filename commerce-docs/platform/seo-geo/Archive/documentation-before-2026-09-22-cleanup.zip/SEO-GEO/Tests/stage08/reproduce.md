# Stage 08 reproduction

Use a disposable PostgreSQL 16 database and set DATABASE_URL. Tests apply all migrations. Keep synthetic fixtures separate from merchant databases. Set PUBLICATION_EVIDENCE_DIR to an absolute output directory when capturing raw HTML.

Build storefront client and SSR entries with the installed Vite binary, then seal matching artifacts. Use unique output directories if other tasks are building this shared workspace. This stage used `.stage08-dist` and `.stage08-dist-server` under the storefront app; set PUBLICATION_ARTIFACT_DIR and PUBLICATION_SSR_ENTRY to their absolute paths for integration tests. The artifact manifest records SHA-256 for public.html and the SSR entry as in server/seal-build.mjs.

```sh
cargo test --manifest-path backend/Cargo.toml -p api-gateway --test publication_rendering --test publication_policy --test publication_discovery --test publication_metadata --locked
cargo test --manifest-path backend/Cargo.toml -p api-gateway --test admin_depth --test catalog --test catalog_schema --test attributes_types --test cart_inventory --locked
cargo test --manifest-path backend/Cargo.toml -p api-gateway --lib public_commerce --locked
cargo clippy --manifest-path backend/Cargo.toml -p api-gateway --lib --tests --locked -- -D warnings
node --test frontend/apps/storefront/server/*checks.mjs
```

From frontend, run installed TypeScript for apps/admin and apps/storefront with --noEmit, ESLint for changed Admin/public-storefront TSX files, and `node node_modules/vitest/vitest.mjs run`. Raw evidence is in `SEO-GEO/Reports/evidence/stage08`. No external indexing submission or production deployment is part of these commands.
