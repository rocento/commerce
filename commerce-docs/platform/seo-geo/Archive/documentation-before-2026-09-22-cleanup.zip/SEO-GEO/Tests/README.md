# SEO/GEO test coverage index

Status: **Not implemented** for new SEO/GEO behavior tests at Stage 00.

Prepared areas: rendering, metadata, canonicals, redirects, structured-data, robots, sitemap, crawler-access, http-status, feeds, attribution and tenant-isolation.

Use the test-location and command mappings in `../Docs/program-contract.md`. Prefer the existing Rust, Vitest, Playwright and Python runners. Later reports must link each acceptance requirement to actual test files, commands and results. This directory's presence is not test evidence.
