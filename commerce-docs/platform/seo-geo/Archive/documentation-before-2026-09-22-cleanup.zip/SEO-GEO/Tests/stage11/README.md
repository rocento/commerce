# Stage 11 local verification

All data is synthetic. Run from the repository root with installed frontend dependencies, Rust, Docker and Playwright Chromium. Use a disposable PostgreSQL instance; sqlx::test creates isolated databases and the matrix creates/drops an additional database. Never point this harness at a production database.

The recorded database was postgres://postgres:publication-test@127.0.0.1:51259/postgres in the disposable rocento-seo-stage11-pg container (postgres:16-bookworm). Production client and SSR builds were written to frontend/apps/storefront/.stage11-dist and .stage11-dist-server using installed Vite; their template/server hashes were sealed in publication-build.json as in earlier stages.

Set PUBLICATION_ARTIFACT_DIR and PUBLICATION_SSR_ENTRY to those absolute paths. Set PUBLICATION_EVIDENCE_DIR to an output directory when generating evidence. For the explicit benchmark also set STAGE11_RENDERER_ENTRY to this directory's renderer.mjs, STAGE11_CONTROL_FILE to a unique temporary JSON path, and STAGE11_LABEL to the desired output name. Optionally set STAGE11_BROWSER_SCRIPT to browser-performance.mjs to run the 24 browser samples while the test's gateway/database are live.

Recorded commands (from backend unless stated otherwise):

```sh
cargo test -p api-gateway --test publication_hardening
cargo test -p api-gateway --test publication_hardening measured_large_catalog -- --ignored
cargo test -p api-gateway --test publication_hardening --test publication_rendering --test publication_policy --test publication_discovery --test publication_metadata --test publication_feeds --test publication_measurement --test admin_depth --test attributes_types --test cart_inventory --test catalog --test catalog_schema --test customer_journey --test orders
cargo test -p api-gateway --lib public_commerce
cargo clippy -p api-gateway --lib --bin api-gateway --test publication_hardening -- -D warnings
```

From root:

```sh
node --test frontend/apps/storefront/server/*checks.mjs
node SEO-GEO/Tests/stage11/admission-probe.mjs /tmp/stage11-admission.json
NODE_ENV=production node SEO-GEO/Tests/stage11/browser-security.mjs
NODE_ENV=production node SEO-GEO/Tests/stage11/rollback.mjs
```

browser-security and rollback consume the synthetic tenant snapshot evidence. The rollback script loads renderer source from commit 2f7f773 and unchanged helper modules; it does not deploy anything. The benchmark wrapper's localhost metrics port exists only in this fixture, never in the production server. Browser performance uses a localhost fixed-host proxy and stubs the attribution endpoint; it is not a checkout measurement.

From frontend, installed tool entrypoints were used directly: node node_modules/typescript/bin/tsc -p apps/storefront/tsconfig.json --noEmit, the equivalent admin project command, and node node_modules/vitest/vitest.mjs run. pnpm's network-dependent wrapper was unnecessary.

before.json was captured before changing the product lookup and renderer admission. Rerunning today's benchmark produces after data. To reproduce the before state, use the prior committed public.rs/publication.mjs in an isolated complete workspace; do not overwrite concurrent working files. The source manifest records their original hashes. Builds and unrelated untracked application/dependency files are not duplicated in the Stage 11 commit.
