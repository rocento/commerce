# Stage 06 validation

Use an isolated PostgreSQL 16 database in DATABASE_URL, never a merchant database. Node 25.9.0 built the local client/SSR and ran Chromium; server checks also ran in Node 22. Browser and socket tests require localhost listener permissions.

From frontend/apps/storefront:
```sh
node ../../node_modules/vite/bin/vite.js build
node ../../node_modules/vite/bin/vite.js build --ssr src/entry-public-server.tsx --outDir dist-server
node server/seal-build.mjs
```

From the repository root, with PUBLICATION_EVIDENCE_DIR pointing at this directory:
```sh
PUBLICATION_BROWSER_CHECK=1 cargo test --manifest-path backend/Cargo.toml -p api-gateway --test publication_rendering --test publication_metadata --test publication_policy --locked
cargo test --manifest-path backend/Cargo.toml -p api-gateway --lib public_commerce --locked
cargo test --manifest-path backend/Cargo.toml -p api-gateway --test catalog --test catalog_schema --test attributes_types --test cart_inventory --test admin_depth --locked
cargo clippy --manifest-path backend/Cargo.toml -p api-gateway --all-targets --locked -- -D warnings
node --test frontend/apps/storefront/server/publication-checks.mjs frontend/apps/storefront/server/url-policy-checks.mjs frontend/apps/storefront/server/metadata-checks.mjs frontend/apps/storefront/server/structured-data-checks.mjs
```

From frontend:
```sh
node node_modules/typescript/bin/tsc -p apps/storefront/tsconfig.json --noEmit
node node_modules/eslint/bin/eslint.js apps/storefront/src/public/page.tsx apps/storefront/src/public/types.ts
node node_modules/vitest/vitest.mjs run
```

All retained data is synthetic. Local schema-shape/consistency checks do not represent external rich-result certification. Existing concurrent theme changes were present in the working tree during frontend validation and are excluded from the Stage 06 commit.
