# Stage 12A candidate validation

Date: 2026-09-22. Scope: local merchant publication validation and release-report preparation. First-client live gates are not executed here.

## Candidate provenance

`assemble.py` creates `/tmp/rocento-stage12a-candidate` and refuses to overwrite it. It copies selected current source and fixture files, including required uncommitted/untracked dependencies, while excluding real credentials, dependency/generated directories and the corporate website. It explicitly includes the documented nonproduction signing fixtures used by existing shared tests. Initial missing contract, preset, deployment and signing fixtures were corrected in the assembly; initial failure logs are retained. No test was removed to hide those failures.

The candidate manifest records source SHA-256 values and parent commit. Installed frontend dependencies are reused through symlinks; their lock metadata is recorded. Workspace-package symlinks can resolve into the original frontend tree, so the final audit also checks selected shared `frontend/packages` source against candidate hashes and rejects drift there. Original app-source drift is recorded separately: app entries are built from the isolated copy, not those workspace paths. This is a local candidate snapshot, not an independently deployable clean Git revision or a fresh dependency installation. Reassemble/revalidate if source or dependencies change before the pilot. `reconcile.py` verifies copied input hashes and the storefront seal, inventories historical reports and hashes generated storefront/Admin artifacts.

The Docker harness mounts candidate source read-only, uses a separate PostgreSQL 16 tmpfs database/network, and reuses only the Stage 11 compiler/registry caches. No client database or retired remote server is contacted. Its recorded image is `rocento-publication-release-verify`, built by the Stage 11 release Dockerfile with Node 22/Rust 1.94.1/Chromium. The absolute frontend dependency mount is specific to this local workspace and must be adapted on another machine.

## Commands

Frontend commands run in the candidate `frontend` directory, using the installed Node tool entrypoints:

```sh
node node_modules/vitest/vitest.mjs run
node node_modules/typescript/bin/tsc -p apps/storefront/tsconfig.json --noEmit
node node_modules/typescript/bin/tsc -p apps/admin/tsconfig.json --noEmit
```

From candidate `frontend/apps/storefront`, build with `node ../../node_modules/vite/bin/vite.js build`, then `node ../../node_modules/vite/bin/vite.js build --ssr src/entry-public-server.tsx --outDir dist-server`, then `node server/seal-build.mjs`. Build candidate Admin with the equivalent Vite command in `frontend/apps/admin`. Existing bundle-size warnings are retained, not suppressed.

From the real repository root:

```sh
docker compose -f SEO-GEO/Tests/stage12a/compose.yaml run --rm verify cargo test --release --locked -p api-gateway --lib --test publication_hardening --test publication_rendering --test publication_policy --test publication_discovery --test publication_metadata --test publication_feeds --test publication_measurement --test publication_migration_upgrade --test admin_depth --test attributes_types --test cart_inventory --test catalog --test catalog_schema --test customer_journey --test orders --test identity --test delivery_areas --test media_library --test themes --test merchant --test reporting -- --test-threads=1
docker compose -f SEO-GEO/Tests/stage12a/compose.yaml run --rm -e PUBLICATION_BROWSER_CHECK=1 -e PUBLICATION_BROWSER_EXECUTABLE=/usr/bin/chromium verify cargo test --release --locked -p api-gateway --test publication_rendering -- --test-threads=1
docker compose -f SEO-GEO/Tests/stage12a/compose.yaml run --rm verify cargo build --release --locked -p api-gateway --bin api-gateway
docker compose -f SEO-GEO/Tests/stage12a/compose.yaml run --rm verify sh -c 'cd /workspace && node --test frontend/apps/storefront/server/*checks.mjs'
python3 SEO-GEO/Tests/stage12a/reconcile.py
```

Run the ten `test_ec2_deployment.py` and seven Stage 11 deployment-preflight tests from the candidate root using Python unittest discovery. Exact result logs are in this directory. Builds/typechecks succeed with exit 0; their empty logs are valid. The broader Vitest suite includes unchanged assistant-adjacent tests as existing regression coverage; no excluded feature code was changed.

The browser fixture tests real public database/gateway/renderer output, hydration, no-session startup, navigation and no-JavaScript HTTP statuses. Search suggestions and private account/cart API responses are explicitly stubbed; it is not a live search-engine or checkout E2E claim. Stage 12A fixes the fixture proxy to preserve HTTP methods and send `/api` to the actual gateway. It also supports an explicit browser executable, asserts the attribution POST response directly, uses DOM/UI readiness instead of keepalive-sensitive network-idle waits, and retains the child log pipe to prevent fixture-induced EPIPE exits. Initial timeout logs demonstrate the fixture defect.

Five pre-existing optional tests are skipped in the broad backend command: the customer-journey Admin preview, Meilisearch stock facets, two-million-product capacity, 50,001-product benchmark and ClickHouse assistant-report integration. The capacity/benchmark have historical evidence; service-dependent cases remain explicitly unverified for this candidate. Stage 12B must cover relevant real-client search/checkout/Admin/analytics flows. No full browser regression suite or new performance comparison is implied.

Stop only the disposable harness with `docker compose -f SEO-GEO/Tests/stage12a/compose.yaml down`. Keep evidence and source snapshot for review. Log carriage returns/trailing whitespace may be normalized; diagnostics are retained.

Focused host lint: from candidate backend, `CARGO_TARGET_DIR=/Users/momar/Documents/commerce-ai/backend/target cargo clippy --locked -p api-gateway --test publication_rendering -- -D warnings`. Result: exit 0.

Committed HTTP captures normalize CRLF to LF for diff review; response status/header/body content is retained.
