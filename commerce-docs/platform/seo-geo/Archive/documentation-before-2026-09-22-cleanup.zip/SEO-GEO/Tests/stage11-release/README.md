# Stage 11 Linux release rehearsal

This replaces the retired Quality server as a **local engineering validation environment**. It does not verify a live merchant deployment or CDN. All catalog, identity, image and credential data in the harness is synthetic. The repository mount is read-only; PostgreSQL data uses tmpfs on a private Compose network with no host port.

Prerequisites: Docker, installed frontend workspace dependencies and the matching sealed `.stage11-dist` / `.stage11-dist-server` artifacts described in `../stage11/README.md`. The Dockerfile defaults to Rust 1.94.1 Debian Bookworm, adds Node 22, Chromium, Nginx and OpenSSL. The recorded build reused local image `rocento-shopping-stage-9535d4d7-rust:latest` (Rust 1.94.1, Debian 12); use `--build-arg RUST_IMAGE=...` only for an equivalent local cache. No application code from that image is used: sources are mounted from this workspace.

Run from the repository root:

```sh
docker compose -f SEO-GEO/Tests/stage11-release/compose.yaml build verify
docker compose -f SEO-GEO/Tests/stage11-release/compose.yaml run --rm verify
# Explicit long workload: browser, proxy, bursts, 60-second sustained load, full paced feed.
docker compose -f SEO-GEO/Tests/stage11-release/compose.yaml run --rm verify cargo test --release -p api-gateway --test publication_release -- --ignored --nocapture
python3 SEO-GEO/Tests/stage11-release/verify_evidence.py
python3 -m unittest discover -s SEO-GEO/Tests/stage11-release -p 'test_*.py'
# Stop this harness after collecting evidence; preserve only compilation caches.
docker compose -f SEO-GEO/Tests/stage11-release/compose.yaml down
```

The default command runs all four hardening tests, including the 50,001-product benchmark, sequentially so the renderer metrics control file cannot race. The long workload is explicitly ignored in ordinary Cargo runs because it needs sealed artifacts, an evidence directory, Linux browser/proxy tools and several minutes. Do not replace its real one-second feed pacing with advanced database scheduler timestamps when reporting wall-clock throughput.

The representative catalog contains 2,001 products, 201 categories and 20 configurable children. All products reference one repeated, high-detail synthetic image; this tests real transfer/encoding/layout behavior, not a collection of unique photography. Two Node processes use one installation database. The actual media API reads original/derived bytes from an isolated in-memory S3-compatible fixture. Browser attribution is stubbed, so the workload makes no checkout or attribution-delivery claim.

Browser observations use fresh contexts, desktop/mobile viewports, 80 ms latency, 200,000 bytes/s download and 4x CPU slowdown. Three samples per page/profile are lab observations, not field percentiles or INP. The proxy uses the real generated merchant Nginx vhost and an explicitly trusted temporary certificate. A fixture bridge switches renderer replicas and simulates a dependency failure; this is not a production infrastructure rollback or CDN cache test.

## Deployment preflight

On the eventual merchant Docker host, run the read-only collector:

```sh
python3 SEO-GEO/Tests/stage11-release/deployment_gate.py --output /tmp/publication-deployment-gate.json
```

Exit 0 verifies only the collector's stated scope; exit 2 blocks release. It inspects Compose projects with a `publication-renderer`, persisted installation identity, origin agreement, unique network resolution, separate persistent PostgreSQL/MinIO scopes, matching private probe secrets and read-only renderers. Secrets are read in memory and omitted from evidence. Externally managed databases/object stores require separate verified evidence; absent deployments fail closed. A captured inventory may be reassessed with `--input`, which must contain trusted collector output's `inventory` object, not an invented inventory.

Make this command a required operator gate before enabling indexing or changing routing. It is not automatically integrated into every existing deployment launcher. Independently verify DNS, trusted public TLS, CDN/WAF, IAM/storage access, public routing and real rollback on the replacement hosting environment.

## Existing image migration

The release changes newly generated derivatives. For each existing referenced image, use the existing authenticated `POST /v1/admin/catalog/media/{id}/publication` endpoint (through the app proxy: `/api/v1/admin/catalog/media/{id}/publication`) with an own-installation session having `catalog.write`. Process a bounded list sequentially, record successful IDs and stop/retry failures. This updates only derivatives and dimension manifests; original uploads remain unchanged. The endpoint enforces the existing 5 MB input and decoder limits. Inspect representative media after regeneration; images not regenerated keep their old derivative encoding. No live backfill was run here.

Final verification also ran the six existing publication integration suites in release mode (33 passed; the two-million-product capacity test remains explicitly ignored), all 14 `public_commerce` unit tests, and `cargo build --release --locked -p api-gateway --bin api-gateway`. Host Clippy checks the library, gateway binary, hardening and release harness targets with `-D warnings`; the cached Linux image does not contain the Clippy component. See `regressions.log`, `publication-unit.log`, `gateway-build.log` and `clippy-host.log`. Node 22 server checks are recorded in `node22-tests.log` (28 passed).

Committed logs normalize carriage returns and trailing whitespace only; diagnostics and results are retained.
