# Stage 02 validation follow-up

Date: 21 September 2026. This report supersedes the regression hold in `02-effective-indexing-and-domain-policy.md`; that report is retained as historical evidence.

**Verified:** the remaining Stage 02 regression gate is cleared. Stage 02's previously recorded focused HTTP/policy/isolation acceptance remains valid; the refreshed frontend suite and typechecks now pass. This is not production deployment certification.

## Repository findings

The failing test required the grocery preset to equal the base theme exactly. `docs/demos/grocery-palette.md` explicitly defines approved grocery-only overrides: primary/success `#054828`, surface `#F1F4F0`. `scripts/grocery_palette.py` and its tests independently support preserving those three tokens without changing non-palette content. The old equality expectation conflicted with the established contract.

## Architecture decision

Correct the regression expectation to compare the full preset against the default plus exactly the three documented values. Continue rejecting all other unexpected changes and editorial opt-ins. Do not alter the actual palette, base theme, runtime behavior or excluded systems.

## Implemented

Updated the existing test name and expected configuration. It still checks full deep equality, now with explicit approved values, and checks the actual grocery preset for editorial presentation opt-ins. No assertion was removed to ignore unexpected palette or structure changes.

## Files changed

- `frontend/packages/api-client/src/demo-presets.test.ts`
- `SEO-GEO/Reports/02-validation-follow-up.md`

The test file was previously untracked and is included in this follow-up commit. Existing shared working-tree edits to `backend/openapi.json` and `frontend/packages/api-client/src/schema.d.ts` are preserved and not staged.

## Tests run and results

Commands using Node run from `frontend`; the Python command runs from repository root. Installed local binaries avoid the package-manager wrapper's previously recorded automatic-install behavior.

| Command | Result |
| --- | --- |
| `node node_modules/vitest/vitest.mjs run packages/api-client/src/demo-presets.test.ts` | **Verified**: 7 passed |
| `node node_modules/vitest/vitest.mjs run` | **Verified**: 111 passed across 21 files, including the six Stage 02 effective-indexing display cases |
| `node node_modules/typescript/bin/tsc -p apps/admin/tsconfig.json --noEmit` | **Verified**: exit 0 |
| `node node_modules/typescript/bin/tsc -p apps/storefront/tsconfig.json --noEmit` | **Verified**: exit 0 |
| `node node_modules/eslint/bin/eslint.js packages/api-client/src/demo-presets.test.ts` | **Verified**: exit 0 |
| `python3 -m unittest discover -s scripts/tests -p 'test_grocery_palette.py'` | **Verified**: 9 passed |

Stage 02 backend, deployment and live local HTTP results remain recorded in the original report. They were not rerun for this test-only correction because no related production code changed in this follow-up.

## Acceptance evidence

The previously failing grocery assertion now matches an independently documented behavior while preserving strict comparison. The full frontend suite is green, resolving the specific hold. Combined with the prior Stage 02 origin HTTP, host isolation, authorization, audit and deployment-policy evidence, the Stage 02 implementation acceptance gate is **Verified**.

## Performance/security observations

No runtime, configuration, permissions, indexing or deployment behavior changed. Nothing was deployed or enabled in production.

## Partially verified

The original limitations remain: no live Nginx/TLS/CDN rollout, full interactive browser Admin session or Node 22 runtime certification. The repository contains concurrent work; the passing frontend results describe the current shared workspace, not a standalone application reconstructed from this document/test commit.

## Not implemented

Stage 03 rendering work. The interrupted Stage 03 turn performed reads only, and this follow-up resumes Stage 02 as requested.

## Blocked

No remaining Stage 02 regression hold from the grocery palette mismatch.

## Follow-up for the next stage

Stage 03 may begin under its approved design and acceptance requirements. Preserve the source-of-truth public commerce view, installation boundaries and policy behavior. Replace the transitional shell with server-visible catalog rendering and correct resource statuses.
