# Stage 09 — Product Feeds and Publication Freshness

Date: 2026-09-21. Scope: Rocento merchant platform public commerce publishing.

**Implemented:** durable publication invalidation, public representation versions, semantic sitemap timestamps, a provider-neutral feed contract, full/incremental admin exports, the reference adapter, bounded background reconciliation, retry/dead-letter handling and operational APIs.

**Verified:** local reference-feed acceptance pipeline, real HTTP storefront/JSON-LD/sitemap agreement, failure recovery and installation isolation. **Partially verified:** production throughput and external operation; no deployment or provider account was used.

## Delivered behavior

Catalog, approved merchant data and public pricing remain authoritative. A new migration records domain changes transactionally. The gateway worker assembles the same anonymous snapshots used by SSR, checks that no intervening domain generation invalidated them, and atomically commits derivative state and feed events. The snapshot includes an additive SHA-256 `representation_version`. Existing no-store rendering immediately reflects current public facts, metadata and JSON-LD.

Only meaningful public projection changes advance sitemap lastmod. Duplicate invalidations, private attribute changes, administrative timestamps and inventory flags that do not change the public availability statement leave it unchanged. Product, category, CMS and home resources participate in reconciliation. CMS release dates remain supported. Feeds and sitemap timestamps converge asynchronously; the report does not claim all surfaces change in one cross-service transaction.

Feed identities include installation, locale, explicit default market and product UUID. Events include eligible anonymous price, public availability wording, images, variants, attributes and the shared canonical URL. Deletion, unpublication, parent withdrawal, policy withdrawal and locale changes have tombstone semantics. Export/delivery recheck publication eligibility before exposing an old queued upsert. No private/customer pricing, inventory internals, storage keys or credentials are serialized.

A reference receiver persists the greatest event version per identity, tolerating duplicates and out-of-order events. Transient failures back off and stop after eight attempts; invalid items fail independently. Reconciliation repairs missing journal/receiver entries without falsely changing lastmod, and a periodic full scan detects a missed domain invalidation. Work is bounded to ten resources/deliveries per persisted one-second interval; full/incremental export pages contain at most 100 items.

Admin API additions use existing discovery permissions, installation binding, session authentication and CSRF middleware:

- `GET /v1/admin/discovery/feeds`: reconciliation status, job counts and item errors.
- `GET /v1/admin/discovery/feeds/export`: full or incremental export with a pinned watermark.
- `POST /v1/admin/discovery/feeds/reconcile`: audited rebuild request and failed-event retry, limited to one request per minute per installation.

The OpenAPI/client additions are backward compatible. Corporate website and shopping-assistant implementation were outside this change. Concurrent workspace changes were preserved; only explicit Stage 09 paths and additive generated-contract fragments belong to this commit.

## Acceptance evidence

| Test | Evidence level | Result |
|---|---|---|
| Create, price, public availability, image, deletion | Verified | Built storefront HTTP status/content, serialized snapshot, JSON-LD, sitemap and reference receiver agree after each change. |
| Public/private distinction | Verified | Private attributes, object keys and secrets excluded; internal stock flag/private metadata no-op preserves version and lastmod. |
| Full and incremental exports | Verified | Pinned historical watermark, page cursor, deletion redaction and 10,001 journal entries exported in bounded pages. |
| Retries and permanent item errors | Verified | Backoff prevents immediate retry; fixed error codes redact simulated token text; eight-attempt ceiling; valid replacement item proceeds. |
| Duplicate, out-of-order and stale work | Verified | Older receiver versions cannot overwrite newer; a controlled concurrent database change discards a stale snapshot batch. |
| Reconciliation recovery | Verified | Deleted journal/receiver entries, missed domain invalidation and missing tombstone are repaired; unchanged lastmod is retained. |
| Tenant isolation | Verified | Two independent databases/workers and identical product IDs remain isolated; one installation's admin session receives 401 on the other; wrong deployment binding fails. |
| Locale, currency and variants | Verified | Locale identity changes create old-scope tombstones/new-scope upserts; parent/child relationships and parent withdrawal propagate; unsupported EUR is rejected by the authoritative USD-only catalog. |
| Bounded catalog processing | Verified | 258 products reconciled through batches no larger than ten; 10,001-event export has no application-wide collection. |
| Sitemap capacity regression | Verified | Two million products; 2,003 index entries, 286,394 bytes; index plus three 1,000-URL partitions in 706 ms after fixture setup. This is not a two-million-product feed rebuild benchmark. |

Recorded checks:

- 28 publication/feed integration tests passed (9 feed, 9 rendering, 4 policy, 4 discovery, 2 media/metadata).
- Explicit two-million-product sitemap capacity test passed separately.
- 42 shared backend tests passed: admin, attribute types, cart/inventory, catalog and catalog schema.
- 13 publication unit tests and 19 Node renderer/transport checks passed.
- 119 frontend tests across 22 files passed; admin/storefront TypeScript checks and client/SSR builds passed.
- Rust Clippy with warnings denied passed.

Logs: `SEO-GEO/Tests/stage09/`. Raw synthetic pipeline evidence: `SEO-GEO/Reports/evidence/stage09/pipeline-*`; before/after snapshot/feed comparisons: `created.json`, `price-changed.json`, `availability-changed.json`, `image-changed.json`. The image-change fixture inserts measured metadata; separate existing media tests verify actual byte processing and authorization. `09-source-manifest.json` binds the Stage 09 sources and evidence.

## Operational limits and deferred work

**Not implemented:** Google/Meta feed transports, Search Console/IndexNow submission, provider credential provisioning, provider approval monitoring, anonymous provider feed hosting, production deployment and an admin feed dashboard. `SubmissionIntent` is a prepared data boundary, not a running submission service. Official Google Merchant, Search Console and IndexNow requirements were checked and linked in `product-feeds.md`; no external request submitted merchant content.

**Not implemented:** multi-currency checkout/pricing, market-specific authoritative stock/prices and simultaneous locale publishing. The current contract explicitly carries supported locale/default-market scope and rejects unsupported currency through the existing platform constraint. It does not invent conversions, translations or global stock availability.

**Partially verified:** production freshness SLA, large-catalog feed rebuild duration, high-write concurrency and external delivery. Five minutes is the delay between periodic passes, not an upper bound on full-catalog freshness. A generation change can invalidate an in-flight batch. A malformed public snapshot can stall its reconciliation batch until repaired; already queued deliveries continue. Category collection bounds are inherited from existing snapshots. The append-only journal has no automatic compaction, and export request-rate protection beyond authentication/bounded pages remains deployment work.

No indexing, ranking, citation, rich-result or provider approval guarantee is made.

Documentation: `SEO-GEO/Docs/product-feeds.md`, `SEO-GEO/Docs/publication-freshness.md`, `SEO-GEO/Docs/feed-operations.md`.
