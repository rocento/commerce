# Stage 08 — Merchant entity, useful content and GEO publishing

## Repository findings and architecture decision

Stage 07 supplied bound merchant robots, sitemaps and provider controls. The existing CMS already supported drafts, immutable revisions, publication, expiry and withdrawal. The public catalog exposed labeled scalar attributes and Stage 06 pricing/structured data, but the platform had no dedicated approved merchant profile or revision-bound policy/guide registry.

**Implemented** — reuse these foundations. Keep store name, locale and canonical identity in existing discovery settings; add a separately approved merchant public profile and references to existing CMS revisions. Use current canonical catalog facts for comparisons. No duplicate product database, generated articles, corporate website changes or assistant implementation changes were introduced.

## Implemented

- Approved legal/business name, description, public logo, country/region, descriptive delivery areas and social profiles; separately approved public contact and physical-location fields.
- Visible merchant information, current policy/guide links and effective dates in initial HTML. Existing product seller, price, regional caveat, attributes and variants remain visible; specifications have stable anchors.
- Supported Organization/ContactPoint/logo properties and merchant-owned WebPage publication dates from the same public projection. No inferred return windows, shipping promises, ratings, certifications or health claims in structured data.
- Revision-bound approval for shipping, returns, warranty, payment, buying/category/sizing/material/ingredient guides, comparisons, FAQs and care instructions. CMS remains the publication source of truth.
- Like-for-like comparison tables from 2–6 current public catalog products, with real prices, visible attribute labels and explicit missing values. AI_INFERRED/DERIVED attribute values are excluded from all anonymous public product facts.
- Public CMS links resolve aliases to canonicals and suppress private, missing, removed or unsafe links. Structured block text remains escaped, not executable HTML.
- Admin AI discoverability integrates earlier effective/crawler state, profile approvals, actionable completeness and policy-review reasons, current CMS publication states, and explicitly sampled industry attribute coverage. Media and product selection reuse existing catalog permissions.
- Additive authenticated entity API, validation, revision conflicts, CSRF/origin checks and audit events. The public-logo media reference is revoked when profile publication is withdrawn unless another published resource independently references it.

## Tests and results

| Check | Result |
| --- | --- |
| Publication integration | **Verified** — 18 passed: 8 rendering, 4 policy, 4 discovery, 2 media |
| Final representative merchant case | **Verified** — approved identity/logo, four policies, buying guide, two-ring comparison, grocery and jewelry products, revision changes and withdrawal |
| Shared CMS/catalog/industry/cart regressions | **Verified** — 42 passed |
| Public-commerce Rust unit tests | **Verified** — 13 passed |
| Node publication/structured-data checks | **Verified** — 19 passed |
| Frontend Vitest | **Verified** — 117 passed across 22 files in the shared tree |
| Storefront client/SSR build and matching artifact seal | **Verified** — isolated Stage 08 output directories |
| Admin/storefront TypeScript, changed TSX ESLint, gateway Clippy | **Verified** — exit 0 |

Reproduction commands and logs are in `../Tests/stage08`; raw HTML, snapshots and HTTP evidence are in `evidence/stage08`. Stage 07's explicit two-million-product capacity test was not repeated: its sitemap algorithm was unchanged. No existing test was disabled. Initial checks identified a MediaPicker prop mismatch, the repository's expected 400 validation status, and a Clippy boolean simplification; those were corrected and the affected checks rerun.

## Acceptance evidence

**Verified** — the representative merchant fixture publishes business identity, a logo reference, delivery-area text, shipping/return/warranty/payment policies, a ring-buying guide and a comparison of silver/gold rings. Grocery and jewelry product pages share the approved merchant identity. Synthetic policy terms are explicitly labeled as test merchant data; they were not copied into any real merchant installation.

**Verified** — initial HTML and JSON-LD contain matching approved identity. Public HTML includes merchant ownership, release dates, policy effective dates, canonical internal links, current prices and labeled comparison facts. The existing six-industry fixture still verifies grocery, jewelry, fashion, skincare, electronics and retail attribute labels and structured facts. Missing specifications stay explicit; no automatic health efficacy statement appears.

**Verified** — private contact/location values and media object keys do not enter public output while their disclosure flags are false. An explicitly AI-inferred health claim is absent from product HTML, embedded facts and JSON-LD. Script-like content renders as escaped text. Public product links remain canonical and private CMS links are suppressed.

**Verified** — approving contact details makes them public; disabling the profile removes them and its independent logo eligibility. A new policy revision invalidates the old approval. Missing effective dates and wrong-locale annotations suppress advertised policy links. CMS unpublishing returns 404 and removes the page from the sitemap. A's admin session cannot read B's profile, and B never receives A's profile values. Existing Host/database binding and private-media authorization tests remain green.

## Operational limits and partial verification

**Partially verified** — Admin UI was type/lint checked and its API exercised, but a live browser walkthrough of the new Admin controls was not run. No production DNS/TLS/CDN deployment or external crawler ingestion was tested. Local production-like requests use approved hosts over loopback and isolated PostgreSQL.

**Implemented** — single-storefront-locale matching for approved annotations. **Not implemented** — automatic translation, independent multilingual CMS routing or hreflang. Existing CMS text requires editorial language review; a mismatched annotation cannot manufacture a translated policy.

Coverage is a labeled sample of at most 1,000 active products and 100 visible definitions, not full-catalog certification. Merchant-entered prose and legacy catalog facts still require editorial verification; this stage does not fact-check medical truth or infer legal policy terms. CMS release dates identify editorial publication; live comparison prices can change independently. A complete combined public-change clock remains a **Future enhancement**.

**Not implemented** — production deployment/migration, search-console submission, AI drafting, automated content generation, llms.txt generation or policy-specific return/shipping schema inferred from prose.

## Scope and provenance

Concurrent analytics/customer-journey, theme and unrelated generated-contract edits were preserved and excluded from the stage commit. Only the entity endpoint and its additive schemas are staged from generated files. Source hashes and the stage file list are in `08-source-manifest.json`. The repository retains substantial untracked application source, so this stage commit alone is not a reproducible full-application baseline.
