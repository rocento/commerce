# Stage 05 — Metadata, on-page links and images

## Repository findings

Stage 04 (`fdc7e25`) already supplied installation-bound snapshots, raw HTML, canonical identity and slug history. Metadata was limited to title/description/robots/canonical. Shared theme heroes could emit multiple h1 elements. Images had no dimension/rendition projection; the media-by-ID endpoints had no publication eligibility check. Catalog/CMS content and existing discovery identity remain authoritative.

Scope is the merchant platform and supporting admin/media APIs. Corporate website and assistant implementation were not changed. Existing unrelated changes in `backend/openapi.json` and the generated TypeScript schema were preserved; only Stage 05 generated additions are included in the local commit.

## Architecture decision

**Implemented** — one Rust metadata resolver feeds the public snapshot and authenticated proposed-settings preview. A separate revisioned presentation settings record avoids copying product facts. Stable resource IDs preserve overrides through slug changes. Existing discovery identity, canonical and effective robots policy retain ownership. Node serializes escaped head tags; React renders semantic content and dimensioned images.

Image manifests are derived from real bytes and stored separately from authoritative originals. Public eligibility is a read-only view over published references. The first broad media edit/compile request was rejected by automatic approval review; the work was separated, the eligibility projection was tested, and the narrower authorization change was approved. No deployment or live merchant data was involved.

## Implemented

- Four page types: factual defaults, merchant templates, literal resource overrides, Unicode-safe guidance, OG/Twitter tags and qualified locale metadata. Social URLs use the approved origin; og:url uses the existing canonical.
- Admin settings, exact resolved preview, validation/fallbacks, revision conflict detection and transactional audit. Existing site-name/default-description controls remain in the same SEO area. Image picker and an authorized processing action support default social images.
- One primary heading; subordinate theme headings; labeled specifications; category ancestors/subcategories; bounded related products; published guide backlinks; real navigation anchors.
- Measured dimensions, actual 480/960 WebP renditions without upscaling, srcset/sizes, prioritized primary imagery, lazy secondary imagery, editable/contextual alt and truthful missing-image behavior.
- Private-media authorization, redacted public storage metadata, no-store delivery and revocation. Production robots permits image-content fetching under the otherwise disallowed API path; protected environments remain blocked.

## Files changed

Core work is in `public_commerce/{metadata,images,snapshot,policy}.rs`, the Stage 05 migration, catalog media handlers/public projections, the publication head writer, shared/public React rendering and admin metadata settings. The OpenAPI extension and generated schemas document the new controls. Tests reuse existing source-adjacent runners, with evidence in `SEO-GEO/Tests/stage05`.

`05-source-manifest.json` records source hashes. `05-existing-source-delta.patch` isolates edits to files first tracked in this stage; much of the application was already untracked before this project. This commit therefore does not claim to establish a fully reproducible application baseline by itself.

## Tests run and results

| Check | Evidence |
| --- | --- |
| Real PostgreSQL/gateway/renderer tests, including browser checks | **Verified** — 10 passed: 2 media, 3 policy, 5 rendering/canonical/metadata |
| Original/derivative image bytes, private access and revocation | **Verified** — actual decoding through the real catalog router and local HTTP object-store fixture |
| Node 22 server checks | **Verified** — 15 passed |
| Rust public-commerce unit tests | **Verified** — 8 passed |
| Catalog, schema/types, identity, cart, delivery, media-library and theme regressions | **Verified** — 55 passed; 1 pre-existing Meilisearch-dependent test ignored |
| Frontend Vitest | **Verified** — 116 passed across 22 files |
| Storefront client/SSR build and seal | **Verified** |
| Admin/storefront TypeScript and changed TS/TSX ESLint | **Verified** — exit 0 |
| Gateway all-target Clippy with warnings denied | **Verified** — exit 0 |

Commands and runtime details are retained in `Tests/stage05/reproduce.md`; logs record executed results. An initial image-policy fixture omitted a required description and was corrected. Removing self-recommendations exposed an older test expecting a product to link to itself; it now asserts the category-to-product anchor and rejects self-recommendations. No test was disabled.

## Acceptance evidence

**Verified** — `metadata-*.html` contains raw home/product/category/content HTML with distinct titles, exactly one canonical and one h1, consistent robots, complete social text tags, escaped Arabic/Unicode values, crawlable links and dimensioned responsive images when present. The product/social image fixtures use synthetic manifests; separate media HTTP tests prove actual derivative bytes and dimensions.

**Verified** — proposed metadata equals the subsequent live resolved metadata after save; saved product overrides survive a slug rename; category/content override previews and blank-description fallbacks resolve correctly; stale revisions return 409, invalid templates return 400, unauthorized reads/writes fail, and one successful save emits one audit event. Category/subcategory, related-product and guide anchors are asserted. Existing tests retain two-installation isolation, no-session/no-JavaScript rendering, hydration, status and canonical checks.

## Performance/security observations

No shared HTML/DTO cache was added. Settings accept at most 500 overrides. Image processing is bounded by file size, decoder limits and two concurrent tasks. Media reference checks prevent draft/unreferenced files from becoming public merely because their UUID is known. Public responses omit storage keys. Derivatives are published only after successful uploads; processing failures retain originals for an explicit retry. No price, stock, brand, review or marketing claim is fabricated.

## Partially verified

External CDN/WAF behavior, deployed S3, production-size media/reference-query performance, all merchant theme combinations and a full admin browser walkthrough. The old X card documentation redirected to the current X overview; local tag output is verified, external X/social previews are not. Existing API noindex headers remain on image responses, so image fetching is supported without claiming standalone image indexing.

## Not implemented

Production migration/deployment, bulk processing of live legacy images, old-CDN-cache purge, external search/social submission, translated hreflang, brand landing pages, arbitrary facet pages, structured-data/sitemap/feed outputs. Legacy images without processed manifests are omitted from public HTML until processed. Production rollout must perform that backfill and verify external responses first.

## Blocked

No blocker remains for the local Stage 05 acceptance gate. Production verification requires deployment access and installation-specific media processing/CDN checks.

## Follow-up for the next stage

Stage 06 should reuse the existing canonical identity, resolved public facts and measured images for structured data. Do not reinterpret overrides as product facts. Preserve private-media authorization, protected-host indexing policy and the rollout requirements in `Docs/image-publication.md`.
