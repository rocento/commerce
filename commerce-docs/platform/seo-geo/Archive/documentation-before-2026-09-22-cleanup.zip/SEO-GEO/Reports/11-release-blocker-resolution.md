# Stage 11 — release-blocker resolution follow-up

2026-09-21. Scope: Rocento merchant platform/storefront SEO/GEO.

**Engineering fixes and local Linux evidence are provided; production release remains blocked on a replacement hosting environment.** The owner confirmed that Quality host 63.182.240.84 is retired. A disposable Linux release rehearsal replaces that unavailable environment for independently testable checks. It does not turn local evidence into live deployment approval. Stage 12 has not started.

## Changes

- Fix the measured image-transfer bottleneck: encode 480/960-pixel WebP derivatives at quality 82 instead of lossless. Original uploads, dimensions, transparency, URLs and access controls remain intact. The synthetic alpha fixture shrank from 203,014 to 11,492 bytes at 480 px, and from 847,164 to 89,742 bytes at 960 px. Pixel tests verify exact alpha preservation and bounded opaque-color error; results do not guarantee equal compression or visual quality for every photograph. The encoder uses the fallible [WebP encoding API](https://docs.rs/webp/0.3.1/webp/struct.Encoder.html#method.encode_simple).
- Repair publication Compose wiring: gateway private renderer URL, required matching observation secret, renderer admission-limit passthrough and a shared read-only sealed artifact mount. Indexing stays disabled by default.
- Add a read-only deployment preflight that blocks missing identities, shared persistent database/media scopes, ambiguous service resolution, mismatched origins/secrets and missing read-only renderer configuration. Operator use is required; this is not yet wired into every deployment launcher.
- Add a reproducible Linux release workload, actual image-bearing browser checks, generated Nginx/TLS proxy rehearsal, sustained two-renderer traffic and full paced feed rebuild. Correct the original benchmark's build label so release runs are identified accurately.

Existing stored derivatives need authenticated regeneration through the existing media publication endpoint; no live backfill was performed. The bounded rollout procedure and commands are in [the rehearsal README](../Tests/stage11-release/README.md).

## Controlled browser result

Same synthetic catalog and original image, fresh Chromium contexts, production client/SSR bundles, Node 22 on Debian Linux; 80 ms latency, 200,000 bytes/s download and 4x CPU slowdown. Each value is the median of three samples.

| Page | Desktop before → after LCP | Mobile before → after LCP |
|---|---:|---:|
| Home | 1.540 → 1.548 s | 1.572 → 1.544 s |
| Configurable product | 7.744 → 2.160 s | 3.108 → 1.692 s |
| Category | 3.240 → 1.540 s | 1.340 → 1.340 s |

Desktop product LCP improved approximately 72%. All six page/profile medians meet the explicit local 2.5-second budget. These are lab observations, not field Core Web Vitals or measured field INP. All 2,001 products share one detailed synthetic image, so this is not a diverse photographic corpus. Search-focus/tab Event Timing candidates only check a short hydrated interaction.

## Release acceptance boundaries

| Original blocker | Follow-up status |
|---|---|
| Intended Node runtime and Rust release profile | Local Linux Node 22 / optimized Rust validation; details below. |
| Image-heavy configurable catalogs and taxonomy | 2,001 products, 201 categories, 20 configurable children, real generated/transferred image bytes; browser budgets pass. |
| Multiple renderer replicas and sustained load | Two processes in one installation, burst matrix and 60-second workload; this is not a long production soak. |
| Complete feed rebuild | Every resource reconciled with actual one-second scheduler pacing; sampled process RSS is not exact peak heap or total platform memory. |
| Proxy/TLS and rollback compatibility | Generated merchant Nginx vhost, explicitly trusted temporary certificate, foreign host 421, missing product 404, current replica switch/back-switch, simulated upstream failure 503 with no stale HTML and successful recovery. Earlier Stage 11 evidence covers prior Stage 10 application renderer compatibility. Neither test is a real infrastructure rollout/rollback. |
| Deployed installation/storage isolation | Collector and negative tests supplied. Actual local inventory has no deployed merchant installation and correctly returns Blocked; no real merchant storage topology was certified. |
| Public CDN/WAF, DNS/TLS, IAM and field performance | Still blocked: no replacement live hosting target is available in this task. |
| Historical pre-SEO baseline | Unavailable. Preserve Stage 10→11 measurements and the controlled encoding comparison; no historical telemetry was fabricated. |

The original Stage 11 report/manifest remain historical and unchanged. New evidence is in `evidence/stage11-release`; its follow-up source manifest identifies the inputs. Concurrent catalog, storefront theme, assistant, API-schema and evaluation work is outside this change.

## Measured Linux workload

Runtime: Node 22.23.2, Rust 1.94.1, Chromium 153.0.8010.52 and Nginx 1.22.1 on Debian 12 aarch64, hosted by the local Apple M4 Pro Docker environment. These are local capacity observations.

- Sustained: 16 workers, two renderers, 51,275 requests over 60.018 seconds, zero errors; p50 18.15 ms, p95 23.19 ms, p99 30.52 ms. Requests read complete response bodies; these are response latency values, not isolated server execution time.
- Bursts: concurrency 1/8/32 returned all 205 requests successfully. At concurrency 80, 303 of 400 succeeded and 97 received retryable 503 admission responses. Rejections represent the configured overload behavior, not successful request throughput.
- Full feed: 2,204 resources in 221 bounded batches, yielding all 2,001 product upserts. Active reconciliation/delivery cost was 10.44 seconds; actual paced wall time was 231.93 seconds. Test-process RSS sampled every ten batches peaked at 32,748 KiB. PostgreSQL, Chromium, renderers and between-sample peaks are excluded.
- Browser: maximum observed CLS 0.01194; short interaction candidates 16–120 ms. All 18 loads contained a decoded real image and no browser page errors.

The explicit evidence checker asserts complete sample counts, six median LCP budgets, CLS, sustained zero-error/p95 bounds, complete real-paced feed coverage and proxy recovery. `engineering-gate.json` passes with an explicit synthetic/local scope. `local-deployment-gate.json` remains Blocked; this is the correct result for an absent merchant deployment.

## Verification

- Four Linux release hardening tests passed, including the 50,001-product benchmark, installation/privacy matrix and database timeout/recovery.
- The explicit representative release workload passed; 18 browser samples and the Nginx/TLS checks passed inside it.
- All 33 existing publication integration regressions and 14 publication unit tests passed in Linux release mode. The separate two-million-product capacity test was not rerun. Existing rendering fixtures can emit Node child-teardown EPIPE diagnostics while their assertions pass; the raw log preserves them.
- All 28 Node 22 server checks and seven Python deployment/Compose contract tests passed. The saved local engineering evidence checker passed.
- The production gateway executable built successfully with `cargo build --release --locked` on Linux.
- Host Clippy passed with warnings denied for the library, gateway binary and both hardening/release test targets. The cached Linux image lacks Clippy; its attempted invocation and the successful host check are retained separately.

Before actual release, supply a replacement merchant host, pass its real deployment isolation preflight, regenerate existing referenced image derivatives in bounded batches, and validate public routing/CDN and infrastructure rollback. No further server address was guessed or production change attempted.
