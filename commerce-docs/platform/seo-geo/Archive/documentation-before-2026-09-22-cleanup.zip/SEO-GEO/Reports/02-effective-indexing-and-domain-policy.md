# Stage 02 Report

Date: 21 September 2026.

**Implemented**: effective indexing, approved-domain/installation binding, origin HTML/header policy and Admin display. **Verified**: focused Stage 02 acceptance on local production-like hosts, including two databases. **Partially verified** overall: the broader frontend regression check retains a grocery preset color mismatch in an untouched area; do not advance to Stage 03 on a claim of an entirely green suite.

## Repository findings

Discovery settings previously persisted preferences without a storefront consumer. The actual storefront is still a static Vite SPA; demo/admin proxy headers are hardcoded noindex. One database belongs to one gateway installation. The application source was untracked before this stage, so the commit tracks only touched/new source surfaces rather than importing the entire repository. The accompanying delta patch records just modifications to captured pre-stage files. Shared generated artifacts are staged separately so concurrent assistant/schema work remains untouched in the working tree.

## Architecture decision

Use one Rust resolver with explicit deployment context and an independent commerce installation UUID. Preserve the existing discovery configuration contract; add a separate authenticated effective-state endpoint. Before Stage 03 SSR, opt in a gateway adapter that loads the actual built storefront HTML and applies robots metadata and headers dynamically from saved settings. Keep existing demo/admin vhosts protected. Production config is additive and requires operator-approved origin, installation binding and a built artifact. No shared HTML cache or production rollout.

## Implemented

- Additive publication-installation migration; production startup binding checks.
- Policy outcomes INDEXABLE, MERCHANT_DISABLED, BLOCKED_BY_ENVIRONMENT, BLOCKED_BY_HEADER, DOMAIN_UNVERIFIED and CONFIGURATION_ERROR.
- Root HTTPS DNS origin validation, exact installation-approved origin matching, Host checking and ignored forwarded authority headers.
- Per-request saved policy reflected in actual HTML meta, X-Robots-Tag and robots.txt; private/query-bearing pages and internal APIs stay noindex. Dynamic responses are no-store.
- Effective Admin endpoint with permission check, revision, configured header/meta/robots state, environment/deployment override, warnings and explicitly unobserved external CDN headers.
- Admin panel using the API response directly, refresh after saves, typed generated response contract and display tests.
- Existing save revision/audit/outbox semantics preserved; existing CSRF request-header/origin middleware applied to discovery routes.
- Opt-in merchant Nginx generator and Compose overlay, leaving existing demo/admin generator behavior unchanged.

## Files changed

Existing files (delta patch available):

- `backend/crates/api-gateway/src/discoverability.rs`
- `backend/crates/api-gateway/src/main.rs`
- `backend/crates/api-gateway/src/lib.rs`
- `backend/crates/api-gateway/openapi/discoverability_contract.py`
- `backend/openapi.json`
- `frontend/packages/api-client/src/schema.d.ts`
- `frontend/packages/api-client/src/discoverability.ts`
- `frontend/apps/admin/src/discoverability-settings.tsx`

New implementation/test files:

- `backend/migrations/20260921090000_publication_installation.sql`
- `backend/crates/api-gateway/src/public_commerce/mod.rs`
- `backend/crates/api-gateway/src/public_commerce/policy.rs`
- `backend/crates/api-gateway/tests/publication_policy.rs`
- `frontend/apps/admin/src/effective-indexing-status.tsx`
- `frontend/apps/admin/src/effective-indexing-status.test.tsx`
- `deploy/ec2/publication.py`
- `compose.publication.yaml`
- `scripts/tests/test_publication_deployment.py`

Documentation/evidence: `SEO-GEO/Docs/indexing-policy.md`, `SEO-GEO/Docs/domain-and-proxy-trust.md`, this report, `02-existing-source-delta.patch` and `02-source-manifest.json`. Prior reports and excluded website/assistant implementation were not edited.

## Tests run and results

All commands below are from repository root unless a working directory is specified. Database credentials are disposable fixture credentials, not merchant secrets.

| Command | Result |
| --- | --- |
| `cargo test -p api-gateway --lib public_commerce --locked` (backend) | **Verified**: 4 policy/binding tests passed |
| `DATABASE_URL=postgres://postgres:stage02-isolated-only@127.0.0.1:50648/postgres PUBLICATION_TEST_INDEX=/Users/momar/Documents/commerce-ai/frontend/apps/storefront/dist/index.html cargo test -p api-gateway --test publication_policy --test identity --test catalog --test admin_depth --test themes --locked --manifest-path backend/Cargo.toml` | **Verified**: 24 integration tests passed: 3 new real-HTTP scenarios and 21 existing regressions |
| `cargo clippy -p api-gateway --all-targets --locked -- -D warnings` (backend) | **Verified**: exit 0 |
| `rustfmt --edition 2021 --config skip_children=true --check backend/crates/api-gateway/src/discoverability.rs backend/crates/api-gateway/src/public_commerce/mod.rs backend/crates/api-gateway/src/public_commerce/policy.rs backend/crates/api-gateway/tests/publication_policy.rs` | **Verified**: exit 0 |
| `python3 -m unittest discover -s scripts/tests -p 'test_publication_deployment.py'` | **Verified**: 3 tests passed |
| `python3 -m unittest discover -s scripts/tests -p 'test_ec2_deployment.py'` | **Verified**: 9 existing tests passed |
| `node node_modules/vitest/vitest.mjs run apps/admin/src/effective-indexing-status.test.tsx` (frontend) | **Verified**: 6 state/display tests passed |
| `node node_modules/eslint/bin/eslint.js apps/admin/src/effective-indexing-status.tsx apps/admin/src/effective-indexing-status.test.tsx apps/admin/src/discoverability-settings.tsx packages/api-client/src/discoverability.ts` (frontend) | **Verified**: exit 0 |
| `node node_modules/typescript/bin/tsc -p /tmp/rocento-stage02-admin-tsconfig.json --noEmit` (frontend) | **Verified**: focused changed Admin controls and their imported contracts typecheck. Temporary config extends repository config and includes the three changed/new Admin TSX files |
| `node node_modules/typescript/bin/tsc -p apps/storefront/tsconfig.json --noEmit` (frontend) | **Verified**: exit 0 |
| `node ../../node_modules/vite/bin/vite.js build` (each of frontend/apps/storefront and frontend/apps/admin) | **Verified**: both built; existing >500 KB chunk warnings remain |
| `node node_modules/vitest/vitest.mjs run` (frontend) | **Partially verified**: final refreshed run 110 passed, 1 failed (grocery preset colors); initial run 104 passed, 2 failed |
| `node node_modules/typescript/bin/tsc -p apps/admin/tsconfig.json --noEmit` (frontend) | **Verified** on final refreshed workspace. An intermediate run failed while unrelated category-management changes referenced a not-yet-added catalogApi.adminCategories method |

The opt-in Compose overlay also passed `docker compose --env-file /dev/null -f compose.yaml -f compose.publication.yaml config --quiet` with disposable required environment values and the deployment noindex default retained. The source-manifest check verified all eight intended Stage 02 changed-file fingerprints; concurrent working-tree generated files are deliberately excluded from that comparison.

The remaining broader frontend failure is `packages/api-client/src/demo-presets.test.ts` (grocery preset versus default primary/success/surface colors). An earlier assistant quantity-control test failure and an intermediate category API type mismatch disappeared after concurrent work elsewhere in the workspace; the refreshed run passes both. This stage did not edit those features or disable tests.

API contract generation: `python3 scripts/generate_openapi.py` initially exposed unrelated BasketDraft.auto_select output drift. Concurrent work subsequently regenerated additional assistant schemas. Preserve the current shared working-tree outputs. For this stage's commit, construct isolated generated artifacts from the captured baseline plus only EffectiveIndexingPolicy and `/v1/admin/discovery/effective`, then run `node frontend/node_modules/openapi-typescript/bin/cli.js /tmp/rocento-stage02-commit/backend/openapi.json -o /tmp/rocento-stage02-commit/frontend/packages/api-client/src/schema.d.ts`. Stage only those isolated blobs, leaving all concurrent working-tree changes untouched. The source delta and manifest describe this stage's committed content. Existing endpoint/schema meanings in that commit are unchanged; the new effective response was validated against OpenAPI in HTTP tests. A single-task commit cannot represent concurrent untracked application work, so do not infer whole-repository reproducibility from it.

Tooling/retries: the default pnpm wrapper attempted an automatic package-manager/dependency install and aborted; installed local Node binaries were used without replacing dependencies. A requested fixture port 55432 was occupied; Docker assigned localhost:50648 instead. Initial sandboxed database access was denied, then the same tests passed with reviewed local-network access. Exploratory wrong-directory commands were corrected; their failures are not test passes. No production service or existing database was modified.

## Acceptance evidence

| Requirement | Evidence | Level |
| --- | --- | --- |
| Merchant preference affects initial response | Real socket tests save on/off settings, then assert matching built HTML meta and X-Robots-Tag; no-store checked | **Verified** |
| Deployment override wins and is visible | Production override fixture returns BLOCKED_BY_HEADER and noindex HTML/header; Admin panel renders the same server state | **Verified** |
| Demo/staging/admin stay blocked | Real HTTP environment matrix plus unchanged demo/admin Nginx generator tests | **Verified** |
| Cross-installation isolation | Two separate migrated databases have different installation IDs; A's host/session/domain cannot select or mutate B; B's revision/state stays unchanged | **Verified** |
| Spoofed forwarded host rejected | Wrong Host plus valid X-Forwarded-Host remains 421; malicious forwarded host on valid Host cannot alter content origin | **Verified** |
| Permission/revision/audit | 401, 403, 409, unsafe domain rejection, CSRF/origin rejection and successful audit/outbox row counts tested | **Verified** |
| Broad regression gate | Backend regressions and final Admin/storefront typechecks pass; whole frontend suite retains the grocery preset color failure | **Partially verified**; transition held |

## Performance/security observations

Policy uses one fresh settings read per HTML request and no-store; no benchmark or latency claim. Templates are operator-configured local files read at startup, not remote URLs. Origin/installation settings fail closed. Forwarded host headers never select canonical or database. The new proxy rejects mismatched hosts and keeps APIs non-indexable. CDN headers are unobserved and explicitly labeled. Static assets remain independently served. No private customer data is used to evaluate publication policy.

## Partially verified

Actual Nginx/TLS/CDN rollout, a full interactive browser Admin session and Node 22 runtime were not exercised. Real HTTP tests used loopback sockets with production-like DNS Host values and built storefront HTML. They prove origin policy, not external DNS ownership or live CDN behavior. The remaining grocery preset regression prevents claiming a wholly green workspace. Concurrent generated-contract edits are preserved outside this stage’s staged contract additions.

## Not implemented

Stage 03 server-rendered catalog data and resource HTTP statuses, Stage 04 page canonicals/aliases, full Stage 07 crawler/discovery features, automated DNS ownership verification or external-header probing. The current adapter retains SPA behavior for unknown non-API client paths, with noindex. No production deployment or indexing change was performed.

## Blocked

Transition to Stage 03 is held on the remaining broader frontend grocery preset regression listed above. The Stage 02 implementation and focused acceptance are reviewable; no excluded feature was changed to force the larger suite green.

## Follow-up for the next stage

Resolve or explicitly disposition the unrelated grocery preset regression before claiming the program gate is green. Then Stage 03 should consume the policy in public SSR, replace the transitional shell adapter, preserve noindex/private behavior and prove real catalog/status/hydration behavior. Use the committed indexing/trust docs for the operator deployment contract.
