# Stage 04 — Canonical URLs, Slugs and Redirect Lifecycle

Date: 21 September 2026. Scope: merchant platform publication.

**Verified — local acceptance:** canonical slug URLs return 200; legacy IDs, previous slugs and combined path/tracking normalization return one 301 directly to the current URL. Deleted/unavailable resources follow the documented 404/explicit-410 policy. The central identity supplies consistent HTML and future discovery adapter URLs, and separate installations cannot produce each other's origins.

**Partially verified — rollout:** no merchant database migration or production deployment was performed. Production data collision audits, backup restoration, merchant-specific themes and external TLS/CDN validation still require installation-specific rollout checks.

## Repository findings

Stage 03 already stored slugs and rendered public documents but linked to IDs, had no atomic historical ownership, and had no emitted canonical link. The approved route registry supported explicit 301/410 decisions but not a rename lifecycle. Existing domain APIs accept an editable slug; the input schema remains compatible (send a blank string to request generation). Attribute-code validation is separate and remains unchanged.

Concurrent generated changes in `backend/openapi.json` and `frontend/packages/api-client/src/schema.d.ts` belong to other work and are preserved, not included in this stage. No corporate website or assistant implementation source is changed. Existing API IDs and private purchase flow remain supported.

## Architecture decision

The initial decision was recorded in `slug-and-redirect-policy.md` before implementation. Use installation-local stable-ID aliases, enforced at the database write boundary so API updates and imports cannot omit history. Resolve each alias to the current live resource in the same publication transaction. Keep one trusted canonical identity in Rust, consumed by Node for the canonical link and exposed to later JSON-LD/sitemap/feed adapters.

There is no locale prefix because the current platform publishes one actual default content locale. Facet/sort/selection combinations are not silently treated as identical content: unsupported anonymous publication queries return 404; existing search and private option workflows remain in the app. Dynamic responses remain no-store.

## Implemented

- Deterministic Unicode NFKD/Latin/Arabic slug normalization, reserved-word/UUID-shaped protection, stable fallback and generated-collision suffixes. Explicit duplicate overrides fail with the existing conflict response.
- Database trigger lifecycle for product/category inserts and slug updates; current, previous and ID aliases are reserved atomically and survive deletion. Existing approved redirect/retirement paths cannot be claimed by a new resource.
- Migration backfill for existing rows; ambiguity aborts rather than assigning another product's URL. API IDs are unchanged.
- Current slug canonicals, slug discovery links, one-hop ID/history redirects, explicit replacement-chain collapse, cycle detection and live-destination checks.
- Central `Context`/`Identity` constructed only from matched database/deployment UUID, approved production origin and saved discovery identity. HTML, JSON-LD, sitemap and feed adapter values share the same URL.
- Canonical `<link>` in HTML, omitted for missing/retired/private/error or unapproved-context output. Node validates the canonical origin, identity, locale and adapter equality.
- Case/trailing-slash/encoded-ASCII normalization; raw encoded separators/dot segments rejected before URL parsing can turn them into another route. Tracking removal, duplicate-query rejection, default-locale checking and self-canonical pagination.
- Distinct active child variants keep their own slugs; inactive parents hide child publication. The existing private `?shop=1` ID route remains noindex and is checked for resource existence.

## Files changed

See `04-source-manifest.json` for the exact file list and hashes, and `04-existing-source-delta.patch` for changes to pre-existing sources.

Primary implementation: `20260921110000_publication_slug_history.sql`, `domain-catalog/src/lib.rs`, `public_commerce/canonical.rs`, snapshot assembly, Node URL policy/publication handlers, and public React links/types. Tests extend the existing publication integration/browser coverage and add Node URL/canonical contracts. Documentation includes canonical policy, slug lifecycle, migration/rollback and updated Stage 03 handoff references.

## Tests run and results

The test database was a dedicated temporary PostgreSQL 16 container. Existing merchant containers/databases were not used. Node tests ran on Node 22.23.2. SQLx tests used a local DATABASE_URL with CREATEDB; credentials are intentionally not embedded here.

| Check | Result |
| --- | --- |
| Vite public client build + SSR build + seal | **Verified** — both built successfully |
| `cargo test -p api-gateway --test publication_rendering --test publication_policy --locked` | **Verified** — 7 passed; live PostgreSQL/gateway/renderer, curl and Chromium enabled |
| `node --test server/publication-checks.mjs server/url-policy-checks.mjs` on Node 22 | **Verified** — 12 passed |
| `cargo test -p api-gateway --lib public_commerce --locked` | **Verified** — 5 passed |
| Existing catalog, catalog-schema, product-type/attribute, identity, cart, delivery and theme API regressions | **Verified** — 50 passed; 1 existing Meilisearch-dependent test ignored |
| Full frontend Vitest suite | **Verified** — 116 passed across 22 files |
| Storefront/admin TypeScript and changed public TS/TSX ESLint | **Verified** — exit 0 |
| `cargo clippy -p api-gateway --all-targets --locked -- -D warnings` | **Verified** — exit 0 |

Rust commands use `--manifest-path backend/Cargo.toml` from the repository root. The retained test logs and reproduction command are under `SEO-GEO/Tests/stage04`.

The first Arabic fixture exposed a decomposed hamza mark becoming a separator; removing the relevant combining-mark range corrected it without weakening the test. Clippy identified two redundant dereferences in the new tests; they were corrected. No existing test was disabled to obtain a passing result.

## Acceptance evidence

All retained evidence is synthetic fixture data, not a production observation:

- `canonical-product-200.http`: current human-readable product path, useful HTML and the approved canonical link.
- `legacy-id-301.http`, `history-first-301.http`, `history-previous-301.http`, `normalized-history-301.http`: all point directly to `/products/orchard-selection`, whose saved response is 200.
- `canonical-pagination-200.http`: page 2 retains `?page=2` in the canonical; a combined old category ID/tracking/page-format request redirects to it in one hop.
- `canonical-identities.json`: HTML/JSON-LD/sitemap/feed adapter values are exactly equal.
- `tenant-b-canonical-200.http`: overlapping product IDs/slugs in a second database produce its own approved origin. Wrong hosts return 421; forged canonical identities are rejected by Node.
- `unknown-404.http`, `retired-410.http`, `unsupported-sort-404.http`: real status responses with no public canonical on error pages.

Integration assertions additionally cover successive renames, aborted rename rollback, historical-name conflicts, concurrent generated-name collisions, Latin composed/decomposed equivalence, Arabic transliteration, reserved words, unsupported-script fallback, physical category/product deletion, parent/child eligibility, explicit replacement loops, pagination, locale query mismatches and query duplicates. The migration rehearsal recreates the pre-stage schema boundary in an isolated transaction, backfills real pre-existing rows, and proves ambiguous lowercase ownership aborts and rolls back.

The retained Stage 03 test still verifies no-session/no-JavaScript content, hydration, published/draft separation, media privacy, freshness, failure statuses and two-store isolation. Browser search navigation now lands on the slug after the legacy ID redirect. The search/account/cart widget regression segment uses explicit API mocks; initial catalog/status behavior uses the real database.

## Performance/security observations

Alias lookups have a primary key by kind/key and an index by resource identity; they cannot choose a different database. Automatic history has no redirect chain because each alias maps to a stable ID. Explicit operator graphs have cycle detection and a 16-visit bound. The existing catalog advisory lock serializes slug allocation; migration and high-write catalog throughput were not load-tested.

No second catalog, price copy or private data source was introduced. Canonical origin never comes from request Host/Forwarded data. Redirects are normalized relative paths to eligible same-installation resources. HTML/state escaping and no-store policies are retained. Known tracking removal is explicit; attribution capture is not implemented in this stage.

## Partially verified

Production-size migration timing/locks, real merchant collision audits, full production backup restoration, external cache behavior and every merchant theme/private checkout path. The existing Meilisearch-specific ignored regression was not executed. No deployed-domain or search-engine indexing claim is made.

## Not implemented

Multiple translated locales/hreflang; anonymous faceted landing pages; a new redirect-management UI; inline private purchase islands; full JSON-LD, sitemap or feed output. Their canonical adapter values are available, but the actual outputs belong to later stages. Unsupported-script fallback is stable, not a fabricated translation.

## Blocked

No blocker remains for the local Stage 04 acceptance gate. Rollout requires the installation-specific preflight, backup and ingress verification described in `slug-and-redirect-policy.md`.

## Follow-up for the next stage

Stage 05 can reuse the canonical identity when implementing richer metadata. Do not recompute origin/slug URLs in downstream writers. Preserve the declared parameter, locale and variant policies; use a separate reviewed design for future translated/faceted pages. Follow the migration and rollback plan before any merchant deployment; keep noindex until its actual public responses are verified.
