# Stage 10 — Attribution, SEO/GEO Health and Observability

Date: 2026-09-21. Scope: Rocento merchant platform and merchant storefronts.

**Implemented:** discovery attribution, authenticated order linkage, permission-controlled analytics, actionable publication health findings, bounded crawler counters and structured operational alerts. **Verified:** local database, HTTP, frontend and synthetic admin acceptance tests. **Partially verified:** production operation; no production deployment, real merchant traffic or external crawler verification was performed.

## Delivered behavior

The additive discovery classifier supports all twelve requested channels. Exact provider hosts and the documented ChatGPT campaign pattern are distinguished from generic AI campaign claims. Paid/email/social campaign precedence is explicit. Lookalike hosts, embedded credentials and malformed input cannot identify a recognized provider. Ordinary Google referrals remain organic search; they do not prove an AI Overview or AI Mode click. Browser evidence is untrusted observational data, not proof of provider or human identity.

First touch identifies session acquisition. Last non-direct touch updates in server ingestion order and freezes when a verified, owning customer links a recent order. A session UUID is shared with legacy browse tracking and rotates after 30 minutes of browser inactivity. Existing legacy source categories/API remain available. Separate event and order uniqueness prevent retry double counting. AI-assisted orders overlap AI-attributed orders and are never added as extra conversions. Browser failures can undercount: this is attribution for observed callbacks, not a financial ledger.

Net collected revenue comes from authoritative collected payments less recorded refunds, grouped by currency. Tests prove a synthetic collected 105.00 payment less a 25.00 refund yields 80.00 once, despite repeated callbacks. Discovery permission allows aggregate traffic; revenue additionally requires reports.read. No browser-provided amount is trusted. Cancelled/delivery-failed orders are excluded from conversion counts; cash still collected remains revenue until refunded. Session windows use session creation and order windows use order creation, so the UI does not invent a conversion rate between different cohorts.

Canonical redirects continue to normalize public URLs. A two-minute secure cookie carries only bounded campaign tokens and referrer origin to the first hydrated page, which consumes it. Conversation paths, query strings and credentials are excluded. GPC/DNT disables tracking and cookie creation. Discovery data expires after 90 days through an hourly worker; authoritative orders/payments are retained. Simultaneous redirecting tabs may compete for the short-lived cookie.

Health combines effective publication policy, installation binding, feed failures/lag and up to 100 redirects with a private renderer sample. Findings contain severity, affected resource, evidence, timestamp and remediation. HTTP checks cover robots/sitemap structure, product HTML, canonical/robots tags, JSON-LD consistency, a measured image, missing-product 404 and redirect chains. Deliberately protected environments are not falsely declared indexing failures. Missing samples and unavailable probes produce explicit warnings.

The admin SEO and AI discoverability pages show actual stored sessions, source evidence categories, top landings/products, UTC trends, conversions/revenue when authorized, findings and observed crawler response counters. There is no arbitrary SEO score or AI rank. The renderer exposes process-local rolling fifteen-minute counters with fixed labels. At least ten claimed-crawler requests, five errors and a 20% error ratio trigger a structured alert, at most once per minute. Synthetic probes are excluded. Feed-lag and redirect alerts run when health is requested; feed batch failures log from the existing worker.

New APIs:

- POST /v1/discovery/attribution: bounded same-origin observation ingestion; verified customer ownership required for order linkage.
- GET /v1/admin/discovery/analytics: installation-bound, permission-controlled UTC windows of 1–90 days.
- GET /v1/admin/discovery/health: installation-bound operational findings and a fixed, private renderer probe.

Operators must configure PUBLICATION_RENDERER_URL and a matching random PUBLICATION_OBSERVATION_TOKEN of at least 32 characters on gateway/renderer through existing secret injection. The token is not browser configuration. Probe destinations are operator-controlled, never supplied by the requesting user. Individual probes have two-second deadlines; the gateway has a twenty-second deadline and a 128 KiB response cap.

## Acceptance evidence

All fixtures below are synthetic. Screenshots illustrate fixture data rather than production observations.

| Coverage | Result and evidence |
|---|---|
| All twelve channels, precedence, unknown providers and spoofing | Verified: nineteen classification cases in synthetic-classification.json and publication_measurement tests. |
| Persistence, retries, first/last touch and privacy | Verified: direct navigation preserves last non-direct touch; duplicate events do not create replacement sessions; malformed/private paths rejected; sensitive referrer content removed. |
| Orders, refunds and authorization | Verified: actual database order/payment/refund fixtures; authenticated owner links once; wrong owner rejected; reports.read controls revenue; revenue-redacted.json. |
| Installation isolation and retention | Verified: separate databases, cross-installation admin session rejection, wrong binding/origin rejection and ninety-day purge. |
| Health failures and recovery | Verified: feed errors, redirect cycle, repaired state and protected-environment false-positive checks; health-failed.json and health-recovered.json. |
| Real HTTP renderer probes | Verified: token boundary, failed render then recovery, actual two-second timeout, foreign host rejection and canonical redirect campaign cookie; renderer-health-recovered.json and renderer-health-timeout.json. |
| Redaction and alert thresholds | Verified: fixed counter labels, no raw secret/URL/customer text, minimum volume/error/rate thresholds, one alert per minute and aging recovery. |
| Admin behavior | Verified: synthetic failure, refresh recovery, permission redaction and desktop/mobile widths without card overflow or JavaScript errors; admin-browser.json and PNGs. |

Recorded checks in SEO-GEO/Tests/stage10:

- 33 publication integration tests passed; the existing two-million-product capacity test was skipped in this run (Stage 09 recorded its explicit pass).
- 62 shared commerce tests passed, including orders and customer journeys. One unrelated customer-journey browser preview test requires its own configured preview and was skipped.
- 13 publication unit tests and 25 Node checks passed.
- 123 frontend tests across 23 files passed; admin/storefront TypeScript and focused lint checks passed.
- Admin production build and storefront client/SSR builds passed.
- Rust check and Clippy with warnings denied passed.

The rendering regression log includes a child-process EPIPE during teardown; all nine HTTP rendering assertions and the parent suite passed. It is retained in the raw log rather than silently removed. Synthetic backend fixtures validate linkage against real database records; they do not claim an end-to-end live merchant purchase. Browser UI fixtures and database acceptance are independently tested boundaries.

## Operational limits and handoff

**Partially verified:** production traffic coverage, high-volume ingestion, external CDN/WAF responses, externally accessible images and all-catalog health. Local probes sample one product/image and the first sitemap partition. XML checks validate the platform vocabulary/structure, not every external XSD rule. Renderer counters reset on restart and do not aggregate across replicas. Claimed crawler user agents are not verified identities. The report always exposes the external-edge evidence gap.

**Not implemented:** production rollout, verified crawler IP/DNS validation, durable centralized metrics, external alert delivery, production dashboards, automated citation sampling or ranking measurement. No indexing, citation, conversion or provider approval guarantee is made. No corporate website or shopping-assistant implementation was changed.

The commit includes only explicit Stage 10 sources and additive generated OpenAPI/client fragments. Concurrent workspace changes remain separate. The previously untracked legacy analytics.ts hook is included to make the shared session/order integration reviewable; its existing categories remain unchanged. 10-source-manifest.json binds the committed source and evidence bytes.

Documentation: SEO-GEO/Docs/analytics.md, SEO-GEO/Docs/health-engine.md and SEO-GEO/Docs/observability.md. Stage 11 has not been started.
