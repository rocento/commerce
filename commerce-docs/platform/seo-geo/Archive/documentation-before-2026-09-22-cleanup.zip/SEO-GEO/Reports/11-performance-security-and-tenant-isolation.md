# Stage 11 — Performance, Security, Privacy and Tenant Isolation

Date: 2026-09-21. Scope: Rocento platform merchant storefront publishing.

**Implemented:** indexed public product lookups and bounded dynamic renderer admission. **Verified:** local tenant/privacy/security acceptance tests, quantified Stage 10-to-11 latency comparison, real browser observations and application rollback compatibility. **Partially verified:** full Stage 11 production/performance gate; target-environment and historical pre-SEO performance evidence are unavailable. No production-readiness claim is made.

## Repository findings

The public path uses repeatable-read anonymous snapshots, approved-host/installation checks, no-store dynamic output, bounded product/family/feed samples, measured media metadata and structured operational findings. Its deployment model is one merchant installation per database/renderer/media-store scope. Existing concurrent catalog/assistant-related workspace changes were preserved.

The combined product ID-as-text/slug query scanned the 50,001-product fixture. Thirty lookup samples averaged 24.56 ms by slug and 25.14 ms by UUID. The renderer also allowed all forty simultaneous fixture requests to reach a delayed dependency. Both findings had concrete measurements before edits.

## Architecture decision

Keep authoritative projections and existing indexes. Use a UUID lookup followed by slug fallback, preserving visibility predicates and UUID precedence. Bound concurrent dynamic dependency/render work rather than add a public document cache. A cache would introduce invalidation and tenant-key risks without a demonstrated need in this workload. No migration, API contract change or frontend rendering redesign is required.

## Implemented

Public lookup now uses existing primary-key/unique-slug indexes. The renderer admits at most 32 dynamic requests by default; PUBLICATION_MAX_INFLIGHT accepts integers 1–256. Excess requests receive no-store, noindex 503 responses with Retry-After: 1. Liveness and immutable assets remain available; permits are released after success or failure. This bounds application work, not every connection or multi-process ingress rate.

## Files changed

Production changes are confined to backend/crates/domain-catalog/src/public.rs and frontend/apps/storefront/server/publication.mjs and start.mjs. Tests add publication_hardening.rs, support/publication_stage11.rs, hardening-checks.mjs and local benchmark/browser/rollback scripts. Four requested policy documents, this report, raw evidence and a source manifest are included. No corporate-site or shopping-assistant implementation was modified; generated OpenAPI/client workspace changes are outside this commit.

## Tests run and results

- 98 backend regression tests passed: 33 existing publication tests, 3 new hardening tests and 62 shared commerce tests.
- The focused hardened matrix was rerun after adding actual PNG-byte isolation and stricter own-admin response checks: 3 passed.
- 13 publication unit tests and 28 Node checks passed.
- 123 frontend tests across 23 files passed; admin/storefront TypeScript checks and production storefront client/SSR builds passed.
- Clippy passed with warnings denied for library, gateway binary and the new hardening test target.
- The explicit 50,001-product benchmark passed before the edit and in two after runs. The first after run includes 24 Chromium page samples. Both merchant XSS browser fixtures and the prior-renderer rollback fixture passed separately.

The broad run skipped the existing two-million-product capacity test, the separately configured customer-journey browser preview test and the explicit benchmark (which ran separately). Existing HTTP rendering tests can emit child teardown EPIPE diagnostics while all assertions pass; raw logs are retained. No existing test was disabled. Commands and reproduction scope are in Tests/stage11/README.md.

## Acceptance evidence

| Gate | Evidence |
|---|---|
| Identical tenant identities | Two actual PostgreSQL databases and HTTP renderers use identical product/category/media/CMS IDs, slug, SKU, locale and attribution IDs, with distinct public sentinels. |
| Public matrix | Home/product/category/CMS HTML, metadata/canonicals, JSON-LD, robots, sitemap index/partitions, redirects, feeds and merchant policies remain installation-scoped; inactive/private content is excluded. |
| Media | Same media IDs and object keys against separate configured object-store endpoints return distinct actual PNG bytes. Private media returns 401 before any store fetch. |
| Protected discovery | Own admin sessions read only their own response data; other-installation and anonymous sessions receive 401. Revenue/privacy/retention tests from Stage 10 still pass. |
| XSS and injection | Host/forwarded spoofing, unsafe destinations, secret forwarding, oversized responses and cancellation tests pass. Hostile stored product text remains visible as escaped text and executes no script/event handler in either Chromium context. |
| Resilience | A real database lock yields a bounded 503 and recovery; A withdrawal does not affect B; worker task interruption/restart uses durable state; existing partial-feed/retry tests pass; no stale cached product is served. |
| Rollback | Prior committed Stage 10 renderer source accepts current schema-v1 snapshots and built artifacts, fails closed on dependency failure and recovers. Mixed-artifact startup rejection remains tested. |

Evidence directory: Reports/evidence/stage11. No high/critical security finding remains open in the reviewed application path under its tested deployment invariant. This is a source-and-test review, not a guarantee against every vulnerability or an independent penetration test.

## Performance/security observations

Same 50,001-product, 100-family-link fixture; fifteen samples per path after one warm-up; local Apple M4 Pro/24 GiB, PostgreSQL 16 Docker, Node 25.9.0, Rust test/dev and Vite production bundles:

| Path | Before median TTFB | After median TTFB | Repeat median | HTML bytes |
|---|---:|---:|---:|---:|
| Home | 10.89 ms | 10.83 ms | 11.77 ms | 29,422 |
| Product | 45.30 ms | 20.86 ms | 20.61 ms | 126,667 |
| Category | 9.09 ms | 10.21 ms | 9.28 ms | 23,285 |
| CMS | 7.96 ms | 9.11 ms | 7.92 ms | 10,738 |

Product median TTFB improved approximately 54%; direct lookups fell to 0.29–0.34 ms. HTML byte counts remained identical. Small non-product variation did not persist in the repeat. Full distributions and p95 observations are retained; a p95 from fifteen samples is effectively the largest sample, not a reliable field percentile.

One snapshot API call per rendered page remained unchanged; dynamic cache hit ratio stayed zero. For the same 68 gateway calls, renderer process CPU was 158.4 ms before / 165.1 ms after, with OS maximum RSS 88,736 / 90,096 KiB. These include process request handling and exclude database memory. The change reduces database lookup wait, not the React render workload.

The after sitemap index took 28.0 ms for 54 partition links; three sampled partitions totaled 135,919 bytes in 23.4 ms. Three feed batches processed thirty resources in 476 ms (438 ms repeat), with test-process RSS sampled after each batch peaking at 40,480 KiB. The harness advances scheduler pacing, so this is active batch cost, not sustained full-catalog throughput or exact peak heap.

Twenty-four post-change Chromium samples recorded median LCP of 32–64 ms desktop / 36–48 ms mobile and maximum CLS below 0.011. Short search-focus/tab interactions produced 32–48 ms Event Timing candidates; these are not field INP. Timing fixtures contain no primary image and do not model realistic network/CPU throttling. Local values must not be presented as production Web Vitals.

## Partially verified

Production release builds/intended Node runtime, image-heavy configurable catalogs, large taxonomies, sustained multi-replica load, full feed rebuild throughput/peak memory, CDN/WAF behavior and infrastructure rollout/rollback need target-environment verification. Historical pre-SEO field/browser telemetry is unavailable; the defensible before/after comparison is Stage 10 versus Stage 11, not before all SEO/GEO work.

## Not implemented

Public HTML caching, request coalescing, distributed rate limiting, shared-bucket tenant namespacing, external alert delivery, production deployment and new provider integrations. Only measured query and concurrency issues were changed. No ranking/indexing/citation guarantee is made.

## Blocked

The full production acceptance gate remains blocked on target-environment performance and deployment-isolation evidence. In particular, sharing the fixed commerce-media bucket/object keys between merchant installations violates the current architecture and must not be released without isolation or a separately designed namespace migration. No such production storage configuration was inspected or changed here.

These are explicit release blockers, not waived performance tests. Local application tenant/privacy gates passed; the report does not promote local synthetic results into a production pass.

## Follow-up for the next stage

Resolve the documented target-environment blockers before making a release claim. Use performance-baseline.md, security-and-privacy.md, tenant-isolation.md and failure-and-rollback.md as the validation contract. Stage 12 has not been started. The source manifest binds this stage's committed source, report and evidence; unrelated workspace changes remain separate.
