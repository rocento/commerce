# Stage 03 — Server-visible rendering and HTTP status

Date: 21 September 2026. Scope: merchant platform storefront publishing; corporate website and assistant implementation excluded.

**Verified — local acceptance:** production-built public home, product, category and CMS documents contain useful initial HTML without JavaScript or customer-session restoration. Missing/retired/renamed routes return 404/410/301. Hydration, host/installation isolation, anonymous data filtering and immediate publication freshness passed the recorded checks.

**Partially verified — rollout:** no merchant production deployment or external TLS/CDN validation was performed. The fixture verifies one assigned published theme and shared presentation code, not screenshot parity for every merchant theme. Inline personalized cart/variant islands are not implemented; the existing shopper view remains available by document navigation. These limits prevent a production-readiness claim.

## Repository findings

Stage 02's temporary gateway public shell could emit 200 before determining resource existence. Existing main.tsx restores a customer session before rendering routed catalog content. Theme and CMS presentation were mixed with browser providers; product/private flows contain browser-only dependencies. Anonymous publication therefore required an independent entry and a safe shared presentation boundary.

The Stage 01 request-time React/Vite SSR architecture and initial no-shared-cache mode were retained. Existing local package-manager wrapper behavior still prevents using it reliably; verification used installed Node binaries. Concurrent generated assistant contract changes in `backend/openapi.json` and `frontend/packages/api-client/src/schema.d.ts` were preserved and excluded from this stage's commit. Much of the original application remains untracked; the existing-source delta records the edits separately from first-time source inclusion.

## Architecture decision

Use one fixed-backend Node renderer per installation. Rust resolves anonymous data and authoritative resource status in one repeatable-read transaction, projecting catalog fields through a domain-owned public reader. Node checks the envelope binding before rendering the same React tree/state that the browser hydrates. Public links use document navigation; the existing search widget enhances the header after hydration. Customer APIs and private app behavior remain separate from initial catalog rendering.

The `/v1/publication/snapshot` endpoint is an internal renderer contract, documented in `public_commerce/snapshot.rs` and `src/public/types.ts`; it is not added to the general shopper SDK or generated OpenAPI in this stage. Version 1 is runtime-checked. A matched-build manifest validates the template/SSR entry before startup. This additive internal boundary avoids changing unrelated generated consumer contracts.

## Implemented

- Meaningful initial home/catalog/product/CMS HTML, crawlable links, merchant identity, primary image metadata, simple-product catalog price/currency, scalar public attributes, conservative location availability, and later-stage metadata insertion point.
- Strict anonymous catalog projection: no private/customer data, unknown/hidden/disabled attributes or media object keys. Published default theme and current CMS release only.
- Real 404/410/301/421/405/503 document semantics. Explicit approved route registry with safe relative destinations and live-target validation; no redirect chains. No unsupported temporary redirects.
- No-store dynamic responses and per-request installation/host/locale/route validation. Product/category/content/theme changes need no cache purge. Hashed static assets remain independently cacheable.
- Shared theme tokens/sections/CMS blocks; public product layout uses existing presentation classes. Existing search loads after hydration; purchase/options link enters the existing shopper route.
- Separate client/SSR builds, artifact seal, health/readiness, bounded/cancellable upstream transport, opt-in Node 22 Compose service and merchant-only ingress change.

## Files changed

The exact source list and SHA-256 values are in `03-source-manifest.json`; changes to pre-existing sources are also recorded in `03-existing-source-delta.patch`.

Primary groups: `backend/crates/api-gateway/src/public_commerce/`, `discoverability.rs`, `domain-catalog/src/public.rs`, publication-route migration, publication integration tests; `frontend/apps/storefront/src/public/`, public entry points, shared theme/content modules, build/runtime files; opt-in deployment configuration; three Stage 03 architecture/policy documents and this report.

No corporate website or assistant implementation file is part of this stage's changes.

## Tests run and results

Commands below ran against installed tooling and an isolated PostgreSQL 16 fixture, never a merchant database. The database URL is intentionally omitted; tests require CREATEDB permission. Browser checking was enabled with `PUBLICATION_BROWSER_CHECK=1` and an absolute evidence output directory.

| Check | Result |
| --- | --- |
| Vite client build, SSR build, artifact seal | **Verified** — both production bundles built |
| `cargo test -p api-gateway --test publication_rendering --test publication_policy --locked` | **Verified** — 4 passed; includes built renderer, real PostgreSQL/gateway, curl and Chromium |
| Node renderer HTTP checks, `node --test server/publication-checks.mjs` | **Verified** — 7 passed, including Node 22 container runtime |
| Built SSR entry on Node 22.23.2 | **Verified** — renders the recorded live anonymous snapshot |
| Existing `catalog`, `identity`, `cart_inventory`, `delivery_areas`, `themes` API suites | **Verified** — 26 passed, 1 existing search integration test ignored because its dedicated Meilisearch harness was not started |
| Full frontend Vitest suite | **Verified** — 116 passed across 22 files |
| Storefront/admin TypeScript checks; changed TS/TSX ESLint | **Verified** — exit 0 |
| `cargo clippy -p api-gateway --all-targets --locked -- -D warnings` | **Verified** — exit 0 |
| Existing public-policy unit tests | **Verified** — 4 passed |
| Publication + existing EC2 Python deployment checks | **Verified** — 12 passed |

Rust commands use `--manifest-path backend/Cargo.toml` when run from repository root. Frontend typecheck/lint/Vitest commands run from `frontend` with installed `node_modules` binaries. Node HTTP checks are a separate runner so they do not create a false Vitest suite.

Initial test execution found the sandbox's local-socket restriction and a Node fetch Host-header mismatch; permitted localhost execution and explicit fixed-host transport resolved them. An initial Node-test filename was incorrectly picked up by Vitest; it was renamed for its separate runner. No test was disabled to obtain a passing result.

## Acceptance evidence

See `SEO-GEO/Tests/stage03/README.md` and retained actual curl responses:

- `home.http`: merchant/theme identity and catalog links/content.
- `products-apples.http`: title, description, 3.25 USD/kg, visible Color attribute, location-dependent availability and purchase navigation.
- `categories-fruit.http`: category title/description and product links.
- `pages-about.http`: published title and article body.
- `unknown-404.http`, `retired-410.http`, `renamed-301.http`: actual wire statuses, no-store/noindex and relative redirect target.
- `product-desktop.png`, `product-mobile.png`: built fixture screenshots, visually inspected.

The integration test checks useful content before the embedded state script, identical HTML with and without supplied session/auth/location headers, no secret attributes/draft theme text, primary media URL/alt without private object key, expired CMS 404, inactive product 404, and invalid redirect target 404. It verifies updated price/name immediately on the next request. A separate installation uses the same IDs/slugs without sharing content; wrong hosts return 421. An unavailable gateway returns 503.

Chromium checks hydration without errors, deep links, document navigation, unchanged meaningful content, no session startup dependency, and JavaScript-disabled 200/404/410. Its search-keyboard/account-login/empty-cart regression segments use explicit shopper API mocks; the initial catalog and status assertions use the real database. Existing Rust suites independently verify real cart/account/catalog behavior.

## Performance/security observations

No second product database or SEO price/stock copy was created. Public queries use a read-only consistent transaction, bounded listing/collection results and deadlines. No shared HTML/DTO cache exists. The renderer sends only a fixed approved Host upstream; browser credentials and precise locations are excluded. Safe React escaping and script serialization protect merchant text; runtime checks reject mismatched installation/origin/path/page/schema. No load-capacity or production latency claim is made.

## Partially verified

Full visual parity across every merchant theme, custom configuration and product family; deployed reverse-proxy/TLS/CDN headers; production resource limits and complete order placement. The existing Meilisearch-specific ignored integration case was not executed. Docker Compose wiring is source-tested; the whole deployment overlay was not launched.

## Not implemented

Inline personalized purchase/variant islands; automated slug-history management (Stage 04); full metadata/canonical rules (Stages 04–05); JSON-LD (Stage 06); sitemaps/feeds and later-stage GEO/measurement work. Public theme collections are bounded anonymous catalog selections, not personalized search/recommendation parity. A reusable shared response cache is a future enhancement under the accepted generation/invalidation contract.

## Blocked

No dependency blocks the verified local rendering/status acceptance. Production rollout still requires the operator's actual merchant binding/artifacts and environment-specific verification; no request to deploy was made.

## Follow-up for the next stage

Stage 04 may build canonical/slug policy on the explicit route registry and snapshot status boundary when requested. Preserve no-store and conservative availability. Keep deployment noindex enabled until merchant-specific visual, private-flow and public-ingress checks pass. Do not infer production readiness or search-engine indexing from the local acceptance result.
