# Rocento Merchant Storefront SEO/GEO — Final Report

Stage 12A, 22 September 2026. This report is the current preparation/acceptance record; Stage 12B will add first-client live evidence. Scope is Rocento merchant platform/storefront publishing, not the corporate website or shopping assistant. [Approved phase split](../Docs/first-client-live-validation.md).

## Executive summary

**Implemented:** installation-bound server-visible publication, canonical/HTTP lifecycle, metadata/images, truthful structured facts, merchant/CMS approvals, discovery surfaces, reference feeds and observational attribution/health. These share authoritative catalog/content/merchant sources. [Architecture](../Docs/architecture.md).

**Partially verified:** local implementation has historical and refreshed candidate evidence. The separate candidate includes required working-tree inputs, rather than pretending the Git revision alone contains a deployable application. Live client/edge/storage/rollback evidence remains absent. [Candidate source manifest](evidence/stage12a/candidate-source.json), [reconciliation](evidence/stage12a/reconciliation.json).

## Release recommendation: NO-GO

**Blocked** for public/general release until mandatory first-client gates pass. This does not prevent the approved Stage 12A preparation or a separately admitted protected pilot. No live indexing, deployment or client mutation occurred. No environment-dependent blocker was waived. [Gate policy](../Docs/first-client-live-validation.md), [live acceptance record](../Docs/first-client-acceptance.md).

## Implemented

- Hybrid React SSR over the Rust anonymous public snapshot, fixed upstreams and approved installation/host binding; private shopper flows remain client-side. [Rendering strategy](../Docs/rendering-strategy.md).
- Canonical slug/history and one-hop redirects, meaningful statuses, shared metadata, real responsive derivatives, initial-HTML JSON-LD and conservative public offer facts. [Canonical policy](../Docs/canonical-policy.md), [structured data](../Docs/structured-data.md), [Stage 11 image fix](11-release-blocker-resolution.md).
- Approved merchant identity and revision-bound useful CMS content; no AI-generated claims or separate SEO product database. [Stage 08 evidence](08-merchant-entity-content-and-geo.md).
- Installation-scoped robots/sitemaps, reference-v1 feeds, reconciliation/retry state, evidence-based referral attribution and sampled health findings. [Crawler policy](../Docs/crawler-policy.md), [feeds](../Docs/product-feeds.md), [analytics](../Docs/analytics.md).
- Stage 12A candidate assembly, source/artifact fingerprints, operational handoff and first-client checklist. [Reproduction](../Tests/stage12a/README.md), [operations](../Docs/operations.md).

## Verified

Verification applies only to the environment and revision in its evidence. Historical results remain historical; current candidate checks are listed under Regression results. The Stage 02 grocery-palette hold was resolved by its documented follow-up and must not be presented as an ongoing failure. The Stage 11 local release follow-up resolves intended-runtime, image-transfer and synthetic workload evidence gaps, while preserving live deployment gaps. [Stage 02 follow-up](02-validation-follow-up.md), [Stage 11 follow-up](11-release-blocker-resolution.md).

## Partially verified

The candidate uses installed JS dependencies and a cached Linux toolchain image; it is not an independent clean-machine rebuild. The isolated snapshot hashes required committed/uncommitted/untracked source inputs and generated artifacts. Concurrent original-workspace changes to storefront `main.tsx` and `mobile-navigation.css` were observed after snapshot assembly; the isolated app inputs/artifacts remain unchanged and those later changes are not certified. Shared package source/dependency metadata still match the snapshot checks. Full first-client theme parity, interactive Admin workflows, real search/checkout E2E and live telemetry require Phase B. [Provenance and test scope](../Tests/stage12a/README.md).

Local schema-shape and visible-fact checks do not establish external rich-result approval. Dated provider-source reviews are retained without claiming a fresh documentation review. Lab interaction timings are not field INP, browser observations are not authenticated AI identity, and historical pre-SEO field telemetry is unavailable. [Structured-data scope](../Docs/structured-data.md), [analytics semantics](../Docs/analytics.md), [performance baseline](../Docs/performance-baseline.md).

## Not implemented

External Google/Meta feed transports, Search Console/IndexNow submission, llms.txt publication, independent multilingual storefront routes/hreflang, multi-currency checkout/FX, inferred global stock, fabricated identifiers/ratings or policy-specific schema inferred from prose. Dynamic shared HTML caching, distributed admission and external alert delivery are not delivered by this milestone. [Feed boundary](../Docs/product-feeds.md), [AI discovery](../Docs/ai-discovery.md), [Stage 06 omissions](06-structured-data-and-product-facts.md), [Stage 11 scope](11-performance-security-and-tenant-isolation.md).

## Blocked

First-client identity/domain/access, named operators and calendar test window are not assigned. Actual storage/IAM separation, public DNS/TLS/CDN/WAF behavior, existing-image regeneration, target workload and infrastructure rollback remain required. The former Quality host is retired. Each required action, owner role and gate deadline appears in the [first-client acceptance record](../Docs/first-client-acceptance.md); names and dates must be assigned before pilot admission.

## Future enhancements

Provider-specific remote adapters, distributed controls, translated publication, stronger whole-catalog health/field telemetry, journal retention/compaction and any caching require separately designed, tested scope. They do not substitute for current live acceptance. [Feed operations](../Docs/feed-operations.md), [health scope](../Docs/health-engine.md), [cache decision](../Docs/cache-and-invalidation.md).

## Acceptance matrix

| Area | Local evidence and level | First-client requirement |
|---|---|---|
| Program/design (00–01) | **Verified** design/provenance records; original source assessment is historical. [00](00-program-contract.md), [01](01-assessment-and-target-architecture.md) | Assemble exact deployable release, not a document-only commit. |
| Indexing/host policy (02) | **Verified** local HTTP policy and cross-installation controls; initial frontend hold superseded. [02](02-effective-indexing-and-domain-policy.md), [follow-up](02-validation-follow-up.md) | Observe actual merchant/demo/admin response headers and controlled indexing transition. |
| Rendering/statuses (03) | **Verified** raw HTTP, no-session publication and meaningful status fixtures. [03](03-server-visible-rendering-and-http-status.md), [current raw product](evidence/stage12a/products-apples.http) | Public ingress and client-theme/browser acceptance. |
| Canonical lifecycle (04) | **Verified** local rename/ID one-hop redirects, query handling and 404/410 rules. [04](04-canonical-urls-slugs-and-redirects.md) | Client migration collision audit and approved domain routing. |
| Metadata/media (05) | **Verified** raw metadata, real image bytes, private-media access/revocation. [05](05-metadata-on-page-links-and-images.md), [candidate regressions](../Tests/stage12a/backend-regressions.log) | Regenerate old derivatives, inspect representative images and public-edge access. |
| Facts/schema (06) | **Verified** local HTML/JSON-LD parity, variants, regions and omissions. [06](06-structured-data-and-product-facts.md), [Node checks](../Tests/stage12a/node22-tests.log) | Client facts/policies and external display eligibility where required. |
| Robots/sitemap (07) | **Verified** local protected-host/eligibility matrix; scale evidence remains historical. [07](07-robots-sitemaps-and-crawler-policy.md), [discovery tests](../Tests/stage12a/backend-regressions.log) | Public TLS/CDN/WAF and actual approved crawler access. |
| Merchant/GEO (08) | **Verified** approved public identity/content and private-field suppression in synthetic fixtures. [08](08-merchant-entity-content-and-geo.md) | Client editorial approval and Admin walkthrough; not automatic fact-checking. |
| Feed freshness (09) | **Verified** reference pipeline create/update/delete, retries and isolation. [09](09-product-feeds-and-freshness.md), [candidate feed tests](../Tests/stage12a/backend-regressions.log) | Actual catalog reconciliation and operational duration; external transport remains Not implemented. |
| Measurement/health (10) | **Verified** synthetic classification/privacy/revenue linkage and actionable failures. [10](10-attribution-health-and-observability.md), [candidate measurement tests](../Tests/stage12a/backend-regressions.log) | Real traffic coverage, operator response and public-edge findings. |
| Hardening (11) | **Verified** local tenant/privacy/timeout tests; **Partially verified** live deployment. [11](11-performance-security-and-tenant-isolation.md), [follow-up](11-release-blocker-resolution.md) | Real storage/IAM, target performance and infrastructure rollback. |
| Final acceptance (12) | **Partially verified** — this Phase A record. [Reproduction](../Tests/stage12a/README.md) | All mandatory Phase B rows and final recommendation. |

## Performance results

The last controlled Stage 11 image-bearing experiment measured product LCP 7.744→2.160 seconds desktop and 3.108→1.692 seconds mobile with 80 ms latency, 200,000 bytes/s download and 4x CPU slowdown. Two local renderers served 51,275 requests in 60 seconds with zero errors and 23.19 ms p95 response latency. A real-paced synthetic 2,204-resource feed pass took 231.93 seconds. These are **Verified historical local observations**, not new Stage 12A benchmarks or first-client performance promises. [Measurements and limitations](11-release-blocker-resolution.md), [raw workload](evidence/stage11-release/release-workload.json).

## Security and tenant-isolation results

Candidate regressions retain two-installation identity/host/privacy checks, actual public/private image byte checks, admin authorization and database timeout/recovery. Public response caching remains disabled. Application tests do not certify a deployed storage topology or constitute independent penetration testing. No new production security conclusion is drawn from the absence of failing local assertions. [Candidate hardening log](../Tests/stage12a/backend-regressions.log), [tenant evidence](evidence/stage12a/tenant-matrix.json), [security contract](../Docs/security-and-privacy.md).

## Regression results

The candidate broad run passed **153 backend tests** across 22 targets, with five pre-existing optional tests skipped. Frontend Vitest passed **516 tests across 25 files**; Node 22 server checks passed **28 tests**. Deployment characterization passed **10 tests**, and deployment/preflight contract tests passed **seven**. Storefront/Admin TypeScript checks, storefront client/SSR seal, Admin build and Linux release gateway build exited successfully. Focused host Clippy for the changed rendering test target passed with warnings denied ([log](../Tests/stage12a/clippy.log)). [Backend](../Tests/stage12a/backend-regressions.log), [frontend](../Tests/stage12a/frontend-tests.log), [Node](../Tests/stage12a/node22-tests.log), [deployment](../Tests/stage12a/deployment-tests.log), [preflight](../Tests/stage12a/preflight-tests.log), [build commands/logs](../Tests/stage12a/README.md).

Skipped cases are the Admin customer-journey preview, Meilisearch stock facets, two-million-product capacity, explicit 50,001-product benchmark and ClickHouse assistant-report integration. Historical capacity/load evidence is retained, not relabeled as a candidate rerun. Full live search, checkout and Admin browser regressions remain Phase B requirements. No existing test was disabled by Stage 12A. [Exact skips](../Tests/stage12a/backend-regressions.log).

Initial assembly omitted shared fixtures; preserved failure logs show missing files, and restoring those inputs resolved the affected frontend/deployment/build failures without altering assertions. The optional browser test also exposed a stale proxy fixture after attribution was introduced; its API routing/method behavior was corrected. The corrected browser-enabled rendering suite passed nine tests, retaining hydration, real navigation, no-session startup, no-JavaScript pages and 404/410 assertions. Search/private cart/account responses remain explicit stubs. The fixture now asserts attribution HTTP 200, waits for DOM/UI readiness instead of keepalive-sensitive network idle, and drains renderer stdout to prevent test-only EPIPE failures. [Browser result](../Tests/stage12a/browser-rendering.log). [Assembly notes](../Tests/stage12a/README.md), [browser diagnostic](../Tests/stage12a/browser-diagnostic.log).

## Deployment and rollback plan

Follow [operations](../Docs/operations.md), the [deployment handoff](../Docs/stage11-deployment-handoff.md) and [first-client plan](../Docs/first-client-live-validation.md). Use a protected prelaunch surface; preserve existing live-store routing/indexing. Validate actual identity/storage and public ingress, regenerate required images in bounded batches, inspect facts and health, exercise rollback in the agreed window, then record a distinct indexing/cutover decision. Keep additive database/feed state and matching prior artifacts. Local application/proxy rollback evidence does not certify live infrastructure recovery.

## Known limitations

One public locale/default market and current USD commerce constraint; bounded family/attribute/content samples; no private/personalized price or global stock inference; sampled health and nonaggregated renderer counters; reference adapter only; no guaranteed feed freshness deadline; no ranking/indexing/citation guarantee. Full merchant-theme parity and live UI acceptance remain unresolved. [Facts](../Docs/public-product-facts.md), [feed limits](09-product-feeds-and-freshness.md), [observability limits](10-attribution-health-and-observability.md).

## Evidence index

- [Stage 12A candidate input manifest](evidence/stage12a/candidate-source.json), [source/artifact reconciliation](evidence/stage12a/reconciliation.json), [exact commands and limitations](../Tests/stage12a/README.md).
- [Stage 11 historical source manifest](11-source-manifest.json), [release follow-up manifest](11-release-source-manifest.json), [resume audit](evidence/stage11-resume/integrity-audit.json).
- Stage reports 00–11 are linked in the acceptance matrix and retained unchanged. Their dates/scopes remain authoritative for historical claims.
- [First-client checklist](../Docs/first-client-acceptance.md) records all live items as Blocked until execution supplies actual evidence.
