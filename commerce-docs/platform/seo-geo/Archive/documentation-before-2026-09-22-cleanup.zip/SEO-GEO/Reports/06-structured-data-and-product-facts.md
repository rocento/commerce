# Stage 06 — Structured data and public product facts

## Repository findings

Stage 05 (`829c673`) supplied canonical snapshots, metadata, accessible public rendering and measured media. Catalog products already carried SKU, type, parent/family links and merchant-defined attributes. Checkout uses the existing decimal promotion evaluator; stock is location/source/reservation dependent. The API/database only support USD. Complete approved merchant policy fields belong to Stage 08 in the architecture contract.

Scope remains the merchant platform. Corporate website and assistant implementation were not changed. Existing generated-contract edits and a concurrent storefront theme edit were preserved and excluded from this stage's commit. The latter was present during frontend build/browser validation.

## Architecture decision

**Implemented** — extend the typed anonymous product projection and repeatable-read snapshot. Reuse the existing pricing evaluator, current canonical context and measured images. Generate JSON-LD from exactly those facts. No duplicated SEO catalog, migration, background projection or cache was introduced.

## Implemented

- Public SKU, parent/family relationships, explicit configuration selectors and computed offer eligibility/diagnostics.
- Unconditional catalog discounts through the shared evaluator, with the same displayed price used by product detail, cards, family members and offers.
- Initial-HTML Organization, WebSite, WebPage, Product/ProductGroup, eligible Offer, BreadcrumbList and measured ImageObject nodes.
- Visible SKU/seller, family links, variation dimensions and individual family specifications/prices.
- Stage 04 independent child canonicals, inactive-child removal and inactive-parent protection.
- A serializer that escapes script-breaking text and rejects material product/offer/merchant contradictions before serving HTML.

**Implemented** — conservative omissions: uncertain regional availability; conditional catalog/automatic cart offers; unsupported currencies; composite parent/aggregate prices; guessed brand/GTIN/MPN/condition; reviews/ratings; incomplete shipping/return policy schema. These omissions avoid unsupported claims and are documented rather than represented as feature eligibility.

## Files changed

`public_commerce/facts.rs` owns computed pricing and graph assembly; the existing snapshot/catalog/image projections supply facts. The storefront public component renders matching seller/SKU/family content. `server/structured-data.mjs` validates and serializes the graph; `publication.mjs` embeds it in the initial head. The gateway uses its workspace decimal dependency directly. Contract extensions are additive to the internal snapshot; unrelated generated OpenAPI files were not changed by this stage.

Source hashes are recorded in `06-source-manifest.json`. The existing repository contains substantial untracked application source, so the local stage commit is not claimed to establish a fully reproducible application baseline alone.

## Tests run and results

| Check | Result |
| --- | --- |
| Real database/gateway/renderer integration, including Chromium | **Verified** — 12 passed (7 rendering, 3 policy, 2 media) |
| Public-commerce Rust unit tests | **Verified** — 10 passed |
| Node 22 server/JSON-LD checks | **Verified** — 18 passed |
| Catalog, schema, attributes/product types, cart and admin-depth regressions | **Verified** — 42 passed |
| Frontend Vitest | **Verified** — 116 passed across 22 files |
| Storefront client/SSR build and artifact seal | **Verified** |
| Storefront TypeScript, changed-file ESLint, all-target gateway Clippy | **Verified** — exit 0 |

Commands are in `Tests/stage06/reproduce.md`; logs and raw responses are in the same directory. A requested test target named promotions did not exist; the available catalog/type/cart suites containing relevant coverage were used. No test was disabled.

## Acceptance evidence

**Verified** — `structured-{grocery,jewelry,fashion,skincare,electronics,retail}.html` contains initial-HTML JSON-LD using real fixture catalog facts and approved scalar attributes. Assertions compare visible product name, price, currency, merchant, canonical and specifications with parsed JSON. Missing image/brand/identifiers/reviews are omitted. Stage 05's image fixture additionally asserts measured ImageObject dimensions, and all four page types assert WebPage URL equals the canonical.

**Verified** — `structured-discounted.html` shows USD 2.92 both visibly and in the Offer after the existing evaluator applies 10% to USD 3.25. Conditional pricing suppresses the offer while preserving the base-price/cart-confirmation display. Unsupported currencies are preserved without conversion in unit tests and rejected by the live catalog database contract.

**Verified** — `structured-variants.html` contains an actual configurable dimension, visible child SKU/specifications/price and a matching individual offer. The child has its own canonical and parent reference. Inactive children disappear; inactive parents make child URLs 404. Composite parents have no synthetic offer.

**Verified** — region-restricted and legacy out-of-stock-flag fixtures omit an unprovable availability enum. Published free-text policy content does not create return/shipping promises. Unicode containing a closing script payload round-trips as JSON without creating another executable script. Node mutation tests reject conflicting price, currency, seller, URL, name and availability.

Existing suites retain no-session/no-JavaScript content, hydration, two-installation isolation, canonical/history/status behavior and private-media protection. The browser screenshots use the synthetic default merchant fixture.

## Performance/security observations

Pricing rules load once per snapshot with the same 100-rule ceiling and ordering as checkout; family reads use the existing 100-child limit. Attribute publication uses active front-visible or explicitly configurable scalar definitions. No customer context or private policy source is queried. Decimal pricing, canonical identity and publication visibility are reused rather than reimplemented in the renderer. Broad suppression of ambiguous promotions trades schema coverage for accuracy.

## Partially verified

External Schema.org/Google rich-result tools, actual search/social display, deployed merchant domains, production-size catalogs and custom merchant variation dimensions. Textual variesBy values accurately retain merchant labels; provider-specific feature eligibility is not asserted. All physical stock states remain deliberately unresolved without a delivery context. The concurrent theme working-tree edit was present during frontend tests but is outside this commit.

## Not implemented

Production deployment; multi-currency checkout/FX; global stock inference; typed brand/GTIN/MPN mappings; aggregate bundle/group pricing; complete shipping/return policy schema before approved Stage 08 data; ratings/reviews; sitemap/feed generation. No ranking, citation, indexing or rich-result guarantee is made.

## Blocked

No blocker remains for the local Stage 06 consistency gate. External production validation requires an approved deployed installation. Incomplete policy/availability data is omitted rather than treated as a public claim.

## Follow-up for the next stage

Stage 07 can enumerate the existing canonical public resources without introducing new price/stock sources. Later policy work should supply validated typed data before enabling return/shipping schema. Preserve the same visibility, tenant binding, pricing diagnostics and private-media authorization.
