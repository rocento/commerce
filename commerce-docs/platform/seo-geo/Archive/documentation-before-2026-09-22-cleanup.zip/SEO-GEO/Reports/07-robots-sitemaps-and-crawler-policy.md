# Stage 07 — Robots, sitemaps and crawler policy

## Repository findings and architecture decision

Stage 06 provided the merchant canonical snapshot, server HTML, JSON-LD and public-media eligibility. Robots output had only a wildcard policy; merchant sitemaps and provider controls were absent. Catalog administrative timestamps are not trustworthy page-modification timestamps. Existing CMS releases supply an actual public release time.

**Implemented** — derive bounded discovery artifacts from the existing catalog/CMS and canonical Context, reuse effective indexing policy, and store only independent provider preferences. No duplicate SEO catalog, shared cache, background job, corporate website change or assistant implementation change was introduced. The design decision was recorded before implementation in the working update and is detailed in `../Docs/sitemap-operations.md`.

## Implemented

- Installation/Host-bound robots, sitemap index and UUID-range partitions through the gateway and Node publisher. All artifacts are no-store; successful Node responses require the expected database installation UUID.
- Environment/private-route rules, canonical sitemap advertisement and repeated private exclusions in every permitted provider group.
- Executable provider registry with official sources and verification dates. OpenAI search retrieval and training preferences are separate, revisioned, permission checked and audited; Admin uses explicit provider names.
- Active public product/category/current CMS URL eligibility, exclusion of inactive-parent children and explicit redirect/removal sources, shared canonical adapter and bounded XML output.
- Genuine CMS release dates; deliberate omission of unreliable product/category/home dates. Stale overflowing partitions fail rather than truncate.
- Additive crawler OpenAPI contract. Existing llms configuration remains backward compatible but is explicitly marked nonoperational in Admin.

## Tests and evidence

| Check | Evidence level and result |
| --- | --- |
| New discovery integration cases | **Verified** — 4 passed: eligibility/XML/dates, policy matrix/binding, preferences/revisions/audit, stale partition growth |
| Existing rendering/policy/media integration | **Verified** — 12 passed (7 rendering, 3 policy, 2 public/private image tests) |
| Two-million-product capacity | **Verified** — 2,003 index entries, 286,394-byte XML index; index plus three 1,000-URL partitions in 688 ms locally |
| Official sitemap/siteindex XSDs | **Verified** — all 7 captured XML documents passed xmllint validation |
| Public-commerce Rust unit tests | **Verified** — 12 passed |
| Node publication checks | **Verified** — 19 passed, including artifact binding, credential exclusion and HEAD |
| Frontend Vitest | **Verified** — 117 passed across 22 files in the current shared tree |
| Client/SSR build and artifact seal | **Verified** — exit 0 |
| Admin/storefront TypeScript, changed Admin ESLint | **Verified** — exit 0 |
| Gateway library/test Clippy | **Verified** — exit 0 |

The standard discovery suite explicitly omits the capacity test, which passed in a separate selected run. The first capacity attempt exceeded the original three-second SQL limit. Profiling identified expensive bounded regex matching; equivalent length/invalid-character checks removed that cost, and discovery received its own bounded 20-second request/15-second SQL budget. Ordinary storefront document budgets remain unchanged. The final fixture contains two million products and four million canonical alias reservations; bulk fixture setup restores slug normalization before HTTP verification. See `evidence/stage07/scale.json` and `../Tests/stage07/capacity-test.log`. Reproduction commands and discovery test log are in `../Tests/stage07`; raw XML, robots and existing publication regression responses are in `evidence/stage07`.

The initial sandboxed Node HTTP run failed with local listen EPERM and passed with approved socket access. An ESLint invocation from the repository root could not locate the frontend config; the documented frontend-directory invocation passed. A later concurrent frontend build removed the shared artifact manifest; rendering validation was moved to an isolated sealed build. These harness failures were corrected rather than suppressed.

## Acceptance evidence

**Verified** — production-like, demo, staging, admin and development policy tests demonstrate the expected robots rules. Existing policy tests cover deployment header overrides. Only production indexable output advertises the approved sitemap. Production noindex pages remain fetchable for traditional crawler removal; no sitemap remains advertised. Artifacts themselves retain noindex/no-store.

**Verified** — the 2,105-product eligibility fixture produces 2,104 distinct public URLs after excluding four products and adding home, category and current CMS page. Every resource class is sampled, all partition outputs remain within 1,000 URLs, dates are stable, and drafts/private/query URLs do not appear. A stale partition exceeding the cap returns 503; a fresh index supplies the extra partition.

**Verified** — wrong Host returns 421, wrong database binding returns 503, and the Node proxy rejects another installation's successful artifact. Existing two-installation tests and public-media authorization tests still pass. The provider registry parses, named preferences vary independently, unauthenticated access fails, stale writes conflict and exactly one successful update is audited.

## Performance/security and operational limits

Memory is bounded by partition anchors and at most 1,001 resource rows, with explicit response size and index-entry ceilings. Database windows may use disk. Each response is transactionally consistent; the entire catalog is not frozen across crawler requests. Index/partition timeouts and oversized stale partitions fail closed with 503. See sitemap operations for limits and recovery.

**Partially verified** — production DNS/TLS/CDN headers, provider ingestion and live merchant Admin browser interaction were not exercised. Local HTTP uses production-like approved hosts over loopback. Capacity results describe the synthetic local database only. No ranking/indexing/citation or production-readiness claim is made.

**Not implemented** — deployment, production migration, external search-console submission, optional llms.txt generation and image sitemap. llms.txt explicitly returns 404 even when its reserved legacy preference is true. No policies/support claims are fabricated.

**Future enhancement** — a comprehensive public-content modification clock for catalog/category/home, additional separately verified provider controls and immutable precomputed sitemap generations if operational scale requires them.

## Scope and provenance

Concurrent analytics/customer-journey source, theme edits and unrelated generated-contract changes were preserved and excluded from the stage commit. Only the additive crawler schemas/path are staged from generated files. Source hashes and the exact stage file list are in `07-source-manifest.json`. The repository still contains substantial untracked application source; this commit alone is not a reproducible full-application baseline.
