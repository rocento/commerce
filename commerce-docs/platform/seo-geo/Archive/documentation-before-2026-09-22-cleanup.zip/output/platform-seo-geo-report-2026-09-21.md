# Platform SEO and GEO assessment

Date: 21 September 2026  
Scope: merchant storefronts, catalog, admin controls, supporting APIs and deployment configuration in Commerce AI / Rocento. The company marketing website is excluded from the assessment. GEO means generative engine optimization: making merchant products and information discoverable and usable in external AI answers.

**Assessment: the platform has useful catalog and settings foundations, but storefront SEO and GEO are incomplete. The existing SEO and AI-discoverability admin screens do not establish that merchant stores are optimized.**

This is a source-code assessment, not a live-domain crawl. Index coverage, rankings, external AI citations, deployed headers, Core Web Vitals and actual merchant content quality remain unverified. “Not found” below means not found in the inspected platform implementation. No application changes were made.

## Current capability

| Area | Evidence and status | Business implication |
| --- | --- | --- |
| Admin SEO controls | Implemented: site/organization name, canonical base URL, description, locale and indexing switches. API includes permissions, revision checks and audit logging. | Useful configuration foundation; no storefront consumer was found. Saving these fields does not demonstrate a change in storefront output. |
| Admin GEO controls | Implemented: llms.txt switch, public-section switches and demo links. Sections include features, industries, pricing and changelog. | Controls are oriented toward public platform information, with no demonstrated product-discovery publishing pipeline. |
| Catalog data | Products contain names, descriptions, slugs, SKU, price, currency, attributes, images, stock and update time. Categories have names, slugs and hierarchy. | Much of the data needed for search-friendly pages and product markup already exists. |
| Page rendering | Vite/React client rendering; initial HTML has an empty root and a generic “Recento · Storefront” title. Product data is fetched after loading JavaScript. Route content also waits for account restoration to settle. | Crawlers must execute JavaScript and complete additional requests to see product content. Google can render JavaScript; other crawlers may not. |
| Page metadata | No storefront implementation found for unique titles, meta descriptions, canonical tags or social metadata. | Product and category pages lack deliberate page-level search and sharing descriptions. |
| URLs | Public routes use `/products/:id` and `/categories/:id`, despite stored slugs. | ID URLs can be indexed. Slugs are a usability opportunity, while consistent canonicals and redirects are the higher priority. |
| Structured data | No storefront Product, Offer, BreadcrumbList or merchant JSON-LD found. | Catalog data is not published in a standard format for product rich-result eligibility. |
| Crawl discovery | No storefront robots.txt, sitemap or llms.txt implementation found. | No explicit storefront crawler policy or catalog sitemap publication was demonstrated. |
| HTTP errors | Deployment uses an index.html fallback; the client renders “Page not found” for unmatched routes. | Unknown URLs can return an HTML success response, creating a soft-404 risk. API errors alone do not correct the page's HTTP status. |
| Deployment indexing | The inspected EC2 generator adds `X-Robots-Tag: noindex, nofollow` to demo storefront and admin hosts. | Appropriate for demos and admin. This configuration would prevent normal indexing if reused for a production merchant store. |
| Attribution | Browser analytics classifies search, social, email, referral, direct and unknown traffic. | AI referrals have no dedicated classification; AI-assisted visits can be mixed into referral or direct traffic. |

## What the existing settings actually do

The backend persists discovery settings and exposes public and authenticated configuration endpoints. The admin calls the authenticated endpoint and reports a successful save. I found no corresponding storefront consumption or output generation for those settings.

The database defaults discovery and indexing to disabled. Those database values are not themselves crawler directives. Similarly, enabling the admin switch cannot override a deployment-level `noindex` header. This disconnect is the most important product issue: a merchant can reasonably interpret the interface as controlling their storefront when that behavior is not demonstrated in the code.

The repository's existing AI-Discoverability initiative explicitly describes its scope as the marketing/docs website. Its completion checklist should not be used as evidence that merchant storefront SEO or GEO is complete.

## SEO priorities

1. **Connect merchant settings to storefront output.** Define a per-installation production domain, merchant identity and publishing policy. Make the effective indexing state visible, including deployment overrides. Keep demo and admin protection intact.
2. **Publish product, category and merchant information in initial HTML.** Add server rendering or a regeneration approach suitable for catalog size and update frequency. Include headings, descriptions, links, metadata and structured data. Public catalog rendering should not depend on customer-session restoration. Google recommends server rendering or prerendering as useful for users and crawlers; not all bots execute JavaScript. [Google JavaScript SEO guidance](https://developers.google.com/search/docs/crawling-indexing/javascript/javascript-seo-basics)
3. **Add page-level metadata controls.** Provide automatic defaults plus merchant overrides for product, category and CMS page titles and descriptions. Generate a canonical URL for each page. Define policies for variants, filters, sorting and pagination; avoid canonicalizing every page to the home page.
4. **Implement discovery and URL lifecycle handling.** Publish a sitemap containing eligible public URLs, serve robots.txt, return genuine missing-page statuses, and redirect renamed or replaced URLs where appropriate. Keep private and transactional pages out of discovery. Authentication remains the protection for private data.
5. **Publish accurate commerce structured data.** Generate Product/Offer and breadcrumb markup, plus merchant policies where supported. Use genuine visible review data only. Align price, currency, variants and availability with the page. Google supports both page markup and Merchant Center feeds for product discovery. Neither guarantees enhanced results. [Google product data guidance](https://developers.google.com/search/docs/appearance/structured-data/product)

## GEO priorities

External AI visibility starts with accessible, accurate merchant pages. The platform's shopping assistant is an onsite capability; its existence does not establish external AI discovery or citation.

Publish useful product specifications, materials or ingredients, dimensions, compatibility, delivery coverage, returns, warranty and merchant contact information where relevant. Make published policy and buying-guide content accessible at stable linked URLs. Use the existing content system as a foundation, while improving rendering and metadata.

Pay particular attention to location-dependent stock. The product API changes availability based on delivery context, and can reject an unsupported selected location. Define a truthful public default and describe regional restrictions. Crawlers should not need a delivery pin to understand a product, and global stock must not imply delivery everywhere.

Treat llms.txt as an optional output with a specific intended consumer. It is not the core GEO feature. Google states that llms.txt is not used for its Search visibility and that there is no special schema required for generative AI search. These statements concern Google; they should not be generalized into claims about every AI service. [Google generative AI optimization guidance](https://developers.google.com/search/docs/fundamentals/ai-optimization-guide)

Provide crawler controls that distinguish search/retrieval access from model-training preferences where services support that distinction. Verify each provider's current rules during implementation. Add product feeds after the canonical product data and update pipeline are reliable.

## Recommended delivery sequence

| Priority | Deliverable | Acceptance evidence |
| --- | --- | --- |
| P0 | Effective storefront indexing and settings integration | Inspect real response headers and HTML on a production-like merchant host. Demonstrate that settings affect the intended host and that admin/demo remain protected. |
| P0 | Rendered public catalog and correct HTTP statuses | Fetch product/category pages without JavaScript and find their actual content. Missing URLs return 404/410 as appropriate; account state does not gate catalog rendering. |
| P1 | Metadata, canonical policy, sitemap and redirects | Sample each page type, changed slug, variant and filtered URL; verify intended canonical, status, sitemap inclusion and indexing policy. |
| P1 | Product and merchant structured data | Validate representative simple and variant products; reconcile markup with visible price, stock, policies and approved reviews. |
| P2 | Merchant content tools and product feed | Publish an accurate buying guide and policies; validate a feed and demonstrate update propagation after catalog changes. |
| P2 | SEO/GEO measurement | Establish per-domain search visibility, crawl errors, AI referral attribution and conversion reporting. Record a repeatable sample of external AI product queries and cited URLs. |

Track eligible indexed pages, organic visits and orders, rich-result validation issues, crawl errors, recognized AI referrals and their conversions. Treat sampled AI citations as variable observations, not guaranteed rankings. Measure mobile performance before assigning performance fixes; this assessment did not run a performance benchmark.

## Source-code evidence

- [Admin discovery settings](/Users/momar/Documents/commerce-ai/frontend/apps/admin/src/discoverability-settings.tsx:7): controls, labels and save behavior.
- [Discovery API](/Users/momar/Documents/commerce-ai/backend/crates/api-gateway/src/discoverability.rs:125): configuration endpoints, authorization and persistence.
- [Settings migration](/Users/momar/Documents/commerce-ai/backend/migrations/20260917010000_discoverability_settings.sql:1): installation-level fields and disabled defaults.
- [Storefront HTML](/Users/momar/Documents/commerce-ai/frontend/apps/storefront/index.html:1): initial document and generic title.
- [Storefront routing](/Users/momar/Documents/commerce-ai/frontend/apps/storefront/src/main.tsx:155): session gate, public routes and client-only missing-page screen.
- [Product rendering](/Users/momar/Documents/commerce-ai/frontend/apps/storefront/src/catalog.tsx:500): client data loading and visible product content.
- [Catalog model](/Users/momar/Documents/commerce-ai/backend/crates/domain-catalog/src/lib.rs:55): available product fields.
- [Public product API](/Users/momar/Documents/commerce-ai/backend/crates/api-gateway/src/catalog.rs:125): delivery-aware availability and active-product check.
- [Managed content](/Users/momar/Documents/commerce-ai/frontend/apps/storefront/src/content.tsx:1): public content rendering foundation.
- [Deployment generator](/Users/momar/Documents/commerce-ai/deploy/ec2/configure.py:166): demo/admin noindex headers and SPA fallback.
- [Attribution](/Users/momar/Documents/commerce-ai/frontend/apps/storefront/src/analytics.ts:1): current traffic-source categories.
- [Existing discoverability initiative scope](/Users/momar/Documents/commerce-ai/Rocento-Codex/AI-Discoverability/README.md:1): explains why previous website completion claims are outside this report's scope.
