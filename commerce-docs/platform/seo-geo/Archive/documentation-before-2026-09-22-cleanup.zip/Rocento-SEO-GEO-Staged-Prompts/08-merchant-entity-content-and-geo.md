# Stage 08 — Merchant Entity, Useful Content and GEO Publishing

Read and follow stages 00–07.

## Objective

Make each merchant and its products clear, authoritative and citable to customers, search engines and external generative retrieval systems through useful public content—not SEO tricks.

## Merchant entity

Provide approved public fields for:

- store name and legal/business name;
- description and logo;
- customer-service contact;
- country/region and physical locations where applicable;
- delivery areas;
- shipping, return, warranty and payment-information pages;
- social profiles;
- policy effective dates and public canonical URLs.

Separate public support contact from private/admin/user details. Require explicit publication where sensitive ambiguity exists.

Render merchant identity visibly and expose only supported structured data from Stage 06.

## Product understanding

Use the canonical public facts to answer clearly on the page:

- What is the product?
- Who sells it?
- What does it cost publicly?
- Is its availability regional or general?
- What are its important attributes and variants?
- What delivery/policy constraints apply?
- What factual guidance is supported by merchant data?

Specifications should use visible labels, semantic markup and stable anchors. Do not hide core facts in tabs that are absent from initial HTML.

## Managed helpful content

Extend the existing managed-content foundation to support:

- buying and category guides;
- sizing/material/ingredient guides;
- product comparisons based on verified catalog facts;
- delivery, return and warranty explanations;
- FAQs and care instructions.

Each page needs a canonical URL, metadata, publication state, author/merchant ownership where appropriate, updated date and relevant internal links.

Do not mass-generate pages, doorway content or thin keyword variants. AI-assisted drafting, if later added elsewhere, is outside this stage; publish only merchant-approved content.

## Admin

Provide a coherent SEO/GEO area showing:

- merchant public identity completeness;
- policies and their publication status;
- product-fact coverage by industry schema;
- content publication state;
- crawler/discovery state from earlier stages;
- specific warnings, never an arbitrary vanity score.

## Tests

Cover public/private field separation, incomplete policies, locale handling, industry attribute labels, content publish/unpublish, canonical and sitemap integration, safe rich text, internal links, tenant isolation and no unsupported health claims.

## Documentation and report

Create:

```text
SEO-GEO/Docs/merchant-entity.md
SEO-GEO/Docs/geo-content-guidelines.md
SEO-GEO/Docs/industry-product-facts.md
SEO-GEO/Reports/08-merchant-entity-content-and-geo.md
```

## Acceptance gate

Publish one representative merchant, policy set, buying guide and products from multiple industries in a production-like environment. Prove the raw HTML, metadata, structured data, internal links and sitemap entries are accurate, useful and free of private or fabricated content.

