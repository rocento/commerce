# Stage 04 — Canonical URLs, Slugs and Redirect Lifecycle

Read and follow stages 00–03.

## Objective

Introduce human-readable, tenant-safe canonical URLs with backward-compatible redirects and explicit duplicate-control policies.

## Preferred public routes

```text
/products/{product-slug}
/categories/{category-slug}
```

If locale is part of the public path, define it centrally and consistently. Keep internal IDs in APIs/database where useful; do not expose them merely because they exist.

## Slug lifecycle

Implement:

- deterministic slug generation;
- Unicode/transliteration policy appropriate to supported locales;
- normalization and reserved-word protection;
- uniqueness within the correct tenant scope;
- collision handling;
- explicit merchant override where supported;
- slug history;
- atomic redirect creation on change;
- redirect-chain collapse;
- loop prevention;
- deletion/replacement behavior;
- migration of existing ID URLs without breaking old links.

## Central canonical service

Create one canonical URL service used by HTML metadata, JSON-LD, sitemaps and feeds.

Inputs should include only trusted resolved values:

- tenant/installation;
- approved storefront origin;
- resource type and slug;
- locale;
- variant policy;
- pagination where indexable.

Never derive canonical origin from an untrusted request host.

## URL policy

Define and implement behavior for:

- variants;
- filters and faceted navigation;
- sort parameters;
- pagination;
- tracking parameters;
- internal search pages;
- case, slash and encoding normalization;
- duplicate query parameters.

Avoid millions of crawlable faceted combinations. Do not canonicalize unrelated content to the home page.

## Tests

Cover:

- old ID URL to slug URL;
- previous slug to current slug;
- duplicate slugs within one tenant;
- identical slugs across different tenants;
- locale variants;
- filter/sort/tracking normalization;
- redirect chains and loops;
- deleted products/categories;
- hostile Host/forwarded-host input;
- canonical consistency across page, JSON-LD placeholder, sitemap placeholder and feed placeholder.

## Documentation and report

Create:

```text
SEO-GEO/Docs/canonical-policy.md
SEO-GEO/Docs/slug-and-redirect-policy.md
SEO-GEO/Reports/04-canonical-urls-slugs-and-redirects.md
```

Include the migration and rollback plan.

## Acceptance gate

Prove that new canonical URLs return 200, legacy and renamed URLs return a single 301 hop, deleted resources follow the documented 404/410 policy, parameterized duplicates resolve correctly, and Tenant A can never generate Tenant B's origin or routes.

