# Stage 11 — Performance, Security, Privacy and Tenant Isolation

Read and follow stages 00–10.

## Objective

Harden the entire SEO/GEO publishing path for Rocento's multi-tenant scale and prove it does not expose private data or materially degrade storefront performance.

## Performance baseline

Measure representative pages before and after SEO/GEO work:

- TTFB;
- LCP;
- CLS;
- INP where browser measurement is available;
- response HTML size;
- backend/API calls per render;
- cache hit ratio;
- render CPU/memory;
- sitemap/feed throughput and peak memory.

Use production-like product counts and variants. Report methodology, sample size and environment. Do not present local synthetic results as production truth.

## Optimization

Address measured bottlenecks only. Candidate techniques include:

- public render caching with precise invalidation;
- request coalescing;
- streamed/paged sitemap and feed generation;
- avoiding N+1 catalog/media/policy queries;
- optimized primary-image delivery;
- bounded background jobs;
- backpressure and rate limiting.

Never cache or leak customer-specific state in public documents.

## Security and privacy review

Threat-model:

- Host and forwarded-header injection;
- cross-tenant cache poisoning;
- stored XSS in metadata, attributes or JSON-LD;
- sitemap/feed enumeration of unpublished data;
- open redirects and redirect loops;
- SSRF through media or submission endpoints;
- XML/CSV injection as applicable;
- crawler impersonation assumptions;
- public exposure of private prices, inventory internals, customer/order/cart/admin data or secrets;
- authorization and audit coverage for admin settings.

Treat robots rules as advisory, never as data protection.

## Mandatory tenant matrix

Prove that Merchant A can never receive Merchant B data in:

- page HTML;
- titles/descriptions/canonicals;
- JSON-LD;
- robots.txt;
- sitemaps;
- redirects;
- feeds;
- images/media references;
- merchant entity/policies;
- health findings and analytics;
- caches and background jobs.

Test identical slugs, IDs, SKUs and locales across tenants.

## Resilience

Test downstream dependency failures, stale caches, job restarts, partial feed failures, database timeouts and deployment rollbacks. Define degraded behavior that stays truthful and private.

## Documentation and report

Create:

```text
SEO-GEO/Docs/performance-baseline.md
SEO-GEO/Docs/security-and-privacy.md
SEO-GEO/Docs/tenant-isolation.md
SEO-GEO/Docs/failure-and-rollback.md
SEO-GEO/Reports/11-performance-security-and-tenant-isolation.md
```

## Acceptance gate

All tenant-isolation and privacy tests must pass. No high/critical security finding may remain open. Performance changes must be quantified; any material regression needs an explicit fix or documented release blocker, not a waived test.


## First-client live validation — approved amendment

Recorded local verification permits Stage 12 preparation. Outstanding deployed storage/IAM isolation, public DNS/TLS/CDN/WAF behavior, representative target performance, existing-image regeneration and infrastructure rollout/rollback are carried into Stage 12’s first-client live phase. Preserve the original Stage 11 reports and their evidence classifications. Keep those findings open until actual target evidence passes; the amendment changes scheduling, not acceptance thresholds. Follow [the pilot plan](../SEO-GEO/Docs/first-client-live-validation.md).
