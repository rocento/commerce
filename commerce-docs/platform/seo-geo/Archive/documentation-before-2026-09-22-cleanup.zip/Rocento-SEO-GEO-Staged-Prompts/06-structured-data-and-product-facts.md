# Stage 06 — Structured Data and Canonical Public Product Facts

Read and follow stages 00–05.

## Objective

Create one typed public commerce representation and use it to generate accurate, server-visible structured data that matches visible storefront content.

## Canonical public product facts

Derive from authoritative catalog/merchant/policy services:

```text
Product
├── identity
├── public commercial facts
├── specifications
├── variants
├── regional availability summary
├── delivery and return policy references
├── media
└── public relationships
```

Do not persist a duplicate SEO product record unless the approved Stage 01 architecture explicitly requires a rebuildable projection. If a projection is used, define ownership, versioning, rebuilding and freshness checks.

Support industry-specific attributes without hard-coding every field into every product:

- grocery: ingredients, allergens, nutrition, weight, storage, origin, dietary properties;
- jewelry: material, purity, weight, dimensions, stones, care and warranty;
- fashion: material, size, fit, color and care;
- pharmacy/skincare: form, size, skin type, ingredients, active ingredients, usage, warnings, manufacturer and origin, only where lawful and supported by merchant data;
- electronics: brand, model, compatibility, dimensions, warranty and technical specifications;
- general retail: typed merchant-defined public attributes.

Do not generate medical or performance claims.

## JSON-LD

Generate applicable server-visible JSON-LD:

- `Organization`/merchant entity;
- `WebSite`;
- `Product`;
- `Offer` or `AggregateOffer` when supported by actual data;
- `BreadcrumbList`;
- `ImageObject` where useful;
- `MerchantReturnPolicy` and `OfferShippingDetails` only when their data is complete and accurate.

Include only supported values such as name, description, image, SKU, GTIN/MPN, brand, canonical URL, price, currency, availability, condition, seller and variant relationships.

Never fabricate reviews or ratings. Never emit empty or guessed identifiers.

## Variant strategy

Implement the Stage 04 canonical decision:

- define when variants share a canonical product;
- define when a variant is independently crawlable;
- represent variant attributes and offers accurately;
- prevent duplicate commercial pages;
- reconcile aggregate versus individual prices and availability.

## Consistency contract

Fail tests when material public facts disagree:

```text
HTML name == JSON-LD name
HTML public price == JSON-LD price
HTML currency == JSON-LD currency
HTML availability summary is compatible with JSON-LD availability
canonical link == JSON-LD URL
visible merchant == seller
```

When a dynamic regional fact cannot be truthfully represented by a standard schema value, omit or conservatively model it and document the decision.

## Tests

Test simple, variant, out-of-stock, region-restricted, missing-image, missing-brand, discounted, multi-currency and policy-enabled products. Validate JSON syntax, schema shape, escaping/XSS safety and agreement with raw HTML.

## Documentation and report

Create:

```text
SEO-GEO/Docs/public-product-facts.md
SEO-GEO/Docs/structured-data.md
SEO-GEO/Docs/variant-publication.md
SEO-GEO/Reports/06-structured-data-and-product-facts.md
```

## Acceptance gate

For representative industries and product types, validate initial-HTML JSON-LD and prove it matches visible data and canonical URLs. Any price, currency, seller or availability contradiction is a release blocker.

