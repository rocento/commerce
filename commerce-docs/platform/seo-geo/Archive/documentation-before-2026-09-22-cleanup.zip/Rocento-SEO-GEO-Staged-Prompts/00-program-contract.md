# Stage 00 — Program Contract and Guardrails

## Role

Act as the senior engineer responsible for delivering enterprise-grade SEO and generative-engine discoverability for Rocento merchant storefronts.

Do not implement product features in this stage. Establish the working contract that every later stage must follow.

## Repository context to verify

The source assessment found:

- a Vite/React storefront with an initially empty application root;
- product and category data loaded after JavaScript starts;
- public catalog routes using IDs despite stored slugs;
- generic document metadata;
- no demonstrated storefront Product/Offer/Breadcrumb JSON-LD;
- no demonstrated merchant-storefront sitemap, robots or llms output;
- an SPA fallback capable of creating soft 404s;
- admin discovery settings persisted in the backend without a demonstrated storefront consumer;
- deployment-level `X-Robots-Tag: noindex, nofollow` protection for demo/admin hosts;
- location-sensitive availability;
- existing traffic-source attribution without dedicated AI-referral classification.

Treat these as hypotheses to verify against the current repository, not permanent facts.

## Hard scope boundaries

Work only on merchant storefront SEO/GEO publishing, supporting catalog/content/admin APIs, deployment behavior, feeds, measurement and validation.

Do not modify:

- the Rocento corporate marketing website;
- shopping-assistant code, prompts, tools, LLM integration or orchestration;
- unrelated admin/catalog capabilities;
- unrelated deployment systems.

If a shared contract must change, prefer an additive, backward-compatible change. Document why it is necessary and prove unrelated consumers still pass regression tests.

## Non-negotiable engineering rules

1. Catalog and approved merchant data remain the source of truth.
2. Never create a second SEO-only product database.
3. Never fabricate price, stock, discounts, brand, GTIN, reviews, ratings, shipping, return policy or medical claims.
4. Visible content, metadata, JSON-LD, sitemap and feeds must agree.
5. Public output is tenant-scoped and host-scoped.
6. No canonical may point to localhost, admin, demo, staging, another tenant or an unapproved host.
7. Demo, staging and admin remain non-indexable by default.
8. Customer, order, cart, address, private price and credential data are never published.
9. Public catalog content must not wait for account/session restoration.
10. Use real HTTP status codes. A client-rendered not-found screen with HTTP 200 is not acceptable.
11. Avoid keyword stuffing, doorway pages and mass-generated low-value content.
12. `llms.txt` is optional and never the core strategy.
13. Do not claim rankings, citations, rich results or indexing guarantees.
14. Provider-specific crawler behavior must be verified against current official documentation at implementation time.
15. Do not disable existing tests to obtain a green build.

## Required project structure

Use or create this structure, adapting capitalization to repository conventions only when necessary:

```text
SEO-GEO/
├── Tests/
│   ├── rendering/
│   ├── metadata/
│   ├── canonicals/
│   ├── redirects/
│   ├── structured-data/
│   ├── robots/
│   ├── sitemap/
│   ├── crawler-access/
│   ├── http-status/
│   ├── feeds/
│   ├── attribution/
│   └── tenant-isolation/
├── Reports/
└── Docs/
```

Prefer existing test locations where the repository already has a strong convention; document the mapping rather than duplicating test infrastructure.

## Status language

Every report and final response must use only these evidence levels:

- **Implemented** — code exists, but verification may still be incomplete.
- **Verified** — the stated acceptance test passed with recorded evidence.
- **Partially verified** — some required environments or cases were unavailable.
- **Not implemented** — deliberately deferred or not attempted.
- **Blocked** — cannot proceed without a specific dependency or decision.
- **Future enhancement** — outside the current agreed milestone.

Do not use “complete,” “optimized,” “GEO ready,” or “production ready” without proving the full relevant acceptance gate.

## Work protocol

For every implementation stage:

1. inspect relevant code, migrations, tests and deployment configuration;
2. check working-tree state and preserve unrelated user changes;
3. write a short architecture decision before major edits;
4. implement the minimum coherent vertical slice;
5. add unit, integration and production-like contract tests;
6. run tests and capture exact results;
7. update the stage report and documentation;
8. stop if a critical gate fails.

## Deliverable

Create `SEO-GEO/Docs/program-contract.md` containing the confirmed contract, repository-specific test commands, repository naming conventions and any justified deviations.

Create `SEO-GEO/Reports/00-program-contract.md` using the shared report layout.

## Acceptance gate

This stage passes only when:

- scope boundaries are explicit;
- test and documentation locations are mapped to the actual repository;
- current build/test commands are recorded;
- no feature code has been changed;
- no excluded system has been modified.


## Approved sequencing amendment — 22 September 2026

Stage 12 preparation may proceed using recorded local Stage 11 evidence. Remaining live checks move into the first client’s controlled pilot under [the live-validation plan](../SEO-GEO/Docs/first-client-live-validation.md). Unavailable live evidence remains Blocked; failed critical tests stop pilot progression and public release. No privacy, isolation, fact accuracy or indexing safeguard is waived.
