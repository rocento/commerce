# Stage 10 — Attribution, SEO/GEO Health and Observability

Read and follow stages 00–09.

## Objective

Measure discovery traffic and surface operational problems using real evidence. Do not invent AI rankings or arbitrary SEO scores.

## Attribution

Extend the existing source classification while preserving current categories:

```text
organic_search
paid_search
social
email
referral
direct
unknown
ai_chatgpt
ai_google
ai_perplexity
ai_claude
ai_other
```

Use verified referral hosts and known UTM patterns. Do not assign a specific provider without evidence. Preserve source, medium, campaign, landing URL, tenant, session, order attribution and revenue using current privacy and retention policy.

Document first-touch/last-touch semantics and the meaning of “AI-assisted” versus “AI-attributed.” Avoid double counting.

## Health engine

Implement actionable checks for:

- canonical domain and effective indexing;
- robots and sitemap availability/validity;
- meaningful server-visible product HTML;
- canonical and robots tags;
- structured-data validity and consistency;
- public image accessibility;
- real 404 behavior;
- redirect loops/chains;
- stale feed jobs;
- crawler 403/5xx responses;
- cross-tenant host/URL anomalies.

Each finding must have severity, evidence, affected URL/resource, timestamp and remediation. Use Healthy/Warning/Error or repository equivalents. Do not collapse everything into an unexplained score.

## Analytics/Admin

Using collected data only, expose:

- recognized AI referral sessions;
- conversions/revenue under the documented attribution model;
- top landing pages and products;
- crawler activity and errors where logs support it;
- indexability and feed issues;
- trend windows with clear timezone and sampling rules.

External AI citation sampling may be documented as a manual/variable observation. Do not represent it as a guaranteed rank metric.

## Observability

Add structured logs/metrics/alerts for:

- render failures;
- unknown canonical hosts;
- sitemap generation failures;
- invalid structured data generation;
- redirect loops;
- crawler 403/429/5xx rates;
- feed failures and lag;
- tenant-resolution failures.

Do not log sensitive customer data or credentials.

## Tests

Cover classification precedence, spoofed referrers/UTMs, unknown providers, attribution persistence, revenue linkage, health-check timeouts, false-positive prevention, tenant isolation, log redaction and alert thresholds.

## Documentation and report

Create:

```text
SEO-GEO/Docs/analytics.md
SEO-GEO/Docs/health-engine.md
SEO-GEO/Docs/observability.md
SEO-GEO/Reports/10-attribution-health-and-observability.md
```

## Acceptance gate

Using synthetic but clearly labeled test traffic, prove each recognized channel is classified correctly and unknown traffic remains unknown/other. Trigger representative health failures and show actionable findings, logs and recovery without exposing sensitive data.

