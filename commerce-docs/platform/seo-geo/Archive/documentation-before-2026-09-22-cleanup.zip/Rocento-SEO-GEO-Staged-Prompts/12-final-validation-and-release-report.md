# Stage 12 — Final Validation and Release Report

Read and follow stages 00–11.

## Objective

Run production-like end-to-end validation, reconcile all stage claims with evidence and produce an honest release decision.

Do not add substantial new features in this stage. Fix only validation defects that are safe and clearly within the implemented architecture; otherwise mark them as blockers.

## Execution phases — approved 22 September 2026

**Phase A — preparation now:** reconcile stages 00–11, prepare required documentation and the acceptance matrix, assemble the exact candidate release, and run relevant local regressions. Carry forward every unresolved Stage 11 live finding. The report remains Partially verified with live checks Blocked; it must not recommend GO based on local evidence alone.

**Phase B — first-client live pilot:** run the target-environment checks and the acceptance suite below on the first client’s agreed environment, following [the pilot plan](../SEO-GEO/Docs/first-client-live-validation.md). Record client/domain, release revision and artifact hashes, installation/storage identities, operator, test window, approved test data, baseline, results and rollback evidence. Do not invent these details before onboarding.

Pilot admission, public indexing and general release are separate gates. Prepare under noindex and controlled access; noindex alone is not access control. If onboarding an already-live store, use an isolated prelaunch environment and preserve existing production indexing/routing. Use a separate synthetic installation for overlapping-tenant and destructive failure scenarios; never create another real client’s data inside the first client’s installation.

## Validation environment

Use at least:

- one production-like indexable merchant host;
- one demo/staging non-indexable host;
- the admin host;
- two tenants with overlapping product/category slugs;
- simple and variant products;
- a region-restricted product;
- published and unpublished content;
- a renamed and a deleted resource.

Record deployment revision, configuration, test data provenance and limitations.

## End-to-end acceptance suite

### Rendering and statuses

- `curl` product/category/content pages and find meaningful initial HTML;
- valid routes return 200;
- renamed routes return one 301 hop;
- unknown routes return 404;
- approved permanently removed resources return 410 where policy requires;
- public rendering does not depend on session restoration or JavaScript.

### Metadata and canonicals

- every supported page type has a correct title, description, canonical and robots directive;
- social metadata is accurate;
- no canonical points to localhost, admin, demo, staging or another tenant;
- filter, sort, pagination, tracking and variant policies behave as documented.

### Structured data

- JSON-LD exists in initial HTML;
- product name, price, currency, seller, availability and URL agree with visible output;
- variants and policies are represented only where accurate;
- no fabricated review/rating/identifier/policy data exists.

### Discovery

- robots and response headers agree with effective indexing state;
- sitemap/index validates and contains only eligible canonical URLs;
- demo, staging and admin remain blocked;
- optional llms output, if implemented, is accurate and modest in scope;
- public images are accessible under the intended policy.

### Merchant/GEO content

- merchant identity and policies are public only when approved;
- representative products show clear labeled facts;
- buying guides are useful, stable and internally linked;
- no private fields or unsupported claims appear.

### Feeds and freshness

- reference feed validates;
- create/update/delete changes reconcile across page, JSON-LD, sitemap and feed;
- retries and full reconciliation recover simulated failures.

### Measurement and operations

- recognized referrals classify correctly;
- unknown traffic is not falsely attributed;
- health checks identify actionable failures;
- logs/metrics redact sensitive information;
- rollback procedure is tested or explicitly marked partially verified.

### Multi-tenant safety

- every isolation test from Stage 11 passes;
- no cross-tenant data appears in caches, jobs, pages or discovery artifacts.

### Regression

Run the existing full relevant regression suites for storefront browsing, search, cart, checkout, accounts, catalog, variants, regional availability, admin, managed content, analytics and deployment. Do not hide failures as unrelated without evidence.

## Required final documentation

Create/update:

```text
SEO-GEO/Docs/architecture.md
SEO-GEO/Docs/rendering-strategy.md
SEO-GEO/Docs/canonical-policy.md
SEO-GEO/Docs/structured-data.md
SEO-GEO/Docs/crawler-policy.md
SEO-GEO/Docs/ai-discovery.md
SEO-GEO/Docs/product-feeds.md
SEO-GEO/Docs/analytics.md
SEO-GEO/Docs/operations.md
SEO-GEO/Reports/SEO-GEO-final-report.md
```

## Final report structure

```md
# Rocento Merchant Storefront SEO/GEO — Final Report

## Executive summary
## Release recommendation: GO / CONDITIONAL GO / NO-GO
## Implemented
## Verified
## Partially verified
## Not implemented
## Blocked
## Future enhancements
## Acceptance matrix
## Performance results
## Security and tenant-isolation results
## Regression results
## Deployment and rollback plan
## Known limitations
## Evidence index
```

Every claim must link to a test, response sample, report or exact repository artifact. Configuration/UI existence alone is not evidence of working storefront behavior.

## Final release gate

Recommend GO only if all P0/P1 behavior is verified, privacy and tenant isolation pass, no high/critical security issues remain, demo/admin/staging protection is preserved, structured data matches visible facts and relevant regressions pass.

Use CONDITIONAL GO only for explicitly bounded noncritical gaps with owners and deadlines. Use NO-GO for broken status codes, cross-tenant leakage, false public facts, incorrect canonicals, inconsistent price/currency/availability, exposed private data, or indexing safeguards that cannot be trusted.


## First-client gate ownership

The Rocento release owner coordinates technical evidence; the client owner confirms approved public facts, domain and test window. Assign named owners and calendar deadlines at onboarding before pilot admission. Every open item has an evidence link, owner, required action and gate deadline; unassigned mandatory items block progression. Stage 12’s release recommendation applies to public/general release, not merely permission to run a controlled pilot.
