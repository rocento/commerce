# Stage 05 — Metadata, On-Page Semantics, Internal Links and Images

Read and follow stages 00–04.

## Objective

Add a centralized metadata engine and make public pages semantically clear, crawlable and shareable without requiring manual SEO entry for every catalog item.

## Metadata engine

Support product, category, managed-content and store-home metadata:

- `<title>`;
- meta description;
- canonical link from Stage 04;
- meta robots from Stage 02;
- Open Graph title, description, URL, type and image;
- Twitter/social card metadata;
- locale metadata where supported.

Provide safe defaults and optional merchant overrides. Example default:

```text
{product_name} | {merchant_name}
```

Do not auto-generate misleading claims or keyword-stuffed descriptions. Define length guidance without destructively truncating meaningful Unicode content.

## Admin controls

Allow appropriately authorized merchants to configure:

- site name and default description;
- title/description templates;
- default social image;
- per-product/category/content overrides;
- preview with exact resolved values;
- validation errors and fallbacks.

Use existing revision control, permissions and audit logging.

## Semantic page structure

Ensure public pages have:

- one meaningful primary heading;
- logical heading order;
- product/category descriptions rendered as text;
- visible labeled specifications;
- breadcrumbs;
- real `<a href>` navigation for crawlable destinations;
- accessible buttons and form controls;
- no navigation dependent only on click handlers.

## Internal linking

Implement meaningful, non-spammy paths such as:

```text
Category → subcategory → product
Product → category / brand / genuinely related public products / relevant guide
Guide → referenced categories and products
```

Do not create uncontrolled tag/filter pages.

## Image SEO

Support:

- meaningful merchant-editable or deterministic alt text;
- width and height attributes;
- responsive `srcset`/sizes;
- modern formats where the existing media pipeline supports them;
- lazy loading below the fold, not for the primary LCP image;
- stable crawlable public image URLs;
- fallback behavior that does not claim nonexistent images.

Ensure CDN rules allow approved public crawlers to fetch public catalog images while private media stays protected.

## Tests

Cover metadata defaults/overrides, escaping, Unicode, missing data, tenant isolation, duplicate tags, canonical consistency, real anchors, headings, accessible names, image fallbacks and social preview output.

## Documentation and report

Create:

```text
SEO-GEO/Docs/metadata-and-on-page-policy.md
SEO-GEO/Docs/internal-linking-policy.md
SEO-GEO/Docs/image-publication.md
SEO-GEO/Reports/05-metadata-on-page-links-and-images.md
```

## Acceptance gate

Inspect raw HTML for every supported page type and prove unique, correct metadata; a single canonical; consistent robots directives; meaningful headings and links; and accessible, dimensioned images. Verify merchant overrides and automatic fallbacks.

