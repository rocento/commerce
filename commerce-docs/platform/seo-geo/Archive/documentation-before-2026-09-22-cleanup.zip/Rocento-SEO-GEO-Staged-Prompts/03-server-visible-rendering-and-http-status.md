# Stage 03 — Server-Visible Catalog Rendering and HTTP Statuses

Read and follow stages 00–02.

## Objective

Publish meaningful product, category, home and managed-content HTML in the initial HTTP response and return correct status/redirect responses before client hydration.

## Rendering requirements

Implement the rendering architecture approved in Stage 01.

For a public product page, initial HTML should contain, when publicly available:

- product name and meaningful description;
- primary image metadata;
- public price and currency;
- truthful public availability context;
- major public attributes;
- merchant/store identity;
- breadcrumbs and crawlable internal links;
- metadata placeholders required by later stages.

For category pages include category name, description, product links and pagination/navigation context. For managed content include title and article body.

Public catalog rendering must not wait for:

- customer login restoration;
- cart restoration;
- geolocation permission;
- a delivery pin;
- browser JavaScript.

Hydration may add interactivity after the meaningful response is delivered.

## Location-sensitive availability

Define a conservative public default. Examples:

- `Available in Cairo and Giza; final delivery eligibility depends on area.`
- `Availability varies by delivery location.`

Never publish global `InStock` when the product is only available in some regions. Preserve personalized/location-specific behavior after the customer provides context.

## HTTP semantics

Implement:

| Request result | Status |
| --- | --- |
| Valid public resource | 200 |
| Renamed resource | 301 to current canonical URL |
| Temporarily unavailable route, only when justified | 302/307 |
| Unknown or inaccessible public resource | 404 |
| Permanently removed resource, when policy applies | 410 |
| Private route | existing appropriate auth response |

The body and status must agree. Avoid a universal `index.html` 200 fallback for unknown public URLs.

## Caching

Add tenant-, host-, locale- and route-safe caching. Vary only on necessary public context. Do not cache customer-specific content into public HTML. Define invalidation for product/category/content publication changes.

## Tests

Add:

- raw HTTP tests with JavaScript disabled;
- server-render snapshot/contract tests;
- valid/invalid/deleted route status tests;
- session-independent public rendering tests;
- regional-availability truth tests;
- cache isolation tests;
- hydration regression tests;
- existing browsing/search/cart/account regression coverage.

## Documentation and report

Create or update:

```text
SEO-GEO/Docs/rendering-strategy.md
SEO-GEO/Docs/http-status-policy.md
SEO-GEO/Docs/cache-and-invalidation.md
SEO-GEO/Reports/03-server-visible-rendering-and-http-status.md
```

## Acceptance gate

For representative product, category and content URLs, record `curl` evidence showing useful initial HTML. Prove unknown URLs return a real 404, approved removed resources return 410 when applicable, and public rendering works without session restoration or client-side JavaScript.

