# Stage 02 — Effective Indexing and Canonical Domain Policy

Read and follow stages 00 and 01.

## Objective

Make merchant discovery settings control real storefront behavior and expose a truthful effective indexing status. Preserve demo, staging and admin protection.

## Required behavior

Create a single policy resolver that combines:

- merchant indexing preference;
- installation type;
- approved production hostname;
- deployment/environment protection;
- response `X-Robots-Tag` behavior;
- page-level robots directives;
- robots.txt policy;
- validation warnings.

Return an explicit state such as:

- `INDEXABLE`
- `MERCHANT_DISABLED`
- `BLOCKED_BY_ENVIRONMENT`
- `BLOCKED_BY_HEADER`
- `DOMAIN_UNVERIFIED`
- `CONFIGURATION_ERROR`

Use repository naming conventions rather than these exact enum values if appropriate, but preserve the semantics.

## Host policy

Implement a validated canonical-domain configuration per tenant/installation.

Requirements:

- permit only approved schemes and hostnames;
- reject localhost, IP placeholders, admin hosts and cross-tenant hosts in production;
- handle ports only where explicitly valid for local development;
- prevent Host-header injection from influencing canonical output;
- define proxy/CDN trusted-header behavior;
- record configuration changes through existing permissions, revision checks and audit logging.

## Admin

Upgrade the existing screen to show:

- merchant preference;
- effective indexing state;
- canonical production domain;
- response-header state;
- robots/meta state;
- environment override;
- concrete warnings and remediation.

Do not display “enabled” as equivalent to “indexable.”

## Deployment

Keep these defaults:

| Environment | Default policy |
| --- | --- |
| Production merchant storefront | Merchant-controlled after valid configuration |
| Demo storefront | `noindex` |
| Staging storefront | `noindex` |
| Admin | always `noindex` |
| Internal API | not an indexable surface |

Do not globally remove `X-Robots-Tag` safeguards.

## Tests

Cover:

- each environment and installation type;
- merchant setting on/off;
- deployment override;
- invalid/unverified canonical host;
- forwarded-host spoofing;
- cross-tenant hostname attempts;
- admin/demo remaining blocked;
- API and UI returning the same effective state;
- audit/revision/permission behavior.

## Documentation and report

Create or update:

```text
SEO-GEO/Docs/indexing-policy.md
SEO-GEO/Docs/domain-and-proxy-trust.md
SEO-GEO/Reports/02-effective-indexing-and-domain-policy.md
```

## Acceptance gate

Using a production-like merchant host, prove from real response headers and generated HTML that:

- enabling indexing produces a consistent indexable result only when all gates allow it;
- disabling indexing produces consistent blocking directives;
- a deployment override wins and is visible in Admin;
- demo, staging and admin remain blocked;
- no tenant can influence another tenant's domain or directives.

