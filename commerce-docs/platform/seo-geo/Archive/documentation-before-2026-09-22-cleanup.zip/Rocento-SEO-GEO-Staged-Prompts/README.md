# Rocento SEO/GEO — Staged Codex Implementation Plan

This package converts the 21 September 2026 source-code assessment into a gated implementation program for Rocento merchant storefronts.

## Scope

Included:

- merchant storefront rendering and public catalog publishing
- catalog, product, category and managed-content SEO
- merchant identity, policies and semantic product facts
- admin SEO/GEO controls that affect real storefront output
- domain, deployment, caching and crawler behavior
- structured data, sitemaps, robots, feeds and attribution
- multi-tenant safety, performance, observability and regression coverage

Excluded:

- the Rocento corporate marketing website
- shopping-assistant, LLM, agent-tool or agent-orchestration changes
- ranking guarantees, fabricated content, doorway pages and review generation
- unrelated framework migrations or broad refactors

If a shared component is encountered, preserve backward compatibility, but do not expand the work into excluded systems.

## How to run the prompts

Run the files in numerical order. Give Codex one stage at a time. Normally, the current acceptance gate must pass and its report must be committed before the next stage starts.

**Approved sequencing update — 22 September 2026:** Stage 12 preparation may start using the verified local Stage 11 evidence. Outstanding target-environment checks move into a controlled live pilot with the first client. They remain open release gates, not waived tests. Stage 12 has two phases: preparation now, then live acceptance with the first client. Follow [the first-client pilot plan](../SEO-GEO/Docs/first-client-live-validation.md).

| Order | Prompt | Outcome |
| --- | --- | --- |
| 00 | `00-program-contract.md` | Establishes non-negotiable rules and reporting format |
| 01 | `01-assessment-and-target-architecture.md` | Verifies the repository and freezes the delivery design |
| 02 | `02-effective-indexing-and-domain-policy.md` | Makes admin indexing settings truthful and environment-aware |
| 03 | `03-server-visible-rendering-and-http-status.md` | Publishes useful initial HTML and real 404/410 responses |
| 04 | `04-canonical-urls-slugs-and-redirects.md` | Adds tenant-safe canonical URLs and URL lifecycle management |
| 05 | `05-metadata-on-page-links-and-images.md` | Adds page metadata, crawlable navigation and image SEO |
| 06 | `06-structured-data-and-product-facts.md` | Creates accurate commerce facts and server-visible JSON-LD |
| 07 | `07-robots-sitemaps-and-crawler-policy.md` | Implements crawl discovery and provider-aware access rules |
| 08 | `08-merchant-entity-content-and-geo.md` | Adds merchant authority, policies and useful GEO content |
| 09 | `09-product-feeds-and-freshness.md` | Builds adapter-based product feeds and update propagation |
| 10 | `10-attribution-health-and-observability.md` | Adds trustworthy measurement and actionable health checks |
| 11 | `11-performance-security-and-tenant-isolation.md` | Hardens scale, privacy and cross-tenant guarantees |
| 12 | `12-final-validation-and-release-report.md` | Runs production-like acceptance and produces the final report |

## Stage rules

Every stage must:

1. inspect the current repository before editing;
2. reuse existing architecture when suitable;
3. preserve backward compatibility and existing regression coverage;
4. add tests for all material behavior;
5. run the narrowest relevant tests first, then the broader suite;
6. record exact commands and results in the stage report;
7. classify work as Implemented, Verified, Partially verified, Not implemented, Blocked, or Future enhancement;
8. stop on a failed critical acceptance gate; the approved Stage 11→12 exception permits preparation while unavailable live checks remain explicitly open;
9. avoid claiming SEO/GEO completion from configuration screens alone;
10. leave excluded systems unchanged.

## Required report layout

Each stage creates:

`SEO-GEO/Reports/NN-stage-name.md`

Use this structure:

```md
# Stage NN Report

## Repository findings
## Architecture decision
## Implemented
## Files changed
## Tests run and results
## Acceptance evidence
## Performance/security observations
## Partially verified
## Not implemented
## Blocked
## Follow-up for the next stage
```

Do not overwrite prior stage reports.

## Completion principle

Rocento has one authoritative public commerce representation, published consistently through server-visible pages, metadata, JSON-LD, sitemaps and feeds. Dynamic or private information must never be exposed merely for discovery.

