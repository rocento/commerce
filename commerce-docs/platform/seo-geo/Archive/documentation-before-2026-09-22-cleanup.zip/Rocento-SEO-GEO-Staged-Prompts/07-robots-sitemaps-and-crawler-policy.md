# Stage 07 — Robots, Sitemaps and Crawler Policy

Read and follow stages 00–06.

## Objective

Provide explicit, environment-aware discovery surfaces and separate traditional search, AI search/retrieval and model-training preferences where providers support that distinction.

## robots.txt

Generate tenant- and environment-aware `robots.txt`.

Requirements:

- production merchant policy follows the effective indexing resolver;
- demo/staging/admin stay blocked by default;
- cart, checkout, account, admin, preview, internal APIs and private routes are not advertised for crawling;
- robots rules do not substitute for authentication/authorization;
- the sitemap URL uses the approved canonical origin;
- cache keys prevent cross-tenant responses.

## XML sitemaps

Implement `/sitemap.xml` and sitemap indexes for large catalogs.

Example partitioning:

```text
/sitemaps/products-0001.xml
/sitemaps/categories.xml
/sitemaps/content.xml
/sitemaps/images-0001.xml   # only if justified
```

Include only active, public, canonical, indexable URLs. Exclude private, transactional, preview, disabled, noncanonical filter and unsupported URLs.

Use genuine `lastmod` derived from meaningful public-content changes. Do not rewrite timestamps merely to look fresh. Stream or page generation so multi-million-item catalogs do not require unbounded memory.

## Crawler policy

Maintain a centralized registry based on current official provider documentation.

Model distinct intentions:

- traditional search crawling;
- AI search/retrieval crawling;
- model-training preference.

Do not expose one ambiguous “Allow AI” toggle. Do not assume every provider recognizes the same directives or user agents. Record source URL and verification date for each provider rule.

If OpenAI discovery is supported, verify the current `OAI-SearchBot` guidance from official OpenAI documentation at implementation time. Treat training controls separately when supported.

## Optional llms.txt

Implement only if it fits the approved architecture. If enabled:

- generate accurate merchant public information and canonical links;
- include concise sections such as About, Categories, Guides, Policies and Support;
- do not dump the whole catalog;
- do not claim it guarantees discovery or ranking;
- make disabled/missing behavior explicit.

## Tests

Cover environment matrices, sitemap schema, URL eligibility, pagination, scale, stable lastmod, tenant isolation, crawler-registry parsing, headers versus robots consistency, public-image access and optional llms output.

## Documentation and report

Create:

```text
SEO-GEO/Docs/crawler-policy.md
SEO-GEO/Docs/sitemap-operations.md
SEO-GEO/Docs/ai-discovery.md
SEO-GEO/Reports/07-robots-sitemaps-and-crawler-policy.md
```

## Acceptance gate

On production-like, demo, staging and admin hosts, prove correct robots/header behavior. Validate sitemap XML and sample every resource class. Confirm zero cross-tenant URLs, no private routes and no fabricated freshness timestamps.

