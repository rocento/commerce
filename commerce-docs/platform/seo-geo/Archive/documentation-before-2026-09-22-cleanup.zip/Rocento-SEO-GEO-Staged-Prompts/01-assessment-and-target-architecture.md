# Stage 01 — Repository Assessment and Target Architecture

Read and follow `00-program-contract.md` before doing any work.

## Objective

Verify the supplied assessment against the current repository and define the smallest viable target architecture for merchant-storefront SEO/GEO. Do not implement the full feature set yet.

## Inspect

Trace end to end:

- merchant/installation/tenant resolution from host to request context;
- storefront framework, routing, build and deployment;
- product, variant, category, media and managed-content models;
- merchant discovery settings, revisions, permissions and audit logs;
- public APIs and location-aware availability behavior;
- reverse proxy, CDN and `X-Robots-Tag` rules;
- analytics source classification;
- caching, invalidation and event infrastructure;
- existing migrations and backward-compatibility conventions.

Locate the exact code paths corresponding to the source assessment. Note anything that has changed since 21 September 2026.

## Architecture decision

Design a reusable public commerce publishing layer:

```text
Catalog + Merchant + Content domains
                 │
                 ▼
     Canonical Public Commerce View
        ├── server-visible storefront
        ├── metadata and canonicals
        ├── JSON-LD
        ├── robots and sitemaps
        └── product feeds
```

The canonical public view may be a domain service, query model or typed assembler appropriate to the existing architecture. It must not become a second database of truth.

Define:

- public versus private fields;
- tenant and installation keys;
- locale and currency handling;
- regional availability representation;
- variant representation;
- merchant-policy references;
- cache keys and invalidation triggers;
- failure behavior when data is incomplete;
- ownership boundaries across backend, storefront and deployment.

## Rendering architecture decision

Compare SSR, controlled prerendering, incremental/static regeneration and a hybrid approach against:

- current Vite/React architecture;
- catalog size and update rate;
- multi-tenant host routing;
- product price/stock freshness;
- deployment complexity;
- cache invalidation;
- true HTTP status requirements.

Choose one approach. Do not initiate a broad framework migration unless the evidence shows it is the only safe solution. Record rejected alternatives and why.

## Required documents

Create:

```text
SEO-GEO/Docs/architecture-assessment.md
SEO-GEO/Docs/target-architecture.md
SEO-GEO/Docs/rendering-strategy.md
SEO-GEO/Docs/public-commerce-contract.md
SEO-GEO/Reports/01-assessment-and-target-architecture.md
```

Include a stage-by-stage file-impact map and migration risk list.

## Tests

Add no speculative feature tests. You may add characterization tests that freeze current behavior and expose known failures without altering production semantics. Clearly label expected failures and do not leave the default CI suite red.

## Acceptance gate

This stage passes only when:

- tenant/host resolution is understood end to end;
- the rendering approach is explicit and feasible;
- the public commerce contract identifies authoritative fields and privacy exclusions;
- cache invalidation and update freshness are designed;
- every later stage has a mapped code surface;
- no broad implementation has started prematurely.

