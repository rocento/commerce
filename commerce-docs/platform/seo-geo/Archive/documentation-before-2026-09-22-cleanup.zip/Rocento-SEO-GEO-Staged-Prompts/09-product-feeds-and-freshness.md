# Stage 09 — Product Feeds and Publication Freshness

Read and follow stages 00–08.

## Objective

Build an extensible feed layer from the canonical public commerce view and keep pages, structured data, sitemaps and feeds synchronized after meaningful catalog changes.

## Architecture

```text
Authoritative catalog/merchant data
              │
              ▼
   Canonical public commerce view
              │
              ▼
        Feed adapter contract
        ├── Google
        ├── Meta
        └── future discovery providers
```

Do not couple catalog core logic to one provider. Do not add speculative providers without a concrete adapter contract and tests.

## Feed contract

Support:

- full export and incremental updates;
- create/update/delete/tombstone semantics;
- price, currency, availability and image changes;
- variant relationships;
- locale and market scope;
- retries with backoff;
- idempotency;
- per-item validation/errors;
- job status and observability;
- tenant rate limits and isolation;
- secrets through the existing secure configuration mechanism.

Never send private/customer-specific prices, inventory internals or unpublished products.

## Freshness pipeline

For meaningful public changes:

```text
Domain change
  → public representation version changes
  → affected render cache invalidates
  → metadata/JSON-LD update together
  → feed update queues
  → sitemap lastmod changes only when justified
```

Define delivery guarantees and reconciliation. Event loss must be detectable and recoverable with a full rebuild/reconciliation job.

## Search-engine submission

Prepare adapter boundaries for sitemap submission, webmaster tooling and optional IndexNow where useful. Verify official provider requirements before implementation. Keep submission failures from corrupting catalog transactions.

## Tests

Cover full/incremental export, deletion, retries, duplicate events, out-of-order events, stale versions, feed/page consistency, multi-currency/locale, variant changes, tenant isolation, secret handling and large-catalog streaming.

## Documentation and report

Create:

```text
SEO-GEO/Docs/product-feeds.md
SEO-GEO/Docs/publication-freshness.md
SEO-GEO/Docs/feed-operations.md
SEO-GEO/Reports/09-product-feeds-and-freshness.md
```

## Acceptance gate

Demonstrate a product create, price change, availability change, image change and deletion through the complete pipeline. Reconcile the page, JSON-LD, sitemap and a reference feed after each change. Prove retries and reconciliation recover from simulated failures without cross-tenant leakage.

